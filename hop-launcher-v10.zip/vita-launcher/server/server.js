// HOP Friends Relay Server
// Маленький WebSocket-сервер для функций «Друзья»: присутствие (онлайн/статус),
// общий чат/лента активности, и передача модпаков между друзьями.
//
// Запуск:
//   cd server
//   npm install
//   npm start
// Сервер слушает порт из переменной окружения PORT (по умолчанию 8787).
// Чтобы друзья видели друг друга через интернет, сервер нужно разместить на хостинге
// (Railway / Render / свой VPS) и прописать его адрес в настройках лаунчера (вкладка «Друзья»).

const http = require('http');
const crypto = require('crypto');
const { WebSocketServer } = require('ws');

const PORT = process.env.PORT || 8787;

// clients: Map<friendCode, { ws, nickname, status, friends: Set<friendCode> }>
const clients = new Map();
// Последние сообщения активности (общая лента, кольцевой буфер на каждого пользователя).
const mailboxes = new Map(); // friendCode -> array of queued messages (для оффлайн-друзей)

function genCode() {
  return 'HOP-' + crypto.randomBytes(3).toString('hex').toUpperCase();
}

function send(ws, obj) {
  if (ws && ws.readyState === 1) ws.send(JSON.stringify(obj));
}

function queueForOffline(code, msg) {
  if (!mailboxes.has(code)) mailboxes.set(code, []);
  const box = mailboxes.get(code);
  box.push(msg);
  while (box.length > 50) box.shift();
}

function broadcastPresence(code) {
  const me = clients.get(code);
  if (!me) return;
  const payload = { type: 'presence', code, nickname: me.nickname, online: true, status: me.status || null };
  for (const [otherCode, other] of clients) {
    if (otherCode === code) continue;
    if (other.friends.has(code)) send(other.ws, payload);
  }
}

function broadcastOffline(code) {
  const payload = { type: 'presence', code, online: false };
  for (const [otherCode, other] of clients) {
    if (otherCode === code) continue;
    if (other.friends.has(code)) send(other.ws, payload);
  }
}

const server = http.createServer((req, res) => {
  if (req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('ok');
    return;
  }
  res.writeHead(404);
  res.end();
});

const wss = new WebSocketServer({ server });

wss.on('connection', (ws) => {
  let myCode = null;

  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }

    if (msg.type === 'hello') {
      // Клиент представляется. Если у него ещё нет кода — выдаём новый.
      myCode = msg.code && typeof msg.code === 'string' ? msg.code : genCode();
      clients.set(myCode, {
        ws,
        nickname: msg.nickname || 'Игрок',
        status: null,
        friends: new Set(Array.isArray(msg.friends) ? msg.friends : []),
      });
      send(ws, { type: 'welcome', code: myCode });

      // Доставляем отложенные сообщения, пока был оффлайн.
      const box = mailboxes.get(myCode);
      if (box && box.length) { for (const m of box) send(ws, m); mailboxes.delete(myCode); }

      // Сообщаем друзьям, что мы онлайн, и запрашиваем их текущий статус в ответ.
      broadcastPresence(myCode);
      const me = clients.get(myCode);
      for (const friendCode of me.friends) {
        const friend = clients.get(friendCode);
        if (friend) send(ws, { type: 'presence', code: friendCode, nickname: friend.nickname, online: true, status: friend.status || null });
      }
      return;
    }

    if (!myCode || !clients.has(myCode)) return; // нужен hello сначала
    const me = clients.get(myCode);

    if (msg.type === 'addFriend' && typeof msg.code === 'string') {
      me.friends.add(msg.code);
      const friend = clients.get(msg.code);
      if (friend) send(ws, { type: 'presence', code: msg.code, nickname: friend.nickname, online: true, status: friend.status || null });
      else send(ws, { type: 'presence', code: msg.code, online: false });
      return;
    }

    if (msg.type === 'status') {
      // { text: 'Играет: Server IP', server: 'play.example.com' } или null чтобы сбросить
      me.status = msg.status || null;
      broadcastPresence(myCode);
      return;
    }

    if (msg.type === 'chat') {
      // Общая лента: рассылаем всем друзьям отправителя
      const payload = { type: 'chat', from: myCode, nickname: me.nickname, text: String(msg.text || '').slice(0, 500), ts: Date.now() };
      for (const [otherCode, other] of clients) {
        if (otherCode === myCode) continue;
        if (other.friends.has(myCode)) send(other.ws, payload);
      }
      return;
    }

    if (msg.type === 'shareModpack' && typeof msg.to === 'string') {
      const payload = { type: 'modpack', from: myCode, nickname: me.nickname, name: msg.name || 'Модпак', mods: Array.isArray(msg.mods) ? msg.mods : [], ts: Date.now() };
      const target = clients.get(msg.to);
      if (target) send(target.ws, payload); else queueForOffline(msg.to, payload);
      return;
    }

    if (msg.type === 'joinRequest' && typeof msg.to === 'string') {
      // Просим друга подключиться к тому же серверу — просто уведомление, само подключение
      // делает клиент лаунчера локально.
      const target = clients.get(msg.to);
      const payload = { type: 'joinRequest', from: myCode, nickname: me.nickname, server: msg.server || null };
      if (target) send(target.ws, payload);
      return;
    }
  });

  ws.on('close', () => {
    if (myCode) {
      clients.delete(myCode);
      broadcastOffline(myCode);
    }
  });
});

server.listen(PORT, () => {
  console.log(`[hop-relay] слушаю на порту ${PORT}`);
});

//! Локальное хозяйство сборки: mods/, resourcepacks/, mods.json, options.txt.
//!
//! Источник правды — файлы на диске, а `mods.json` только добавляет к ним
//! происхождение (откуда качали, каким был sha1, какая версия мода). Если
//! пользователь закинул jar руками — он появится в списке; если удалил файл
//! мимо лаунчера — запись из конфига не превратится в фантомный мод.

use std::io::Read;
use std::path::{Path, PathBuf};

use serde::{Deserialize, Serialize};
use sha1::{Digest, Sha1};

use crate::modloader::LoaderKind;
use crate::paths;

const DISABLED_SUFFIX: &str = ".disabled";

// --- mods.json --------------------------------------------------------

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct ModsConfig {
    /// "Vanilla" | "Forge" | "Fabric"
    #[serde(default)]
    pub loader: String,
    #[serde(default)]
    pub loader_version: String,
    #[serde(default)]
    pub mc_version: String,
    #[serde(default)]
    pub mods: Vec<ModRecord>,
    #[serde(default)]
    pub resourcepacks: Vec<ModRecord>,
}

/// Запись о скачанном файле: нужна, чтобы перед запуском доложить пропавший
/// мод обратно и чтобы не качать то, что уже лежит с тем же sha1.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct ModRecord {
    #[serde(default)]
    pub id: String,
    pub filename: String,
    #[serde(default = "yes")]
    pub enabled: bool,
    #[serde(default)]
    pub version: String,
    /// "modrinth:AANobbMI", "curseforge:238222", "local"
    #[serde(default)]
    pub source: String,
    #[serde(default)]
    pub sha1: String,
    #[serde(default)]
    pub name: String,
    #[serde(default)]
    pub url: String,
    #[serde(default)]
    pub size: u64,
}

fn yes() -> bool {
    true
}

pub fn load_config(version_id: &str) -> ModsConfig {
    std::fs::read(paths::mods_config_path(version_id))
        .ok()
        .and_then(|bytes| serde_json::from_slice(&bytes).ok())
        .unwrap_or_default()
}

pub fn save_config(version_id: &str, config: &ModsConfig) -> anyhow::Result<()> {
    let path = paths::mods_config_path(version_id);
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    // tmp + rename: прерванная запись не оставит битый JSON.
    let tmp = path.with_extension("json.tmp");
    std::fs::write(&tmp, serde_json::to_vec_pretty(config)?)?;
    std::fs::rename(&tmp, &path)?;
    Ok(())
}

/// Фиксирует в mods.json, какой loader стоит у профиля.
pub fn remember_loader(
    version_id: &str,
    loader: LoaderKind,
    loader_version: &str,
    mc_version: &str,
) -> anyhow::Result<()> {
    let mut config = load_config(version_id);
    config.loader = loader.as_str().to_string();
    config.loader_version = loader_version.to_string();
    config.mc_version = mc_version.to_string();
    save_config(version_id, &config)
}

// --- Что видит UI -----------------------------------------------------

#[derive(Debug, Clone, Serialize)]
pub struct ModEntry {
    pub filename: String,
    pub enabled: bool,
    pub size: u64,
    pub mod_id: String,
    pub name: String,
    pub version: String,
    pub authors: String,
    /// Какой loader требует сам jar: "forge" | "fabric" | "neoforge" | ""
    pub loader: String,
    /// Что мод пишет про совместимость с версией MC (как есть, строкой).
    pub mc_range: String,
    pub source: String,
    /// None = метаданных не хватило, чтобы судить.
    pub compatible: Option<bool>,
    pub warning: Option<String>,
}

#[derive(Debug, Clone, Serialize)]
pub struct ResourcePackEntry {
    pub filename: String,
    pub enabled: bool,
    pub size: u64,
    pub name: String,
    pub description: String,
    pub pack_format: Option<i64>,
    pub source: String,
}

// --- Моды -------------------------------------------------------------

fn strip_disabled(name: &str) -> (String, bool) {
    match name.strip_suffix(DISABLED_SUFFIX) {
        Some(base) => (base.to_string(), false),
        None => (name.to_string(), true),
    }
}

pub fn list_mods(version_id: &str, mc_version: &str, loader: LoaderKind) -> Vec<ModEntry> {
    let dir = paths::mods_dir(version_id);
    let config = load_config(version_id);
    let mut out: Vec<ModEntry> = Vec::new();

    let Ok(entries) = std::fs::read_dir(&dir) else {
        return out;
    };
    for entry in entries.flatten() {
        let path = entry.path();
        if !path.is_file() {
            continue;
        }
        let Some(raw_name) = path.file_name().and_then(|n| n.to_str()) else {
            continue;
        };
        let (filename, enabled) = strip_disabled(raw_name);
        if !filename.to_ascii_lowercase().ends_with(".jar") {
            continue;
        }

        let meta = read_jar_metadata(&path).unwrap_or_default();
        let size = entry.metadata().map(|m| m.len()).unwrap_or(0);
        let record = config.mods.iter().find(|m| m.filename == filename);

        let version = if meta.version.is_empty() {
            record
                .map(|r| r.version.clone())
                .filter(|v| !v.is_empty())
                .unwrap_or_else(|| version_from_filename(&filename))
        } else {
            meta.version.clone()
        };

        let (compatible, warning) = judge(&meta, mc_version, loader);

        out.push(ModEntry {
            filename,
            enabled,
            size,
            mod_id: meta.mod_id,
            name: if meta.name.is_empty() {
                record.map(|r| r.name.clone()).unwrap_or_default()
            } else {
                meta.name
            },
            version,
            authors: meta.authors,
            loader: meta.loader,
            mc_range: meta.mc_range,
            source: record
                .map(|r| r.source.clone())
                .filter(|s| !s.is_empty())
                .unwrap_or_else(|| "local".to_string()),
            compatible,
            warning,
        });
    }
    out.sort_by(|a, b| a.filename.to_lowercase().cmp(&b.filename.to_lowercase()));
    out
}

/// Совместим ли мод с профилем. Ошибаться в сторону «не знаю» здесь полезнее,
/// чем пугать пользователя красным на каждом моде без метаданных.
fn judge(meta: &JarMetadata, mc_version: &str, loader: LoaderKind) -> (Option<bool>, Option<String>) {
    if !meta.loader.is_empty() {
        let expected = match loader {
            LoaderKind::Forge => "forge",
            LoaderKind::Fabric => "fabric",
            LoaderKind::Vanilla => "",
        };
        // NeoForge-моды в Forge-профиле не заработают, и наоборот.
        if expected.is_empty() {
            return (
                Some(false),
                Some("Профиль без модлоадера — мод не загрузится.".to_string()),
            );
        }
        if meta.loader != expected && !(meta.loader == "neoforge" && expected == "forge") {
            return (
                Some(false),
                Some(format!(
                    "Мод собран под {}, а профиль — {}.",
                    meta.loader, expected
                )),
            );
        }
        if meta.loader == "neoforge" && expected == "forge" {
            return (
                Some(false),
                Some("Это мод для NeoForge, обычный Forge его не загрузит.".to_string()),
            );
        }
    }

    if meta.mc_range.is_empty() || mc_version.is_empty() {
        return (None, None);
    }
    match version_matches(mc_version, &meta.mc_range) {
        Some(true) => (Some(true), None),
        Some(false) => (
            Some(false),
            Some(format!(
                "Мод заявляет Minecraft {}, а профиль — {mc_version}.",
                meta.mc_range
            )),
        ),
        None => (None, None),
    }
}

pub fn toggle_mod(version_id: &str, filename: &str, enabled: bool) -> anyhow::Result<()> {
    let dir = paths::mods_dir(version_id);
    let base = sanitize_filename(filename)?;
    let on = dir.join(&base);
    let off = dir.join(format!("{base}{DISABLED_SUFFIX}"));

    if enabled {
        if off.exists() {
            std::fs::rename(&off, &on)?;
        } else if !on.exists() {
            anyhow::bail!("файл мода {base} не найден");
        }
    } else if on.exists() {
        std::fs::rename(&on, &off)?;
    } else if !off.exists() {
        anyhow::bail!("файл мода {base} не найден");
    }

    let mut config = load_config(version_id);
    if let Some(record) = config.mods.iter_mut().find(|m| m.filename == base) {
        record.enabled = enabled;
    }
    save_config(version_id, &config)
}

pub fn remove_mod(version_id: &str, filename: &str) -> anyhow::Result<()> {
    let dir = paths::mods_dir(version_id);
    let base = sanitize_filename(filename)?;
    let mut removed = false;
    for candidate in [dir.join(&base), dir.join(format!("{base}{DISABLED_SUFFIX}"))] {
        if candidate.exists() {
            std::fs::remove_file(&candidate)?;
            removed = true;
        }
    }
    let mut config = load_config(version_id);
    config.mods.retain(|m| m.filename != base);
    save_config(version_id, &config)?;
    if !removed {
        anyhow::bail!("файл мода {base} не найден");
    }
    Ok(())
}

/// Копирует локальный jar в mods/ профиля.
pub fn add_local_mod(version_id: &str, source: &Path) -> anyhow::Result<String> {
    let dir = paths::mods_dir(version_id);
    std::fs::create_dir_all(&dir)?;
    let name = source
        .file_name()
        .and_then(|n| n.to_str())
        .ok_or_else(|| anyhow::anyhow!("непонятное имя файла"))?;
    if !name.to_ascii_lowercase().ends_with(".jar") {
        anyhow::bail!("мод — это .jar, а тут {name}");
    }
    let base = sanitize_filename(name)?;
    let dest = dir.join(&base);
    std::fs::copy(source, &dest)?;

    let meta = read_jar_metadata(&dest).unwrap_or_default();
    let mut config = load_config(version_id);
    config.mods.retain(|m| m.filename != base);
    config.mods.push(ModRecord {
        id: meta.mod_id,
        filename: base.clone(),
        enabled: true,
        version: meta.version,
        source: "local".to_string(),
        sha1: sha1_file(&dest).unwrap_or_default(),
        name: meta.name,
        url: String::new(),
        size: std::fs::metadata(&dest).map(|m| m.len()).unwrap_or(0),
    });
    save_config(version_id, &config)?;
    Ok(base)
}

/// Перед запуском: если файл из mods.json пропал с диска, тихо доставляем его
/// обратно по сохранённой ссылке. Возвращает, что пришлось докачать.
pub async fn restore_missing(version_id: &str) -> anyhow::Result<Vec<String>> {
    let config = load_config(version_id);
    let mut restored: Vec<String> = Vec::new();

    for (record, dir) in config
        .mods
        .iter()
        .map(|m| (m, paths::mods_dir(version_id)))
        .chain(
            config
                .resourcepacks
                .iter()
                .map(|m| (m, paths::resourcepacks_dir(version_id))),
        )
    {
        let base = dir.join(&record.filename);
        let disabled = dir.join(format!("{}{DISABLED_SUFFIX}", record.filename));
        if base.exists() || disabled.exists() {
            continue;
        }
        if record.url.is_empty() {
            continue; // локальный файл — восстановить нечем
        }
        crate::net::ensure_download_url(&record.url)?;
        let sha1 = Some(record.sha1.as_str()).filter(|s| !s.is_empty());
        crate::version_manager::download_verified(&record.url, &base, sha1, None).await?;
        restored.push(record.filename.clone());
    }
    Ok(restored)
}

// --- Ресурс-паки ------------------------------------------------------
//
// С паками проще: модлоадер им не нужен, совместимость почти всегда есть.
// Единственная тонкость — «включён» для пака означает не имя файла, а строку
// resourcePacks:[...] в options.txt, потому что порядок в этом списке задаёт
// приоритет паков. Поэтому здесь не переименовываем файлы, а правим options.txt.

pub fn list_resourcepacks(version_id: &str) -> Vec<ResourcePackEntry> {
    let dir = paths::resourcepacks_dir(version_id);
    let config = load_config(version_id);
    let enabled = read_enabled_packs(version_id);
    let mut out = Vec::new();

    let Ok(entries) = std::fs::read_dir(&dir) else {
        return out;
    };
    for entry in entries.flatten() {
        let path = entry.path();
        let Some(name) = path.file_name().and_then(|n| n.to_str()).map(String::from) else {
            continue;
        };
        let is_zip = path.is_file() && name.to_ascii_lowercase().ends_with(".zip");
        let is_folder_pack = path.is_dir() && path.join("pack.mcmeta").exists();
        if !is_zip && !is_folder_pack {
            continue;
        }
        let meta = read_pack_meta(&path).unwrap_or_default();
        out.push(ResourcePackEntry {
            enabled: enabled.iter().any(|e| pack_key(e) == name),
            size: entry.metadata().map(|m| m.len()).unwrap_or(0),
            name: name.clone(),
            description: meta.description,
            pack_format: meta.pack_format,
            source: config
                .resourcepacks
                .iter()
                .find(|r| r.filename == name)
                .map(|r| r.source.clone())
                .unwrap_or_else(|| "local".to_string()),
            filename: name,
        });
    }
    out.sort_by(|a, b| a.filename.to_lowercase().cmp(&b.filename.to_lowercase()));
    out
}

/// В options.txt паки пишутся как "file/pack.zip" (1.13+) или просто "pack.zip".
fn pack_key(entry: &str) -> String {
    entry
        .trim_matches('"')
        .trim_start_matches("file/")
        .to_string()
}

pub fn read_enabled_packs(version_id: &str) -> Vec<String> {
    let Ok(text) = std::fs::read_to_string(paths::options_file(version_id)) else {
        return Vec::new();
    };
    for line in text.lines() {
        if let Some(rest) = line.strip_prefix("resourcePacks:") {
            let inner = rest.trim().trim_start_matches('[').trim_end_matches(']');
            return inner
                .split(',')
                .map(|s| s.trim().trim_matches('"').to_string())
                .filter(|s| !s.is_empty())
                .collect();
        }
    }
    Vec::new()
}

pub fn toggle_resourcepack(version_id: &str, filename: &str, enabled: bool) -> anyhow::Result<()> {
    let base = sanitize_filename(filename)?;
    let dir = paths::resourcepacks_dir(version_id);
    if enabled && !dir.join(&base).exists() {
        anyhow::bail!("ресурс-пак {base} не найден");
    }

    let mut packs = read_enabled_packs(version_id);
    packs.retain(|p| pack_key(p) != base);
    if enabled {
        // В конец: последний в списке применяется поверх остальных.
        packs.push(format!("file/{base}"));
    }
    write_enabled_packs(version_id, &packs)
}

fn write_enabled_packs(version_id: &str, packs: &[String]) -> anyhow::Result<()> {
    let path = paths::options_file(version_id);
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let list = packs
        .iter()
        .map(|p| format!("\"{}\"", p.trim_matches('"')))
        .collect::<Vec<_>>()
        .join(",");
    let new_line = format!("resourcePacks:[{list}]");

    let existing = std::fs::read_to_string(&path).unwrap_or_default();
    let mut lines: Vec<String> = existing.lines().map(String::from).collect();
    match lines.iter_mut().find(|l| l.starts_with("resourcePacks:")) {
        Some(line) => *line = new_line,
        None => lines.push(new_line),
    }
    // Игра сама перепишет файл при выходе; наша задача не потерять остальные
    // настройки пользователя.
    std::fs::write(&path, format!("{}\n", lines.join("\n")))?;
    Ok(())
}

pub fn remove_resourcepack(version_id: &str, filename: &str) -> anyhow::Result<()> {
    let base = sanitize_filename(filename)?;
    let path = paths::resourcepacks_dir(version_id).join(&base);
    if path.is_dir() {
        std::fs::remove_dir_all(&path)?;
    } else if path.exists() {
        std::fs::remove_file(&path)?;
    } else {
        anyhow::bail!("ресурс-пак {base} не найден");
    }
    let _ = toggle_resourcepack(version_id, &base, false);
    let mut config = load_config(version_id);
    config.resourcepacks.retain(|r| r.filename != base);
    save_config(version_id, &config)
}

pub fn add_local_resourcepack(version_id: &str, source: &Path) -> anyhow::Result<String> {
    let dir = paths::resourcepacks_dir(version_id);
    std::fs::create_dir_all(&dir)?;
    let name = source
        .file_name()
        .and_then(|n| n.to_str())
        .ok_or_else(|| anyhow::anyhow!("непонятное имя файла"))?;
    if !name.to_ascii_lowercase().ends_with(".zip") {
        anyhow::bail!("ресурс-пак — это .zip, а тут {name}");
    }
    let base = sanitize_filename(name)?;
    std::fs::copy(source, dir.join(&base))?;

    let mut config = load_config(version_id);
    config.resourcepacks.retain(|r| r.filename != base);
    config.resourcepacks.push(ModRecord {
        filename: base.clone(),
        enabled: false,
        source: "local".to_string(),
        ..Default::default()
    });
    save_config(version_id, &config)?;
    Ok(base)
}

// --- Метаданные из jar ------------------------------------------------

#[derive(Debug, Clone, Default)]
pub struct JarMetadata {
    pub mod_id: String,
    pub name: String,
    pub version: String,
    pub authors: String,
    pub loader: String,
    pub mc_range: String,
}

pub fn read_jar_metadata(path: &Path) -> anyhow::Result<JarMetadata> {
    let file = std::fs::File::open(path)?;
    let mut archive = zip::ZipArchive::new(file)?;

    if let Ok(mut entry) = archive.by_name("fabric.mod.json") {
        let mut text = String::new();
        entry.read_to_string(&mut text)?;
        drop(entry);
        return Ok(parse_fabric_mod_json(&text));
    }
    for (name, loader) in [
        ("META-INF/mods.toml", "forge"),
        ("META-INF/neoforge.mods.toml", "neoforge"),
    ] {
        if let Ok(mut entry) = archive.by_name(name) {
            let mut text = String::new();
            entry.read_to_string(&mut text)?;
            drop(entry);
            let mut meta = parse_mods_toml(&text);
            meta.loader = loader.to_string();
            if meta.version.contains("${") {
                meta.version.clear(); // ${file.jarVersion} подставляет Gradle
            }
            return Ok(meta);
        }
    }
    // Forge 1.12 и старше
    if let Ok(mut entry) = archive.by_name("mcmod.info") {
        let mut text = String::new();
        entry.read_to_string(&mut text)?;
        drop(entry);
        return Ok(parse_mcmod_info(&text));
    }
    Ok(JarMetadata::default())
}

fn parse_fabric_mod_json(text: &str) -> JarMetadata {
    let value: serde_json::Value = match serde_json::from_str(text) {
        Ok(v) => v,
        Err(_) => return JarMetadata::default(),
    };
    let authors = match value.get("authors") {
        Some(serde_json::Value::Array(items)) => items
            .iter()
            .filter_map(|i| {
                i.as_str()
                    .map(String::from)
                    .or_else(|| i.get("name").and_then(|n| n.as_str()).map(String::from))
            })
            .collect::<Vec<_>>()
            .join(", "),
        _ => String::new(),
    };
    let mc_range = value
        .pointer("/depends/minecraft")
        .map(|v| match v {
            serde_json::Value::String(s) => s.clone(),
            serde_json::Value::Array(items) => items
                .iter()
                .filter_map(|i| i.as_str())
                .collect::<Vec<_>>()
                .join(" или "),
            other => other.to_string(),
        })
        .unwrap_or_default();

    JarMetadata {
        mod_id: str_field(&value, "id"),
        name: str_field(&value, "name"),
        version: str_field(&value, "version"),
        authors,
        loader: "fabric".to_string(),
        mc_range,
    }
}

fn str_field(value: &serde_json::Value, key: &str) -> String {
    value
        .get(key)
        .and_then(|v| v.as_str())
        .unwrap_or_default()
        .to_string()
}

/// Мини-парсер mods.toml. Полноценный TOML тут не нужен: нам интересны
/// несколько скалярных ключей из первой секции [[mods]] и versionRange
/// зависимости от minecraft.
fn parse_mods_toml(text: &str) -> JarMetadata {
    let mut meta = JarMetadata::default();
    let mut section: String;
    let mut in_first_mod = false;
    let mut mods_seen = 0;
    let mut minecraft_dep = false;

    for raw in text.lines() {
        let line = raw.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        if line.starts_with('[') {
            section = line.trim_matches(|c| c == '[' || c == ']').to_string();
            if section == "mods" {
                mods_seen += 1;
                in_first_mod = mods_seen == 1;
            } else {
                in_first_mod = false;
            }
            minecraft_dep = section.starts_with("dependencies.");
            continue;
        }
        let Some((key, value)) = line.split_once('=') else {
            continue;
        };
        let key = key.trim();
        let value = value.trim().trim_matches('"').trim_matches('\'').to_string();

        if in_first_mod {
            match key {
                "modId" => meta.mod_id = value,
                "version" => meta.version = value,
                "displayName" => meta.name = value,
                "authors" | "credits" if meta.authors.is_empty() => meta.authors = value,
                _ => {}
            }
        } else if minecraft_dep {
            if key == "modId" && value != "minecraft" {
                minecraft_dep = false;
            } else if key == "versionRange" && meta.mc_range.is_empty() {
                meta.mc_range = value;
            }
        }
    }
    meta
}

fn parse_mcmod_info(text: &str) -> JarMetadata {
    let value: serde_json::Value = match serde_json::from_str(text) {
        Ok(v) => v,
        Err(_) => return JarMetadata::default(),
    };
    let first = value
        .as_array()
        .and_then(|a| a.first().cloned())
        .or_else(|| value.pointer("/modList/0").cloned())
        .unwrap_or(serde_json::Value::Null);
    JarMetadata {
        mod_id: str_field(&first, "modid"),
        name: str_field(&first, "name"),
        version: str_field(&first, "version"),
        authors: match first.get("authorList") {
            Some(serde_json::Value::Array(items)) => items
                .iter()
                .filter_map(|i| i.as_str())
                .collect::<Vec<_>>()
                .join(", "),
            _ => String::new(),
        },
        loader: "forge".to_string(),
        mc_range: str_field(&first, "mcversion"),
    }
}

#[derive(Debug, Default)]
struct PackMeta {
    description: String,
    pack_format: Option<i64>,
}

fn read_pack_meta(path: &Path) -> anyhow::Result<PackMeta> {
    let text = if path.is_dir() {
        std::fs::read_to_string(path.join("pack.mcmeta"))?
    } else {
        let file = std::fs::File::open(path)?;
        let mut archive = zip::ZipArchive::new(file)?;
        let mut entry = archive.by_name("pack.mcmeta")?;
        let mut text = String::new();
        entry.read_to_string(&mut text)?;
        text
    };
    let value: serde_json::Value = serde_json::from_str(&text)?;
    Ok(PackMeta {
        description: value
            .pointer("/pack/description")
            .map(|d| match d {
                serde_json::Value::String(s) => s.clone(),
                other => other.to_string(),
            })
            .unwrap_or_default(),
        pack_format: value.pointer("/pack/pack_format").and_then(|v| v.as_i64()),
    })
}

// --- Мелочи -----------------------------------------------------------

/// Имя файла приходит из фронтенда. Без этой проверки "../../accounts.json"
/// в remove_mod удалил бы что-нибудь интересное.
pub fn sanitize_filename(raw: &str) -> anyhow::Result<String> {
    let name = raw.trim().trim_end_matches(DISABLED_SUFFIX);
    if name.is_empty()
        || name.contains('/')
        || name.contains('\\')
        || name.contains("..")
        || Path::new(name).file_name().and_then(|n| n.to_str()) != Some(name)
    {
        anyhow::bail!("недопустимое имя файла: {raw}");
    }
    Ok(name.to_string())
}

pub fn sha1_file(path: &Path) -> anyhow::Result<String> {
    let bytes = std::fs::read(path)?;
    let mut hasher = Sha1::new();
    hasher.update(&bytes);
    Ok(format!("{:x}", hasher.finalize()))
}

pub fn version_from_filename(filename: &str) -> String {
    // jei-1.20.1-15.2.0.27.jar → 15.2.0.27
    let stem = filename.trim_end_matches(".jar");
    stem.rsplit('-')
        .find(|part| part.chars().next().is_some_and(|c| c.is_ascii_digit()))
        .unwrap_or("")
        .to_string()
}

/// Подходит ли версия MC под то, что заявил мод. None = разобрать не смогли.
///
/// Поддерживаем два формата: maven-диапазон Forge (`[1.20.1,1.21)`) и
/// semver-выражения Fabric (`>=1.20.1 <1.21`, `1.20.x`, `~1.20.1`, `*`).
pub fn version_matches(mc_version: &str, range: &str) -> Option<bool> {
    let range = range.trim();
    if range.is_empty() || range == "*" {
        return Some(true);
    }
    let target = parse_semver(mc_version)?;

    if range.starts_with('[') || range.starts_with('(') {
        let (open, close) = (
            range.starts_with('['),
            range.ends_with(']'),
        );
        let inner = range.trim_matches(|c: char| "[()]".contains(c));
        let mut bounds = inner.splitn(2, ',');
        let low = bounds.next().unwrap_or("").trim();
        let high = bounds.next().unwrap_or("").trim();
        if !low.is_empty() {
            let low_v = parse_semver(low)?;
            if target < low_v || (target == low_v && !open) {
                return Some(false);
            }
        }
        if !high.is_empty() {
            let high_v = parse_semver(high)?;
            if target > high_v || (target == high_v && !close) {
                return Some(false);
            }
        }
        return Some(true);
    }

    let mut verdict = true;
    for token in range.split_whitespace() {
        let token = token.trim();
        let ok = if let Some(rest) = token.strip_prefix(">=") {
            parse_semver(rest).map(|v| target >= v)
        } else if let Some(rest) = token.strip_prefix("<=") {
            parse_semver(rest).map(|v| target <= v)
        } else if let Some(rest) = token.strip_prefix('>') {
            parse_semver(rest).map(|v| target > v)
        } else if let Some(rest) = token.strip_prefix('<') {
            parse_semver(rest).map(|v| target < v)
        } else if let Some(rest) = token.strip_prefix('~').or_else(|| token.strip_prefix('^')) {
            // ~1.20.1 = вся ветка 1.20.*
            parse_semver(rest).map(|v| target.0 == v.0 && target.1 == v.1)
        } else if token.ends_with(".x") || token.ends_with(".*") {
            parse_semver(token.trim_end_matches(|c: char| "x*.".contains(c)))
                .map(|v| target.0 == v.0 && target.1 == v.1)
        } else {
            parse_semver(token).map(|v| target == v)
        };
        match ok {
            Some(true) => {}
            Some(false) => verdict = false,
            None => return None,
        }
    }
    Some(verdict)
}

fn parse_semver(raw: &str) -> Option<(u32, u32, u32)> {
    let cleaned: String = raw
        .trim()
        .chars()
        .take_while(|c| c.is_ascii_digit() || *c == '.')
        .collect();
    if cleaned.is_empty() {
        return None;
    }
    let mut parts = cleaned.split('.').map(|p| p.parse::<u32>().unwrap_or(0));
    Some((
        parts.next().unwrap_or(0),
        parts.next().unwrap_or(0),
        parts.next().unwrap_or(0),
    ))
}

/// Путь к папке модов профиля — UI показывает его в подсказке.
pub fn mods_dir_display(version_id: &str) -> PathBuf {
    paths::mods_dir(version_id)
}

//! Один общий reqwest-клиент на весь процесс.
//!
//! Раньше каждый вызов делал `reqwest::Client::new()`, то есть на каждый из
//! ~2500 файлов ассетов поднимался новый пул соединений и новый TLS-хендшейк.
//! Один переиспользуемый клиент с keep-alive ускоряет установку версии в разы.

use std::sync::OnceLock;
use std::time::Duration;

pub fn client() -> &'static reqwest::Client {
    static CLIENT: OnceLock<reqwest::Client> = OnceLock::new();
    CLIENT.get_or_init(|| {
        reqwest::Client::builder()
            .user_agent(concat!("VitaLauncher/", env!("CARGO_PKG_VERSION")))
            .connect_timeout(Duration::from_secs(15))
            .timeout(Duration::from_secs(180))
            .pool_max_idle_per_host(16)
            .build()
            .unwrap_or_default()
    })
}

/// Разрешаем ходить только по https и только на домены Mojang/Microsoft.
/// URL версии приходит из фронтенда, так что проверка не лишняя.
pub fn ensure_trusted_url(url: &str) -> anyhow::Result<()> {
    let parsed = reqwest::Url::parse(url).map_err(|e| anyhow::anyhow!("некорректный URL: {e}"))?;
    if parsed.scheme() != "https" {
        anyhow::bail!("разрешены только https-ссылки");
    }
    let host = parsed.host_str().unwrap_or_default().to_ascii_lowercase();
    const ALLOWED: [&str; 6] = [
        "mojang.com",
        "minecraft.net",
        "minecraftservices.com",
        "microsoftonline.com",
        "xboxlive.com",
        "microsoft.com",
    ];
    let ok = ALLOWED
        .iter()
        .any(|d| host == *d || host.ends_with(&format!(".{d}")));
    if !ok {
        anyhow::bail!("недоверенный домен: {host}");
    }
    Ok(())
}

/// Домены, откуда можно тянуть файлы модов, ресурс-паков и модлоадеров.
///
/// Отдельный список от `ensure_trusted_url`: там разрешены только Mojang и
/// Microsoft (по этим адресам ходят токены), а здесь качаются jar-ы. Ссылки на
/// файлы приходят из API CurseForge/Modrinth, то есть снаружи, поэтому
/// проверять их обязательно — иначе «поставь мод» превращается в «скачай что
/// угодно откуда угодно и запусти в JVM с правами пользователя».
pub fn ensure_download_url(url: &str) -> anyhow::Result<()> {
    let parsed = reqwest::Url::parse(url).map_err(|e| anyhow::anyhow!("некорректный URL: {e}"))?;
    if parsed.scheme() != "https" {
        anyhow::bail!("разрешены только https-ссылки");
    }
    let host = parsed.host_str().unwrap_or_default().to_ascii_lowercase();
    const ALLOWED: [&str; 13] = [
        // Mojang
        "mojang.com",
        "minecraft.net",
        // Forge / NeoForge
        "minecraftforge.net",
        "forgecdn.net",
        "neoforged.net",
        // Fabric
        "fabricmc.net",
        // Modrinth
        "modrinth.com",
        // CurseForge
        "curseforge.com",
        // Зеркала maven, на которые ссылаются профили модлоадеров
        "maven.apache.org",
        "repo1.maven.org",
        "sonatype.org",
        "jitpack.io",
        "githubusercontent.com",
    ];
    let ok = ALLOWED
        .iter()
        .any(|d| host == *d || host.ends_with(&format!(".{d}")));
    if !ok {
        anyhow::bail!(
            "домен {host} не в списке разрешённых для загрузки файлов. \
             Файл можно поставить вручную кнопкой «Из файла»."
        );
    }
    Ok(())
}

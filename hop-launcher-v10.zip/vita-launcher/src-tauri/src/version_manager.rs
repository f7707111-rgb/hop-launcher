//! Список версий, метаданные версии, установка файлов и кэш установки.
//!
//! Ключевые правки этого этапа:
//!  * install_and_launch качает файлы РОВНО одной выбранной версии. Манифест
//!    (get_version_manifest) грузится только для выпадающего списка и никаких
//!    загрузок не инициирует;
//!  * появился маркер установки .vita-installed.json: если версия уже собрана
//!    и структура на месте, повторный "Играть" не перекачивает ничего;
//!  * загрузка идёт параллельно (12 потоков) с одним общим http-клиентом,
//!    раньше ~2500 ассетов качались строго по одному;
//!  * поддержаны natives через downloads.classifiers + карту natives
//!    (версии 1.6-1.18 без этого не получали LWJGL и падали при старте);
//!  * пути библиотек берутся из downloads.artifact.path, а не угадываются из
//!    maven-имени (ломалось на именах с классификатором вида
//!    org.lwjgl:lwjgl:3.3.1:natives-windows);
//!  * assetIndex теперь Option — очень старые версии (pre-1.6) его не имеют;
//!  * legacy/virtual ассеты раскладываются в assets/virtual/<index> и
//!    resources/, иначе в старых версиях нет звуков и языков.

use futures_util::stream::{self, StreamExt};
use serde::{Deserialize, Serialize};
use sha1::{Digest, Sha1};
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, OnceLock};
use tokio::io::AsyncWriteExt;

use crate::net;
use crate::paths::safe_component;

const VERSION_MANIFEST_URL: &str =
    "https://launchermeta.mojang.com/mc/game/version_manifest_v2.json";
const RESOURCES_BASE: &str = "https://resources.download.minecraft.net";
const DOWNLOAD_CONCURRENCY: usize = 12;
const DOWNLOAD_RETRIES: u32 = 3;
/// Версия формата маркера установки: увеличивать при смене раскладки файлов,
/// чтобы старые установки пере-проверились.
const MARKER_FORMAT: u32 = 2;
const MARKER_FILE: &str = ".vita-installed.json";

// --- Манифест ---------------------------------------------------------

#[derive(Debug, Deserialize, Serialize, Clone)]
pub struct VersionManifest {
    pub latest: LatestVersions,
    pub versions: Vec<VersionEntry>,
}

#[derive(Debug, Deserialize, Serialize, Clone)]
pub struct LatestVersions {
    pub release: String,
    pub snapshot: String,
}

#[derive(Debug, Deserialize, Serialize, Clone)]
pub struct VersionEntry {
    pub id: String,
    #[serde(rename = "type")]
    pub version_type: String,
    pub url: String,
    #[serde(rename = "releaseTime", default)]
    pub release_time: Option<String>,
}

/// Полный список версий для выпадающего списка. Ничего не скачивает кроме
/// самого манифеста (~250 КБ).
pub async fn fetch_version_manifest() -> anyhow::Result<VersionManifest> {
    let resp = net::client().get(VERSION_MANIFEST_URL).send().await?;
    let status = resp.status();
    let text = resp.text().await?;
    if !status.is_success() {
        anyhow::bail!("не удалось получить список версий: HTTP {}", status.as_u16());
    }
    Ok(serde_json::from_str(&text)?)
}

// --- Метаданные версии ------------------------------------------------

#[derive(Debug, Deserialize, Clone)]
pub struct VersionDetail {
    pub id: String,
    /// У профилей модлоадеров mainClass свой (BootstrapLauncher, KnotClient);
    /// у некоторых промежуточных json его нет вообще — тогда берём из родителя.
    #[serde(rename = "mainClass", default)]
    pub main_class: String,
    /// Профили Forge/Fabric не содержат downloads: client.jar берётся у
    /// родительской ванильной версии (inheritsFrom).
    #[serde(default)]
    pub downloads: Option<VersionDownloads>,
    #[serde(default)]
    pub libraries: Vec<Library>,
    /// У версий до 1.6 индекса ассетов нет вообще.
    #[serde(rename = "assetIndex", default)]
    pub asset_index: Option<AssetIndexRef>,
    #[serde(default)]
    pub assets: Option<String>,
    pub arguments: Option<Arguments>,
    /// Версии до 1.13 используют плоскую строку вместо `arguments`.
    #[serde(rename = "minecraftArguments")]
    pub minecraft_arguments: Option<String>,
    #[serde(rename = "javaVersion", default)]
    pub java_version: Option<JavaVersionReq>,
    #[serde(rename = "type", default)]
    pub version_type: Option<String>,
    /// Профиль модлоадера ссылается на ванильную версию, от которой наследует
    /// ассеты, client.jar и большую часть аргументов.
    #[serde(rename = "inheritsFrom", default)]
    pub inherits_from: Option<String>,
    /// Не из JSON: id корневой ванильной версии после разрешения наследования.
    /// Там лежат client.jar и natives, общие для ванили и всех сборок.
    #[serde(skip)]
    pub client_id: String,
}

impl VersionDetail {
    /// client.jar есть только у ванильных версий; у профилей он унаследован.
    pub fn client_download(&self) -> Option<&DownloadInfo> {
        self.downloads.as_ref().map(|d| &d.client)
    }

    /// Тот id, в папке которого лежат client.jar и natives.
    pub fn client_version_id(&self) -> &str {
        if self.client_id.is_empty() {
            &self.id
        } else {
            &self.client_id
        }
    }
}

#[derive(Debug, Deserialize, Clone)]
pub struct JavaVersionReq {
    #[serde(default)]
    pub component: String,
    #[serde(rename = "majorVersion", default)]
    pub major_version: u32,
}

#[derive(Debug, Deserialize, Clone)]
pub struct VersionDownloads {
    pub client: DownloadInfo,
}

#[derive(Debug, Deserialize, Clone)]
pub struct DownloadInfo {
    pub url: String,
    #[serde(default)]
    pub sha1: String,
    #[serde(default)]
    pub size: u64,
    /// Относительный путь внутри /libraries — Mojang его даёт, и он надёжнее
    /// самодельной сборки пути из maven-имени.
    #[serde(default)]
    pub path: Option<String>,
}

#[derive(Debug, Deserialize, Clone)]
pub struct AssetIndexRef {
    pub id: String,
    pub url: String,
    #[serde(default)]
    pub sha1: String,
}

#[derive(Debug, Deserialize, Clone)]
pub struct Library {
    pub name: String,
    pub downloads: Option<LibraryDownloads>,
    /// Fabric и старый Forge описывают библиотеки без downloads: только
    /// maven-имя и база репозитория. Путь и ссылку собираем сами.
    #[serde(default)]
    pub url: Option<String>,
    pub rules: Option<Vec<Rule>>,
    /// Старая схема natives: карта os -> ключ в classifiers.
    #[serde(default)]
    pub natives: Option<HashMap<String, String>>,
}

#[derive(Debug, Deserialize, Clone)]
pub struct LibraryDownloads {
    pub artifact: Option<DownloadInfo>,
    #[serde(default)]
    pub classifiers: Option<HashMap<String, DownloadInfo>>,
}

#[derive(Debug, Deserialize, Clone)]
pub struct Rule {
    pub action: String,
    pub os: Option<OsRule>,
}

#[derive(Debug, Deserialize, Clone)]
pub struct OsRule {
    pub name: Option<String>,
}

#[derive(Debug, Deserialize, Clone)]
pub struct Arguments {
    #[serde(default)]
    pub game: Vec<serde_json::Value>,
    #[serde(default)]
    pub jvm: Vec<serde_json::Value>,
}

pub fn current_os_key() -> &'static str {
    if cfg!(target_os = "windows") {
        "windows"
    } else if cfg!(target_os = "macos") {
        "osx"
    } else {
        "linux"
    }
}

/// Разрешает ли набор правил использовать библиотеку/аргумент на этой ОС.
/// Отсутствие правил = разрешено. Правила по features (demo, custom resolution)
/// разбираются на стороне вызывающего кода.
pub fn rules_allow(rules: &Option<Vec<Rule>>) -> bool {
    let Some(rules) = rules else { return true };
    if rules.is_empty() {
        return true;
    }
    let current = current_os_key();
    let mut allowed = false;
    for rule in rules {
        let os_matches = match &rule.os {
            Some(os) => os.name.as_deref().map(|n| n == current).unwrap_or(true),
            None => true,
        };
        if os_matches {
            allowed = rule.action == "allow";
        }
    }
    allowed
}

// --- Пути -------------------------------------------------------------

pub fn version_dir(game_dir: &Path, version_id: &str) -> PathBuf {
    game_dir
        .join("versions")
        .join(safe_component(version_id))
}

pub fn client_jar_path(game_dir: &Path, version_id: &str) -> PathBuf {
    let id = safe_component(version_id);
    version_dir(game_dir, version_id).join(format!("{id}.jar"))
}

pub fn version_json_path(game_dir: &Path, version_id: &str) -> PathBuf {
    let id = safe_component(version_id);
    version_dir(game_dir, version_id).join(format!("{id}.json"))
}

pub fn natives_dir(game_dir: &Path, version_id: &str) -> PathBuf {
    version_dir(game_dir, version_id).join("natives")
}

pub fn libraries_dir(game_dir: &Path) -> PathBuf {
    game_dir.join("libraries")
}

pub fn assets_dir(game_dir: &Path) -> PathBuf {
    game_dir.join("assets")
}

pub fn asset_index_path(game_dir: &Path, index_id: &str) -> PathBuf {
    assets_dir(game_dir)
        .join("indexes")
        .join(format!("{}.json", safe_component(index_id)))
}

fn marker_path(game_dir: &Path, version_id: &str) -> PathBuf {
    version_dir(game_dir, version_id).join(MARKER_FILE)
}

/// Читает или скачивает JSON конкретной версии и кладёт его рядом с клиентом
/// (versions/<id>/<id>.json), как это делает официальный лаунчер. Повторный
/// запуск обходится без обращения к сети.
pub async fn load_or_fetch_detail(
    game_dir: &Path,
    version_id: &str,
    url: &str,
) -> anyhow::Result<VersionDetail> {
    let path = version_json_path(game_dir, version_id);
    if let Ok(bytes) = tokio::fs::read(&path).await {
        match serde_json::from_slice::<VersionDetail>(&bytes) {
            Ok(detail) => return Ok(detail),
            Err(err) => eprintln!("[vita] кэш {} не читается ({err}), качаю заново", path.display()),
        }
    }

    if url.trim().is_empty() {
        anyhow::bail!("нет ни локального JSON версии {version_id}, ни ссылки на него");
    }
    net::ensure_trusted_url(url)?;

    let resp = net::client().get(url).send().await?;
    let status = resp.status();
    let text = resp.text().await?;
    if !status.is_success() {
        anyhow::bail!(
            "не удалось скачать метаданные версии {version_id}: HTTP {}",
            status.as_u16()
        );
    }
    let detail: VersionDetail = serde_json::from_str(&text)
        .map_err(|e| anyhow::anyhow!("не удалось разобрать JSON версии {version_id}: {e}"))?;

    if let Some(parent) = path.parent() {
        tokio::fs::create_dir_all(parent).await?;
    }
    tokio::fs::write(&path, text.as_bytes()).await?;
    Ok(detail)
}

// --- Загрузка файлов --------------------------------------------------

fn sha1_hex(bytes: &[u8]) -> String {
    let mut hasher = Sha1::new();
    hasher.update(bytes);
    format!("{:x}", hasher.finalize())
}

/// Скачивает файл, проверяя sha1, и НЕ качает повторно, если на диске уже
/// лежит валидная копия. Это и есть кэш: второй "Играть" по той же версии
/// не тянет из сети ничего.
pub async fn download_verified(
    url: &str,
    dest: &Path,
    expected_sha1: Option<&str>,
    expected_size: Option<u64>,
) -> anyhow::Result<()> {
    if file_is_valid(dest, expected_sha1, expected_size).await {
        return Ok(());
    }

    if let Some(parent) = dest.parent() {
        tokio::fs::create_dir_all(parent).await?;
    }

    let mut last_err: Option<anyhow::Error> = None;
    for attempt in 0..DOWNLOAD_RETRIES {
        match try_download(url, dest, expected_sha1).await {
            Ok(()) => return Ok(()),
            Err(err) => {
                last_err = Some(err);
                tokio::time::sleep(std::time::Duration::from_millis(
                    300 * u64::from(attempt + 1),
                ))
                .await;
            }
        }
    }
    Err(last_err.unwrap_or_else(|| anyhow::anyhow!("не удалось скачать {url}")))
}

async fn file_is_valid(dest: &Path, expected_sha1: Option<&str>, expected_size: Option<u64>) -> bool {
    let Ok(meta) = tokio::fs::metadata(dest).await else {
        return false;
    };
    if !meta.is_file() {
        return false;
    }
    // Размер сверяем первым: он отсекает битые файлы без чтения содержимого.
    if let Some(size) = expected_size {
        if size > 0 && meta.len() != size {
            return false;
        }
    }
    match expected_sha1 {
        Some(expected) if !expected.is_empty() => match tokio::fs::read(dest).await {
            Ok(bytes) => sha1_hex(&bytes).eq_ignore_ascii_case(expected),
            Err(_) => false,
        },
        // Нечем проверять — считаем, что существующий непустой файл годен.
        _ => meta.len() > 0,
    }
}

async fn try_download(url: &str, dest: &Path, expected_sha1: Option<&str>) -> anyhow::Result<()> {
    let resp = net::client().get(url).send().await?;
    let status = resp.status();
    if !status.is_success() {
        anyhow::bail!("HTTP {} при загрузке {url}", status.as_u16());
    }
    let bytes = resp.bytes().await?;

    if let Some(expected) = expected_sha1 {
        if !expected.is_empty() {
            let actual = sha1_hex(&bytes);
            if !actual.eq_ignore_ascii_case(expected) {
                anyhow::bail!("sha1 не совпал для {url} (ожидался {expected}, получен {actual})");
            }
        }
    }

    // Пишем в temp и переименовываем: прерванная загрузка не оставит
    // недокачанный файл, который потом примут за валидный.
    let tmp = dest.with_extension("vitapart");
    {
        let mut file = tokio::fs::File::create(&tmp).await?;
        file.write_all(&bytes).await?;
        file.flush().await?;
    }
    if let Err(err) = tokio::fs::rename(&tmp, dest).await {
        let _ = tokio::fs::remove_file(&tmp).await;
        return Err(err.into());
    }
    Ok(())
}

// --- Разбор библиотек -------------------------------------------------

#[derive(Debug, Clone)]
pub struct LibArtifact {
    pub name: String,
    pub path: PathBuf,
    pub url: String,
    pub sha1: String,
    pub size: u64,
    /// true = это jar с нативными библиотеками из classifiers (старая схема):
    /// его надо распаковать в natives и НЕ класть в classpath.
    pub native_only: bool,
}

/// maven-имя ("group:artifact:version[:classifier]") -> путь внутри /libraries.
pub fn maven_path(name: &str) -> PathBuf {
    let parts: Vec<&str> = name.split(':').collect();
    if parts.len() < 3 {
        return PathBuf::from(safe_component(name));
    }
    let (group, artifact, version) = (parts[0], parts[1], parts[2]);
    let group_path = group.replace('.', "/");
    let file = match parts.get(3) {
        Some(classifier) => format!("{artifact}-{version}-{classifier}.jar"),
        None => format!("{artifact}-{version}.jar"),
    };
    PathBuf::from(format!("{group_path}/{artifact}/{version}/{file}"))
}

fn artifact_relpath(name: &str, info: &DownloadInfo) -> PathBuf {
    match &info.path {
        Some(p) if !p.is_empty() => PathBuf::from(p),
        _ => maven_path(name),
    }
}

/// Ключ в classifiers для нативных библиотек текущей ОС ("natives-windows").
fn native_classifier(lib: &Library) -> Option<String> {
    let natives = lib.natives.as_ref()?;
    let raw = natives.get(current_os_key())?;
    let arch = if cfg!(target_pointer_width = "32") {
        "32"
    } else {
        "64"
    };
    Some(raw.replace("${arch}", arch))
}

/// Библиотека без downloads: путь собираем из maven-имени, ссылку — из базы
/// репозитория (Fabric отдаёт профиль ровно в таком виде).
fn maven_only_artifact(lib: &Library, libraries_dir: &Path) -> Option<LibArtifact> {
    let rel = maven_path(&lib.name);
    let base = lib
        .url
        .clone()
        .or_else(|| default_maven_base(&lib.name))
        .unwrap_or_default();
    let url = if base.is_empty() {
        String::new()
    } else {
        format!(
            "{}/{}",
            base.trim_end_matches('/'),
            rel.to_string_lossy().replace('\\', "/")
        )
    };
    Some(LibArtifact {
        name: lib.name.clone(),
        path: libraries_dir.join(rel),
        url,
        sha1: String::new(),
        size: 0,
        native_only: false,
    })
}

/// Куда идти за библиотекой, если профиль не указал репозиторий.
fn default_maven_base(name: &str) -> Option<String> {
    let group = name.split(':').next().unwrap_or_default();
    let base = match group {
        g if g.starts_with("net.fabricmc") => "https://maven.fabricmc.net",
        g if g.starts_with("net.minecraftforge") || g.starts_with("de.oceanlabs") => {
            "https://maven.minecraftforge.net"
        }
        g if g.starts_with("net.neoforged") => "https://maven.neoforged.net/releases",
        _ => "https://libraries.minecraft.net",
    };
    Some(base.to_string())
}

/// Все файлы библиотек, нужные этой версии на этой ОС.
pub fn resolve_libraries(detail: &VersionDetail, libraries_dir: &Path) -> Vec<LibArtifact> {
    let mut out: Vec<LibArtifact> = Vec::new();
    for lib in &detail.libraries {
        if !rules_allow(&lib.rules) {
            continue;
        }
        let Some(downloads) = &lib.downloads else {
            // Fabric/старый Forge: downloads нет, есть maven-координаты.
            if let Some(artifact) = maven_only_artifact(lib, libraries_dir) {
                out.push(artifact);
            }
            continue;
        };

        if let Some(artifact) = &downloads.artifact {
            out.push(LibArtifact {
                name: lib.name.clone(),
                path: libraries_dir.join(artifact_relpath(&lib.name, artifact)),
                url: artifact.url.clone(),
                sha1: artifact.sha1.clone(),
                size: artifact.size,
                native_only: false,
            });
        }

        // Старая схема natives (1.6-1.18): нужный jar лежит в classifiers.
        if let (Some(classifiers), Some(key)) = (&downloads.classifiers, native_classifier(lib)) {
            if let Some(info) = classifiers.get(&key) {
                let name = format!("{}:{key}", lib.name);
                out.push(LibArtifact {
                    path: libraries_dir.join(artifact_relpath(&name, info)),
                    name,
                    url: info.url.clone(),
                    sha1: info.sha1.clone(),
                    size: info.size,
                    native_only: true,
                });
            }
        }
    }
    out
}

// --- Установка --------------------------------------------------------

#[derive(Debug, Serialize, Deserialize)]
struct InstallMarker {
    format: u32,
    version: String,
    client_sha1: String,
    asset_index: String,
    libraries: usize,
    assets: usize,
    installed_at: i64,
}

#[derive(Debug, Deserialize)]
struct AssetIndexFile {
    #[serde(default)]
    objects: HashMap<String, AssetObject>,
    /// pre-1.6: ассеты надо продублировать в <game>/resources.
    #[serde(rename = "map_to_resources", default)]
    map_to_resources: bool,
    /// 1.6: ассеты надо разложить по именам в assets/virtual/<index>.
    #[serde(rename = "virtual", default)]
    is_virtual: bool,
}

#[derive(Debug, Deserialize, Clone)]
struct AssetObject {
    hash: String,
    #[serde(default)]
    size: u64,
}

struct Job {
    url: String,
    dest: PathBuf,
    sha1: String,
    size: u64,
    label: String,
}

/// Главная точка входа перед запуском: гарантирует, что выбранная (и только
/// выбранная) версия установлена. Возвращает true, если всё уже было на месте
/// и качать ничего не пришлось.
pub async fn ensure_installed<F>(
    game_dir: &Path,
    detail: &VersionDetail,
    on_progress: F,
) -> anyhow::Result<bool>
where
    F: Fn(&str, usize, usize, &str) + Send + Sync,
{
    if marker_valid(game_dir, detail).await {
        on_progress("cached", 1, 1, "версия уже скачана");
        return Ok(true);
    }
    install_version(game_dir, detail, &on_progress).await?;
    Ok(false)
}

/// Быстрая проверка кэша. Полный пересчёт sha1 всех ~2500 ассетов на каждый
/// запуск не нужен: маркер фиксирует, что установка была доведена до конца, а
/// мы дополнительно проверяем ключевые файлы и выборку ассетов.
async fn marker_valid(game_dir: &Path, detail: &VersionDetail) -> bool {
    let Ok(bytes) = tokio::fs::read(marker_path(game_dir, &detail.id)).await else {
        return false;
    };
    let Ok(marker) = serde_json::from_slice::<InstallMarker>(&bytes) else {
        return false;
    };

    let index_id = detail
        .asset_index
        .as_ref()
        .map(|a| a.id.clone())
        .unwrap_or_default();

    let client = detail.client_download();
    let client_sha1 = client.map(|c| c.sha1.clone()).unwrap_or_default();
    let client_size = client.map(|c| c.size).unwrap_or(0);

    if marker.format != MARKER_FORMAT
        || marker.version != detail.id
        || marker.client_sha1 != client_sha1
        || marker.asset_index != index_id
    {
        return false;
    }

    // client.jar: сверяем размер (дёшево) — sha1 уже зафиксирован маркером.
    let jar = client_jar_path(game_dir, detail.client_version_id());
    match tokio::fs::metadata(&jar).await {
        Ok(meta) if client_size == 0 || meta.len() == client_size => {}
        _ => return false,
    }

    // Все библиотеки на месте?
    let libs = resolve_libraries(detail, &libraries_dir(game_dir));
    if libs.len() != marker.libraries {
        return false;
    }
    for lib in &libs {
        if tokio::fs::metadata(&lib.path).await.is_err() {
            return false;
        }
    }

    // Ассеты: индекс + выборочная проверка объектов.
    if let Some(index_ref) = &detail.asset_index {
        let index_path = asset_index_path(game_dir, &index_ref.id);
        let Ok(index_bytes) = tokio::fs::read(&index_path).await else {
            return false;
        };
        let Ok(index) = serde_json::from_slice::<AssetIndexFile>(&index_bytes) else {
            return false;
        };
        if index.objects.len() != marker.assets {
            return false;
        }
        let objects_dir = assets_dir(game_dir).join("objects");
        let step = (index.objects.len() / 20).max(1);
        for (i, obj) in index.objects.values().enumerate() {
            if i % step != 0 {
                continue;
            }
            if obj.hash.len() < 2 {
                continue;
            }
            let path = objects_dir.join(&obj.hash[0..2]).join(&obj.hash);
            if tokio::fs::metadata(&path).await.is_err() {
                return false;
            }
        }
    }

    true
}

/// Скачивает client.jar, библиотеки (+natives) и ассеты ОДНОЙ версии.
/// on_progress(phase, done, total, label) — для прогресс-бара в UI.
pub async fn install_version<F>(
    game_dir: &Path,
    detail: &VersionDetail,
    on_progress: &F,
) -> anyhow::Result<()>
where
    F: Fn(&str, usize, usize, &str) + Send + Sync,
{
    let libs_dir = libraries_dir(game_dir);
    let natives = natives_dir(game_dir, detail.client_version_id());
    let assets = assets_dir(game_dir);

    // 1. Клиентский jar (для профиля Forge/Fabric — родительский ванильный)
    on_progress("client", 0, 1, "client.jar");
    let client_jar = client_jar_path(game_dir, detail.client_version_id());
    if let Some(client) = detail.client_download() {
        download_verified(
            &client.url,
            &client_jar,
            Some(&client.sha1),
            Some(client.size),
        )
        .await?;
    } else if !client_jar.exists() {
        anyhow::bail!(
            "нет client.jar для {} и неизвестно, откуда его брать: \
             в профиле не указан ни downloads, ни inheritsFrom",
            detail.id
        );
    }
    on_progress("client", 1, 1, "client.jar");

    // 2. Библиотеки и natives
    let libs = resolve_libraries(detail, &libs_dir);
    // Часть библиотек Forge installer кладёт сам (в JSON у них пустой url).
    // Их не качаем, но проверяем, что файл действительно появился.
    for lib in libs.iter().filter(|l| l.url.is_empty()) {
        if !lib.path.exists() {
            anyhow::bail!(
                "библиотека {} должна была появиться после установки модлоадера, но её нет ({}). \
                 Переустанови модлоадер.",
                lib.name,
                lib.path.display()
            );
        }
    }
    let lib_jobs: Vec<Job> = libs
        .iter()
        .filter(|lib| !lib.url.is_empty())
        .map(|lib| Job {
            url: lib.url.clone(),
            dest: lib.path.clone(),
            sha1: lib.sha1.clone(),
            size: lib.size,
            label: lib.name.clone(),
        })
        .collect();
    run_jobs("libraries", lib_jobs, on_progress).await?;

    // Нативные jar-ы распаковываем в versions/<id>/natives.
    tokio::fs::create_dir_all(&natives).await?;
    for lib in libs.iter().filter(|l| l.native_only || l.name.contains("natives")) {
        if lib.path.exists() {
            if let Err(err) = extract_natives(&lib.path, &natives) {
                eprintln!("[vita] не удалось распаковать natives {}: {err}", lib.name);
            }
        }
    }

    // 3. Ассеты
    if let Some(index_ref) = &detail.asset_index {
        on_progress("assets", 0, 1, "индекс ассетов");
        let index_path = asset_index_path(game_dir, &index_ref.id);
        download_verified(
            &index_ref.url,
            &index_path,
            Some(&index_ref.sha1),
            None,
        )
        .await?;

        let index_bytes = tokio::fs::read(&index_path).await?;
        let index: AssetIndexFile = serde_json::from_slice(&index_bytes)?;
        let objects_dir = assets.join("objects");

        let asset_jobs: Vec<Job> = index
            .objects
            .values()
            .filter(|obj| obj.hash.len() >= 2)
            .map(|obj| Job {
                url: format!("{RESOURCES_BASE}/{}/{}", &obj.hash[0..2], obj.hash),
                dest: objects_dir.join(&obj.hash[0..2]).join(&obj.hash),
                sha1: obj.hash.clone(),
                size: obj.size,
                label: "ассеты".to_string(),
            })
            .collect();
        run_jobs("assets", asset_jobs, on_progress).await?;

        // Старые версии читают ассеты по именам файлов, а не по хэшам.
        if index.is_virtual || index.map_to_resources {
            let target = if index.map_to_resources {
                game_dir.join("resources")
            } else {
                assets.join("virtual").join(safe_component(&index_ref.id))
            };
            on_progress("assets", 0, 1, "раскладка legacy-ассетов");
            materialize_legacy_assets(&index, &objects_dir, &target).await?;
        }
    }

    write_marker(game_dir, detail, libs.len()).await?;
    on_progress("done", 1, 1, "готово");
    Ok(())
}

/// Параллельная загрузка пачки файлов с прогрессом.
async fn run_jobs<F>(phase: &str, jobs: Vec<Job>, on_progress: &F) -> anyhow::Result<()>
where
    F: Fn(&str, usize, usize, &str) + Send + Sync,
{
    // Один и тот же файл может встречаться в списке дважды (например,
    // одинаковые по содержимому ассеты с разными именами делят hash).
    // Без дедупликации две задачи писали бы один и тот же временный файл.
    let jobs: Vec<Job> = {
        let mut seen: std::collections::HashSet<PathBuf> = std::collections::HashSet::new();
        jobs.into_iter().filter(|job| seen.insert(job.dest.clone())).collect()
    };

    let total = jobs.len();
    if total == 0 {
        return Ok(());
    }
    on_progress(phase, 0, total, "подготовка");

    let done = Arc::new(AtomicUsize::new(0));
    let progress = on_progress;

    let mut stream = stream::iter(jobs.into_iter().map(|job| {
        let done = Arc::clone(&done);
        async move {
            download_verified(
                &job.url,
                &job.dest,
                Some(job.sha1.as_str()).filter(|s| !s.is_empty()),
                Some(job.size).filter(|s| *s > 0),
            )
            .await?;
            let n = done.fetch_add(1, Ordering::SeqCst) + 1;
            // Не спамим событиями на каждый файл — WebView этого не любит.
            if n == total || n % 10 == 0 {
                progress(phase, n, total, &job.label);
            }
            Ok::<(), anyhow::Error>(())
        }
    }))
    .buffer_unordered(DOWNLOAD_CONCURRENCY);

    while let Some(result) = stream.next().await {
        result?;
    }
    on_progress(phase, total, total, "готово");
    Ok(())
}

async fn write_marker(
    game_dir: &Path,
    detail: &VersionDetail,
    libraries: usize,
) -> anyhow::Result<()> {
    let assets = match &detail.asset_index {
        Some(index_ref) => {
            let bytes = tokio::fs::read(asset_index_path(game_dir, &index_ref.id)).await?;
            serde_json::from_slice::<AssetIndexFile>(&bytes)?.objects.len()
        }
        None => 0,
    };
    let marker = InstallMarker {
        format: MARKER_FORMAT,
        version: detail.id.clone(),
        client_sha1: detail
            .client_download()
            .map(|c| c.sha1.clone())
            .unwrap_or_default(),
        asset_index: detail
            .asset_index
            .as_ref()
            .map(|a| a.id.clone())
            .unwrap_or_default(),
        libraries,
        assets,
        installed_at: crate::util::now_unix(),
    };
    let path = marker_path(game_dir, &detail.id);
    if let Some(parent) = path.parent() {
        tokio::fs::create_dir_all(parent).await?;
    }
    tokio::fs::write(&path, serde_json::to_vec_pretty(&marker)?).await?;
    Ok(())
}

async fn materialize_legacy_assets(
    index: &AssetIndexFile,
    objects_dir: &Path,
    target: &Path,
) -> anyhow::Result<()> {
    for (name, obj) in &index.objects {
        if obj.hash.len() < 2 {
            continue;
        }
        let src = objects_dir.join(&obj.hash[0..2]).join(&obj.hash);
        let dest = target.join(name);
        if let Ok(meta) = tokio::fs::metadata(&dest).await {
            if meta.len() == obj.size || obj.size == 0 {
                continue;
            }
        }
        if let Some(parent) = dest.parent() {
            tokio::fs::create_dir_all(parent).await?;
        }
        if tokio::fs::copy(&src, &dest).await.is_err() {
            eprintln!("[vita] не удалось разложить legacy-ассет {name}");
        }
    }
    Ok(())
}

fn extract_natives(jar_path: &Path, out_dir: &Path) -> anyhow::Result<()> {
    std::fs::create_dir_all(out_dir)?;
    let file = std::fs::File::open(jar_path)?;
    let mut archive = zip::ZipArchive::new(file)?;
    for i in 0..archive.len() {
        let mut entry = archive.by_index(i)?;
        let name = entry.name().to_string();
        if name.starts_with("META-INF") {
            continue;
        }
        let is_native = name.ends_with(".dll")
            || name.ends_with(".so")
            || name.ends_with(".dylib")
            || name.ends_with(".jnilib");
        if !is_native {
            continue;
        }
        // Только имя файла: ZIP-путь из архива не должен уводить за out_dir.
        let Some(file_name) = Path::new(&name).file_name() else {
            continue;
        };
        let out_path = out_dir.join(file_name);
        if out_path.exists() {
            continue;
        }
        let mut out_file = std::fs::File::create(&out_path)?;
        std::io::copy(&mut entry, &mut out_file)?;
    }
    Ok(())
}

/// Версии, уже установленные локально (для пометки "скачано" в списке).
pub fn installed_versions(game_dir: &Path) -> Vec<String> {
    let mut out = Vec::new();
    let Ok(entries) = std::fs::read_dir(game_dir.join("versions")) else {
        return out;
    };
    for entry in entries.flatten() {
        if !entry.path().join(MARKER_FILE).exists() {
            continue;
        }
        if let Ok(bytes) = std::fs::read(entry.path().join(MARKER_FILE)) {
            if let Ok(marker) = serde_json::from_slice::<InstallMarker>(&bytes) {
                out.push(marker.version);
                continue;
            }
        }
        if let Some(name) = entry.file_name().to_str() {
            out.push(name.to_string());
        }
    }
    out
}

// --- Наследование версий (inheritsFrom) -------------------------------
//
// Профили модлоадеров не самодостаточны: и Forge installer, и Fabric meta
// отдают JSON вида
//   { "id": "1.20.1-forge-47.3.12", "inheritsFrom": "1.20.1",
//     "mainClass": "cpw.mods.bootstraplauncher.BootstrapLauncher", ... }
// Всё остальное (client.jar, ассеты, половина аргументов) берётся у ванильного
// родителя. Поэтому перед установкой и запуском цепочку надо склеить в одну
// плоскую VersionDetail — ровно это делает resolve_detail.

const MAX_INHERIT_DEPTH: usize = 8;

pub fn local_detail_exists(game_dir: &Path, version_id: &str) -> bool {
    version_json_path(game_dir, version_id).exists()
}

/// Ссылка на ванильный JSON версии по её id (нужна, когда профиль ссылается на
/// версию, которую ещё не качали).
pub async fn version_url_for(version_id: &str) -> anyhow::Result<Option<String>> {
    static CACHE: OnceLock<tokio::sync::Mutex<Option<VersionManifest>>> = OnceLock::new();
    let cell = CACHE.get_or_init(|| tokio::sync::Mutex::new(None));
    let mut guard = cell.lock().await;
    if guard.is_none() {
        *guard = Some(fetch_version_manifest().await?);
    }
    Ok(guard
        .as_ref()
        .and_then(|m| m.versions.iter().find(|v| v.id == version_id))
        .map(|v| v.url.clone()))
}

/// Склеивает профиль с родителями в одну плоскую VersionDetail.
/// `version_url` нужен только если JSON этой версии ещё не лежит на диске.
pub async fn resolve_detail(
    game_dir: &Path,
    version_id: &str,
    version_url: &str,
) -> anyhow::Result<VersionDetail> {
    let mut chain: Vec<VersionDetail> = Vec::new();
    let mut current_id = version_id.to_string();
    let mut current_url = version_url.to_string();

    for _ in 0..MAX_INHERIT_DEPTH {
        let detail = load_or_fetch_detail(game_dir, &current_id, &current_url).await?;
        let parent = detail.inherits_from.clone();
        chain.push(detail);

        let Some(parent_id) = parent.filter(|p| !p.trim().is_empty()) else {
            break;
        };
        if chain.iter().any(|d| d.id == parent_id) {
            anyhow::bail!("циклическое наследование версий вокруг {parent_id}");
        }
        current_url = if local_detail_exists(game_dir, &parent_id) {
            String::new()
        } else {
            version_url_for(&parent_id).await?.ok_or_else(|| {
                anyhow::anyhow!(
                    "профиль ссылается на версию {parent_id}, но её нет ни на диске, \
                     ни в манифесте Mojang"
                )
            })?
        };
        current_id = parent_id;
    }

    // chain: [профиль, ..., ванильный корень] — склеиваем от корня вниз.
    let mut iter = chain.into_iter().rev();
    let mut merged = iter
        .next()
        .ok_or_else(|| anyhow::anyhow!("пустая цепочка версий"))?;
    merged.client_id = merged.id.clone();
    for child in iter {
        merged = merge_details(merged, child);
    }
    Ok(merged)
}

/// Ключ дедупликации библиотек: group:artifact(:classifier), без версии.
/// Forge и Fabric подсовывают свои (более новые) asm, guava, gson — их версия
/// должна победить ванильную, иначе игра падает на старте с NoSuchMethodError.
fn library_key(name: &str) -> String {
    let parts: Vec<&str> = name.split(':').collect();
    if parts.len() < 3 {
        return name.to_string();
    }
    let mut key = format!("{}:{}", parts[0], parts[1]);
    if let Some(classifier) = parts.get(3) {
        key.push(':');
        key.push_str(classifier);
    }
    key
}

fn merge_details(parent: VersionDetail, child: VersionDetail) -> VersionDetail {
    let client_id = if parent.client_id.is_empty() {
        parent.id.clone()
    } else {
        parent.client_id.clone()
    };

    // Библиотеки профиля идут первыми и вытесняют одноимённые ванильные.
    let mut libraries: Vec<Library> = Vec::new();
    let mut seen: std::collections::HashSet<String> = std::collections::HashSet::new();
    for lib in child.libraries.into_iter().chain(parent.libraries.into_iter()) {
        if seen.insert(library_key(&lib.name)) {
            libraries.push(lib);
        }
    }

    // Аргументы складываются: сначала ванильные, потом добавки модлоадера
    // (--launchTarget, --fml.forgeVersion, module-path для 1.17+).
    let arguments = match (parent.arguments, child.arguments) {
        (Some(p), Some(c)) => Some(Arguments {
            game: [p.game, c.game].concat(),
            jvm: [p.jvm, c.jvm].concat(),
        }),
        (Some(p), None) => Some(p),
        (None, c) => c,
    };

    VersionDetail {
        id: child.id,
        main_class: if child.main_class.trim().is_empty() {
            parent.main_class
        } else {
            child.main_class
        },
        downloads: child.downloads.or(parent.downloads),
        libraries,
        asset_index: child.asset_index.or(parent.asset_index),
        assets: child.assets.or(parent.assets),
        arguments,
        // Legacy-профили (Forge 1.12 и старше) переопределяют строку целиком —
        // в ней уже есть --tweakClass.
        minecraft_arguments: child.minecraft_arguments.or(parent.minecraft_arguments),
        java_version: child.java_version.or(parent.java_version),
        version_type: child.version_type.or(parent.version_type),
        inherits_from: None,
        client_id,
    }
}

/// Все версии/профили, у которых на диске есть JSON (включая modded).
pub fn local_version_ids(game_dir: &Path) -> Vec<String> {
    let mut out = Vec::new();
    let Ok(entries) = std::fs::read_dir(game_dir.join("versions")) else {
        return out;
    };
    for entry in entries.flatten() {
        if !entry.path().is_dir() {
            continue;
        }
        let Some(name) = entry.file_name().to_str().map(|s| s.to_string()) else {
            continue;
        };
        if entry.path().join(format!("{name}.json")).exists() {
            out.push(name);
        }
    }
    out.sort();
    out
}

/// Читает локальный JSON версии без сети (для определения loader'а).
pub fn read_local_detail(game_dir: &Path, version_id: &str) -> Option<VersionDetail> {
    let bytes = std::fs::read(version_json_path(game_dir, version_id)).ok()?;
    serde_json::from_slice::<VersionDetail>(&bytes).ok()
}

/// Есть ли законченная установка (маркер) у этой версии/профиля.
pub fn is_installed(game_dir: &Path, version_id: &str) -> bool {
    marker_path(game_dir, version_id).exists()
}

/// Записывает JSON профиля в versions/<id>/<id>.json.
pub async fn write_version_json(
    game_dir: &Path,
    version_id: &str,
    json: &str,
) -> anyhow::Result<PathBuf> {
    let path = version_json_path(game_dir, version_id);
    if let Some(parent) = path.parent() {
        tokio::fs::create_dir_all(parent).await?;
    }
    tokio::fs::write(&path, json.as_bytes()).await?;
    Ok(path)
}

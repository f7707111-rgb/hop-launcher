//! Единая точка правды по путям лаунчера.
//!
//! Windows: %APPDATA%/VitaLauncher      (dirs::data_dir -> Roaming)
//! macOS:   ~/Library/Application Support/VitaLauncher
//! Linux:   ~/.local/share/VitaLauncher

use std::path::PathBuf;

/// Корень данных лаунчера (аккаунты, конфиг, скины).
pub fn launcher_dir() -> PathBuf {
    dirs::data_dir()
        .unwrap_or_else(|| PathBuf::from("."))
        .join("VitaLauncher")
}

/// Игровая директория (.minecraft): versions/, libraries/, assets/.
pub fn game_dir() -> PathBuf {
    launcher_dir().join(".minecraft")
}

/// %APPDATA%/VitaLauncher/accounts.json — список сохранённых аккаунтов.
pub fn accounts_file() -> PathBuf {
    launcher_dir().join("accounts.json")
}

/// %APPDATA%/VitaLauncher/config.json — настройки лаунчера (ms_client_id и т.п.).
pub fn config_file() -> PathBuf {
    launcher_dir().join("config.json")
}

/// Локальные png-скины офлайн-аккаунтов.
pub fn skins_dir() -> PathBuf {
    launcher_dir().join("skins")
}

/// %APPDATA%/VitaLauncher/shortcuts/ — сохранённые ярлыки быстрого запуска
/// (JSON с параметрами + png-иконка со скином аккаунта).
pub fn shortcuts_dir() -> PathBuf {
    launcher_dir().join("shortcuts")
}

pub fn ensure_dirs() -> std::io::Result<()> {
    std::fs::create_dir_all(launcher_dir())?;
    std::fs::create_dir_all(skins_dir())?;
    std::fs::create_dir_all(loader_cache_dir())?;
    std::fs::create_dir_all(shortcuts_dir())?;
    Ok(())
}

/// Убирает из строки всё, что не годится в имя файла/папки.
/// Важно не только для косметики: version_id приходит из фронтенда, и без
/// этого "../.." позволил бы писать за пределы игровой папки.
pub fn safe_component(raw: &str) -> String {
    let cleaned: String = raw
        .chars()
        .map(|c| {
            if c.is_ascii_alphanumeric() || matches!(c, '.' | '-' | '_' | ' ') {
                c
            } else {
                '_'
            }
        })
        .collect();
    let trimmed = cleaned.trim().trim_matches('.').to_string();
    if trimmed.is_empty() {
        "unknown".to_string()
    } else {
        trimmed
    }
}

// --- Профили: моды, ресурс-паки ---------------------------------------
//
// Каждая версия (включая modded-профили вида 1.20.1-forge-47.3.12) живёт в
// своей папке versions/<id>/ и по умолчанию запускается с game_dir = этой
// папкой. Это единственный способ, при котором mods/ и resourcepacks/ вообще
// читаются игрой: Minecraft ищет их в рабочей директории, а не в versions/.
// Побочный плюс — миры и настройки у сборок не перемешиваются.
//
// libraries/ и assets/ остаются общими в корне .minecraft, они адресуются
// абсолютными путями и весят слишком много, чтобы дублировать их на профиль.

/// Папка профиля: versions/<id>/.
pub fn instance_dir(version_id: &str) -> PathBuf {
    game_dir().join("versions").join(safe_component(version_id))
}

/// Рабочая директория запуска. По умолчанию — папка профиля (изоляция сборок).
/// Кто хочет старое поведение этапа 2 (всё в общем .minecraft) — ставит
/// `"shared_game_dir": true` в config.json.
pub fn run_dir(version_id: &str) -> PathBuf {
    if shared_game_dir() {
        game_dir()
    } else {
        instance_dir(version_id)
    }
}

pub fn shared_game_dir() -> bool {
    read_config()
        .get("shared_game_dir")
        .and_then(|v| v.as_bool())
        .unwrap_or(false)
}

/// versions/<id>/mods/ — jar-ы модов (выключенные лежат как *.jar.disabled).
pub fn mods_dir(version_id: &str) -> PathBuf {
    run_dir(version_id).join("mods")
}

/// versions/<id>/resourcepacks/ — zip-ы ресурс-паков.
pub fn resourcepacks_dir(version_id: &str) -> PathBuf {
    run_dir(version_id).join("resourcepacks")
}

/// versions/<id>/mods.json — что за loader, какие моды и откуда взялись.
pub fn mods_config_path(version_id: &str) -> PathBuf {
    instance_dir(version_id).join("mods.json")
}

/// options.txt того профиля, в котором игра реально запускается: там живёт
/// строка resourcePacks:[...].
pub fn options_file(version_id: &str) -> PathBuf {
    run_dir(version_id).join("options.txt")
}

/// launcher_profiles.json — сам лаунчер им не пользуется, но installer Forge
/// без этого файла отказывается ставиться («Minecraft Launcher not installed»).
pub fn launcher_profiles_file() -> PathBuf {
    game_dir().join("launcher_profiles.json")
}

/// Кэш скачанных installer-ов модлоадеров.
pub fn loader_cache_dir() -> PathBuf {
    launcher_dir().join("loaders")
}

/// %APPDATA%/VitaLauncher/backups/ — автобэкапы миров (зипы saves/ по профилям).
pub fn backups_dir() -> PathBuf {
    launcher_dir().join("backups")
}

fn read_config() -> serde_json::Value {
    std::fs::read(config_file())
        .ok()
        .and_then(|b| serde_json::from_slice(&b).ok())
        .unwrap_or_else(|| serde_json::json!({}))
}

/// Ключ CurseForge (у них API только по ключу): env или config.json.
pub fn curseforge_key() -> Option<String> {
    if let Ok(key) = std::env::var("VITA_CURSEFORGE_KEY") {
        if !key.trim().is_empty() {
            return Some(key.trim().to_string());
        }
    }
    read_config()
        .get("curseforge_api_key")
        .and_then(|v| v.as_str())
        .map(|s| s.trim().to_string())
        .filter(|s| !s.is_empty())
}

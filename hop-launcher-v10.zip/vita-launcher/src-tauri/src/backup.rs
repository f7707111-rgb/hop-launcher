//! Автобэкапы миров.
//!
//! Перед каждым запуском тихо зипуем папку saves/ текущего профиля в
//! %APPDATA%/VitaLauncher/backups/<profile>/<timestamp>.zip. Старые бэкапы
//! (кроме последних KEEP_LAST) удаляются, чтобы не разрастаться бесконечно.
//! Ошибки бэкапа никогда не должны мешать запуску игры — все вызовы этого
//! модуля из main.rs делают best-effort и просто пишут в stderr при сбое.

use std::fs::File;
use std::io::{Read, Write};
use std::path::Path;

use zip::write::SimpleFileOptions;

const KEEP_LAST: usize = 5;

/// Зипует run_dir/saves в backups/<version_id>/<timestamp>.zip.
/// Возвращает None, если папки saves ещё нет (первый запуск, миров нет).
pub fn backup_world(run_dir: &Path, version_id: &str) -> anyhow::Result<Option<String>> {
    let saves_dir = run_dir.join("saves");
    if !saves_dir.exists() {
        return Ok(None);
    }
    // Пустая saves/ (миров ещё не создали) — тоже не за что бэкапить.
    let has_worlds = std::fs::read_dir(&saves_dir)
        .map(|mut it| it.next().is_some())
        .unwrap_or(false);
    if !has_worlds {
        return Ok(None);
    }

    let dest_dir = crate::paths::backups_dir().join(crate::paths::safe_component(version_id));
    std::fs::create_dir_all(&dest_dir)?;

    let stamp = chrono::Local::now().format("%Y-%m-%d_%H-%M-%S").to_string();
    let zip_path = dest_dir.join(format!("{stamp}.zip"));

    zip_dir(&saves_dir, &zip_path)?;
    prune_old_backups(&dest_dir)?;

    Ok(Some(zip_path.to_string_lossy().to_string()))
}

fn zip_dir(src_dir: &Path, zip_path: &Path) -> anyhow::Result<()> {
    let file = File::create(zip_path)?;
    let mut zip = zip::ZipWriter::new(file);
    let options = SimpleFileOptions::default().compression_method(zip::CompressionMethod::Deflated);

    let mut stack = vec![src_dir.to_path_buf()];
    while let Some(dir) = stack.pop() {
        for entry in std::fs::read_dir(&dir)? {
            let entry = entry?;
            let path = entry.path();
            let rel = path.strip_prefix(src_dir)?.to_string_lossy().replace('\\', "/");
            if path.is_dir() {
                zip.add_directory(format!("{rel}/"), options)?;
                stack.push(path);
            } else {
                zip.start_file(rel, options)?;
                let mut f = File::open(&path)?;
                let mut buf = Vec::new();
                f.read_to_end(&mut buf)?;
                zip.write_all(&buf)?;
            }
        }
    }
    zip.finish()?;
    Ok(())
}

/// Оставляет только KEEP_LAST самых свежих .zip по имени файла (timestamp в
/// имени сортируется лексикографически = хронологически).
fn prune_old_backups(dir: &Path) -> anyhow::Result<()> {
    let mut entries: Vec<_> = std::fs::read_dir(dir)?
        .filter_map(|e| e.ok())
        .filter(|e| e.path().extension().map(|x| x == "zip").unwrap_or(false))
        .collect();
    entries.sort_by_key(|e| e.file_name());
    if entries.len() > KEEP_LAST {
        for old in &entries[..entries.len() - KEEP_LAST] {
            let _ = std::fs::remove_file(old.path());
        }
    }
    Ok(())
}

/// Список сохранённых бэкапов профиля (для будущего UI восстановления),
/// новые сверху.
pub fn list_backups(version_id: &str) -> Vec<String> {
    let dir = crate::paths::backups_dir().join(crate::paths::safe_component(version_id));
    let mut names: Vec<String> = std::fs::read_dir(&dir)
        .map(|it| {
            it.filter_map(|e| e.ok())
                .filter_map(|e| e.file_name().to_str().map(|s| s.to_string()))
                .filter(|n| n.ends_with(".zip"))
                .collect()
        })
        .unwrap_or_default();
    names.sort();
    names.reverse();
    names
}

//! Ярлыки быстрого запуска.
//!
//! Идея: сохранить связку аккаунт + версия (+ сборка Forge/Fabric), выдать
//! пользователю иконку на рабочем столе / в меню Пуск / Dock / меню
//! приложений, а по клику на неё лаунчер сам стартует с аргументом
//! `--launch-shortcut=<name>`, тихо ставит то, чего не хватает, запускает
//! игру и закрывается — без открытия обычного окна лаунчера вообще.
//!
//! Файлы живут в %APPDATA%/VitaLauncher/shortcuts/:
//!   <name>.json — параметры (см. ShortcutFile)
//!   <name>.png  — иконка (голова скина выбранного аккаунта, если удалось
//!                 её достать; используется в списке ярлыков UI и в
//!                 .desktop-файле на Linux)
//!
//! Платформенный ярлык — это ОТДЕЛЬНАЯ сущность (файл на рабочем столе /
//! в ~/.local/share/applications), которую мы создаём и удаляем вместе с
//! записью в shortcuts/, но которая физически не хранит параметры запуска —
//! только команду `<launcher> --launch-shortcut=<name>`.

use std::path::{Path, PathBuf};

use serde::{Deserialize, Serialize};

use crate::accounts::StoredAccount;
use crate::paths;
use crate::util::{base64_encode, now_unix};

/// То, что лежит в shortcuts/<name>.json.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ShortcutFile {
    pub name: String,
    pub account_id: String,
    pub version_id: String,
    /// Профиль сборки (Forge/Fabric) в versions/, если это не ваниль.
    #[serde(default)]
    pub profile_id: Option<String>,
    #[serde(default)]
    pub loader: String,
    /// Ссылка на JSON версии Mojang — чтобы первый запуск ярлыка мог
    /// докачать версию, даже если её ещё не было на диске.
    #[serde(default)]
    pub version_url: String,
    pub created_at: i64,
}

/// То, что уходит в UI списком.
#[derive(Debug, Clone, Serialize)]
pub struct ShortcutInfo {
    pub name: String,
    pub account_name: String,
    pub version_id: String,
    pub loader: String,
    pub created_at: i64,
    /// data:-URL с иконкой (голова скина), если её удалось сохранить.
    pub icon: Option<String>,
}

fn safe_name(raw: &str) -> String {
    paths::safe_component(raw)
}

pub fn shortcut_json_path(name: &str) -> PathBuf {
    paths::shortcuts_dir().join(format!("{}.json", safe_name(name)))
}

fn shortcut_icon_path(name: &str) -> PathBuf {
    paths::shortcuts_dir().join(format!("{}.png", safe_name(name)))
}

pub fn exists(name: &str) -> bool {
    shortcut_json_path(name).exists()
}

/// Пишем через временный файл + rename — так же, как аккаунты, чтобы
/// оборванная запись не оставила битый JSON.
pub fn save(shortcut: &ShortcutFile) -> anyhow::Result<PathBuf> {
    paths::ensure_dirs()?;
    let path = shortcut_json_path(&shortcut.name);
    let tmp = path.with_extension("json.tmp");
    std::fs::write(&tmp, serde_json::to_vec_pretty(shortcut)?)?;
    std::fs::rename(&tmp, &path)?;
    Ok(path)
}

pub fn load(name: &str) -> anyhow::Result<ShortcutFile> {
    let path = shortcut_json_path(name);
    let bytes = std::fs::read(&path)
        .map_err(|_| anyhow::anyhow!("ярлык «{name}» не найден ({})", path.display()))?;
    serde_json::from_slice(&bytes)
        .map_err(|e| anyhow::anyhow!("ярлык «{name}» повреждён: {e}"))
}

/// Все сохранённые ярлыки, свежие сверху.
pub fn list() -> Vec<ShortcutFile> {
    let mut out = Vec::new();
    let Ok(entries) = std::fs::read_dir(paths::shortcuts_dir()) else {
        return out;
    };
    for entry in entries.flatten() {
        let path = entry.path();
        if path.extension().and_then(|e| e.to_str()) != Some("json") {
            continue;
        }
        if let Ok(bytes) = std::fs::read(&path) {
            if let Ok(shortcut) = serde_json::from_slice::<ShortcutFile>(&bytes) {
                out.push(shortcut);
            }
        }
    }
    out.sort_by(|a, b| b.created_at.cmp(&a.created_at));
    out
}

/// Собирает ShortcutInfo для UI: подтягивает имя аккаунта и иконку.
pub fn info(file: &ShortcutFile, account_name: Option<String>) -> ShortcutInfo {
    let icon = std::fs::read(shortcut_icon_path(&file.name))
        .ok()
        .map(|bytes| format!("data:image/png;base64,{}", base64_encode(&bytes)));
    ShortcutInfo {
        name: file.name.clone(),
        account_name: account_name.unwrap_or_else(|| "аккаунт удалён".to_string()),
        version_id: file.version_id.clone(),
        loader: file.loader.clone(),
        created_at: file.created_at,
        icon,
    }
}

/// Удаляет JSON, иконку и платформенный ярлык (рабочий стол / меню).
pub fn delete(name: &str) -> anyhow::Result<()> {
    let json = shortcut_json_path(name);
    if !json.exists() {
        anyhow::bail!("ярлык «{name}» не найден");
    }
    let _ = std::fs::remove_file(shortcut_icon_path(name));
    std::fs::remove_file(&json).map_err(|e| anyhow::anyhow!("не удалось удалить ярлык: {e}"))?;
    remove_platform_shortcut(name);
    Ok(())
}

/// Пытается достать текущий скин аккаунта и положить его как
/// shortcuts/<name>.png. Не выходит ошибкой наружу: иконка — приятный
/// бонус, а не обязательное условие для создания ярлыка.
pub async fn save_icon_for(name: &str, account: &StoredAccount) -> Option<PathBuf> {
    paths::ensure_dirs().ok()?;

    // Офлайн-аккаунт: png уже лежит на диске локально — просто копируем.
    if let Some(skin_path) = &account.skin_path {
        if let Ok(bytes) = std::fs::read(skin_path) {
            let path = shortcut_icon_path(name);
            if std::fs::write(&path, &bytes).is_ok() {
                return Some(path);
            }
        }
    }

    // Официальный аккаунт: качаем актуальную текстуру скина по URL.
    if let Some(url) = &account.skin_url {
        if !url.is_empty() {
            if let Ok(resp) = crate::net::client().get(url).send().await {
                if resp.status().is_success() {
                    if let Ok(bytes) = resp.bytes().await {
                        let path = shortcut_icon_path(name);
                        if std::fs::write(&path, &bytes).is_ok() {
                            return Some(path);
                        }
                    }
                }
            }
        }
    }
    None
}

fn desktop_dir() -> Option<PathBuf> {
    dirs::desktop_dir()
}

// --- Windows: .lnk на рабочий стол через WScript.Shell (COM) ----------
//
// IShellLink через сырой COM в чистом Rust — это отдельная зависимость и
// десятки строк unsafe-кода ради одного файла. PowerShell даёт тот же COM
// (New-Object -COM WScript.Shell) в одну команду, без единой новой crate —
// этот путь выбран сознательно вместо .bat-обёртки: .lnk — это то, что
// пользователь ожидает увидеть на рабочем столе Windows.
#[cfg(target_os = "windows")]
pub fn create_platform_shortcut(name: &str, _icon_path: Option<&Path>) -> anyhow::Result<String> {
    let exe = std::env::current_exe()?;
    let desktop = desktop_dir().ok_or_else(|| anyhow::anyhow!("не найден рабочий стол"))?;
    let lnk_path = desktop.join(format!("{}.lnk", safe_name(name)));
    let working_dir = exe
        .parent()
        .map(|p| p.display().to_string())
        .unwrap_or_default();
    let arg = format!("--launch-shortcut={}", safe_name(name));

    // Иконку .lnk можно поставить только из .ico/.exe/.dll — наш png сюда не
    // годится, поэтому ярлык использует иконку самого лаунчера. Сам png со
    // скином всё равно сохраняется рядом (используется в UI и на Linux).
    let script = format!(
        "$s = (New-Object -COM WScript.Shell).CreateShortcut('{lnk}'); \
         $s.TargetPath = '{target}'; $s.Arguments = '{args}'; \
         $s.WorkingDirectory = '{wd}'; $s.WindowStyle = 1; $s.Save()",
        lnk = lnk_path.display(),
        target = exe.display(),
        args = arg,
        wd = working_dir,
    );

    let output = std::process::Command::new("powershell")
        .args(["-NoProfile", "-NonInteractive", "-Command", &script])
        .output()?;
    if !output.status.success() {
        anyhow::bail!(
            "PowerShell не смог создать ярлык: {}",
            String::from_utf8_lossy(&output.stderr)
        );
    }
    Ok(lnk_path.to_string_lossy().to_string())
}

#[cfg(target_os = "windows")]
fn remove_platform_shortcut(name: &str) {
    if let Some(desktop) = desktop_dir() {
        let _ = std::fs::remove_file(desktop.join(format!("{}.lnk", safe_name(name))));
    }
}

// --- macOS --------------------------------------------------------------
//
// Настоящий .app-бандл с Info.plist — оверкилл для одной кнопки "запусти
// с таким-то аргументом". Кладём на рабочий стол исполняемый .command:
// Finder запускает такие файлы в Terminal по двойному клику, что даёт тот
// же результат (окно Minecraft вместо лаунчера), только с видимым, а не
// скрытым терминалом. Честный компромисс без Info.plist/иконки .app.
#[cfg(target_os = "macos")]
pub fn create_platform_shortcut(name: &str, _icon_path: Option<&Path>) -> anyhow::Result<String> {
    use std::os::unix::fs::PermissionsExt;

    let exe = std::env::current_exe()?;
    let desktop = desktop_dir().ok_or_else(|| anyhow::anyhow!("не найден рабочий стол"))?;
    let path = desktop.join(format!("{}.command", safe_name(name)));
    let arg = format!("--launch-shortcut={}", safe_name(name));
    let script = format!("#!/bin/bash\n\"{}\" {}\n", exe.display(), arg);
    std::fs::write(&path, script)?;
    let mut perms = std::fs::metadata(&path)?.permissions();
    perms.set_mode(0o755);
    std::fs::set_permissions(&path, perms)?;
    Ok(path.to_string_lossy().to_string())
}

#[cfg(target_os = "macos")]
fn remove_platform_shortcut(name: &str) {
    if let Some(desktop) = desktop_dir() {
        let _ = std::fs::remove_file(desktop.join(format!("{}.command", safe_name(name))));
    }
}

// --- Linux: .desktop в ~/.local/share/applications ---------------------
#[cfg(all(unix, not(target_os = "macos")))]
pub fn create_platform_shortcut(name: &str, icon_path: Option<&Path>) -> anyhow::Result<String> {
    use std::os::unix::fs::PermissionsExt;

    let exe = std::env::current_exe()?;
    let dir = dirs::data_dir()
        .ok_or_else(|| anyhow::anyhow!("не найдена папка ~/.local/share"))?
        .join("applications");
    std::fs::create_dir_all(&dir)?;
    let path = dir.join(format!("vita-shortcut-{}.desktop", safe_name(name)));
    let arg = format!("--launch-shortcut={}", safe_name(name));
    let icon_line = icon_path
        .filter(|p| p.exists())
        .map(|p| format!("Icon={}\n", p.display()))
        .unwrap_or_default();
    let content = format!(
        "[Desktop Entry]\nType=Application\nName={name}\nExec=\"{exe}\" {arg}\n{icon_line}Terminal=false\n",
        name = name,
        exe = exe.display(),
        arg = arg,
        icon_line = icon_line,
    );
    std::fs::write(&path, content)?;
    let mut perms = std::fs::metadata(&path)?.permissions();
    perms.set_mode(0o755);
    std::fs::set_permissions(&path, perms)?;
    Ok(path.to_string_lossy().to_string())
}

#[cfg(all(unix, not(target_os = "macos")))]
fn remove_platform_shortcut(name: &str) {
    if let Some(dir) = dirs::data_dir().map(|d| d.join("applications")) {
        let _ = std::fs::remove_file(dir.join(format!("vita-shortcut-{}.desktop", safe_name(name))));
    }
}

#[allow(dead_code)]
fn _touch_now_unix() -> i64 {
    now_unix()
}

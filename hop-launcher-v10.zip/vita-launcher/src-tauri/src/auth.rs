//! Авторизация: офлайн-аккаунты и цепочка Microsoft -> Xbox Live -> XSTS ->
//! Minecraft Services.
//!
//! Что изменилось на этом этапе:
//!  * сохраняем refresh_token и умеем тихо обновлять access_token
//!    (grant_type=refresh_token) — браузер нужен только при первом входе;
//!  * poll устройства различает "ещё не подтвердили" и реальную ошибку,
//!    раньше любая ошибка выглядела как бесконечное ожидание;
//!  * все ответы читаются через read_json: при не-200 в UI уходит текст
//!    ответа сервера, а не загадочная ошибка парсинга serde.

use md5::{Digest, Md5};
use serde::de::DeserializeOwned;
use serde::{Deserialize, Serialize};
use uuid::Uuid;

use crate::accounts::{AccountKind, StoredAccount};
use crate::net;
use crate::util::{now_unix, truncate};

// ---------------------------------------------------------------------
// Офлайн
// ---------------------------------------------------------------------

/// Локальный аккаунт "просто поиграть". Никакой сети и никакой проверки.
pub fn create_offline_account(username: &str) -> StoredAccount {
    StoredAccount {
        id: Uuid::new_v4().to_string(),
        username: username.to_string(),
        uuid: offline_uuid(username),
        kind: AccountKind::Offline,
        // Игре нужен токен правильной "формы"; в офлайне он не проверяется.
        access_token: "0".repeat(32),
        refresh_token: None,
        expires_at: None,
        skin_path: None,
        skin_url: None,
        skin_slim: false,
        last_used_at: Some(now_unix()),
        invalid: false,
    }
}

/// Vanilla-совместимый UUID офлайн-игрока: MD5 от `OfflinePlayer:<name>`,
/// подпатченный до вида UUIDv3. Так же делает ванильный сервер в offline-mode,
/// поэтому один и тот же ник всегда даёт одного и того же игрока.
fn offline_uuid(username: &str) -> String {
    let mut hasher = Md5::new();
    hasher.update(format!("OfflinePlayer:{username}"));
    let mut bytes = hasher.finalize();

    bytes[6] = (bytes[6] & 0x0f) | 0x30; // version 3
    bytes[8] = (bytes[8] & 0x3f) | 0x80; // variant

    Uuid::from_slice(&bytes)
        .expect("md5 output is always 16 bytes")
        .to_string()
}

// ---------------------------------------------------------------------
// Официальный вход
// ---------------------------------------------------------------------

const DEFAULT_MS_CLIENT_ID: &str = "PUT-YOUR-AZURE-APP-CLIENT-ID-HERE"; // <-- сюда вставь свой Client ID из portal.azure.com
const MS_SCOPE: &str = "XboxLive.signin offline_access";
const MS_DEVICE_CODE_URL: &str =
    "https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode";
const MS_TOKEN_URL: &str = "https://login.microsoftonline.com/consumers/oauth2/v2.0/token";
const XBL_AUTH_URL: &str = "https://user.auth.xboxlive.com/user/authenticate";
const XSTS_AUTH_URL: &str = "https://xsts.auth.xboxlive.com/xsts/authorize";
const MC_LOGIN_URL: &str = "https://api.minecraftservices.com/authentication/login_with_xbox";
pub const MC_PROFILE_URL: &str = "https://api.minecraftservices.com/minecraft/profile";

/// client_id своего приложения Azure AD. Порядок поиска:
/// переменная окружения -> config.json -> константа в коде.
///
/// Приложение нужно зарегистрировать самому: portal.azure.com ->
/// App registrations -> New registration, тип "Public client",
/// разрешения XboxLive.signin + offline_access.
pub fn ms_client_id() -> anyhow::Result<String> {
    if let Ok(v) = std::env::var("VITA_MS_CLIENT_ID") {
        if !v.trim().is_empty() {
            return Ok(v.trim().to_string());
        }
    }
    if let Ok(bytes) = std::fs::read(crate::paths::config_file()) {
        if let Ok(cfg) = serde_json::from_slice::<serde_json::Value>(&bytes) {
            if let Some(v) = cfg.get("ms_client_id").and_then(|v| v.as_str()) {
                let v = v.trim();
                if !v.is_empty() && !v.starts_with("PUT-YOUR") {
                    return Ok(v.to_string());
                }
            }
        }
    }
    if DEFAULT_MS_CLIENT_ID.starts_with("PUT-YOUR") {
        anyhow::bail!(
            "Вход через Microsoft пока не настроен — офлайн-аккаунты работают без этого."
        );
    }
    Ok(DEFAULT_MS_CLIENT_ID.to_string())
}

/// Единая точка чтения JSON-ответов: при не-200 отдаём наверх статус и тело.
async fn read_json<T: DeserializeOwned>(resp: reqwest::Response, ctx: &str) -> anyhow::Result<T> {
    let status = resp.status();
    let text = resp.text().await.unwrap_or_default();
    if !status.is_success() {
        anyhow::bail!("{ctx}: HTTP {} — {}", status.as_u16(), truncate(&text, 400));
    }
    serde_json::from_str::<T>(&text)
        .map_err(|e| anyhow::anyhow!("{ctx}: неожиданный ответ ({e}) — {}", truncate(&text, 200)))
}

#[derive(Debug, Deserialize, Serialize)]
pub struct DeviceCodeResponse {
    pub device_code: String,
    pub user_code: String,
    pub verification_uri: String,
    pub interval: u64,
    pub expires_in: u64,
    pub message: String,
}

/// Шаг 1: получаем device code. Пользователю показываем user_code и ссылку.
pub async fn start_device_code_flow() -> anyhow::Result<DeviceCodeResponse> {
    let client_id = ms_client_id()?;
    let resp = net::client()
        .post(MS_DEVICE_CODE_URL)
        .form(&[("client_id", client_id.as_str()), ("scope", MS_SCOPE)])
        .send()
        .await?;
    read_json(resp, "Microsoft device code").await
}

#[derive(Debug, Clone)]
pub struct MsTokens {
    pub access_token: String,
    pub refresh_token: Option<String>,
}

#[derive(Debug, Deserialize)]
struct MsTokenResponse {
    access_token: String,
    #[serde(default)]
    refresh_token: Option<String>,
}

#[derive(Debug, Deserialize)]
struct MsErrorResponse {
    #[serde(default)]
    error: String,
    #[serde(default)]
    error_description: String,
}

pub enum PollOutcome {
    /// Пользователь ещё не подтвердил вход в браузере — опрашиваем дальше.
    Pending,
    Ready(MsTokens),
}

/// Шаг 2: опрос токена. Ошибки authorization_pending/slow_down — это норма,
/// всё остальное реально ломает вход и должно доехать до пользователя.
pub async fn poll_device_code(device_code: &str) -> anyhow::Result<PollOutcome> {
    let client_id = ms_client_id()?;
    let resp = net::client()
        .post(MS_TOKEN_URL)
        .form(&[
            ("client_id", client_id.as_str()),
            ("grant_type", "urn:ietf:params:oauth:grant-type:device_code"),
            ("device_code", device_code),
        ])
        .send()
        .await?;

    if resp.status().is_success() {
        let token: MsTokenResponse = read_json(resp, "Microsoft token").await?;
        return Ok(PollOutcome::Ready(MsTokens {
            access_token: token.access_token,
            refresh_token: token.refresh_token,
        }));
    }

    let text = resp.text().await.unwrap_or_default();
    let err: MsErrorResponse = serde_json::from_str(&text).unwrap_or(MsErrorResponse {
        error: String::new(),
        error_description: truncate(&text, 200),
    });

    match err.error.as_str() {
        "authorization_pending" | "slow_down" => Ok(PollOutcome::Pending),
        "expired_token" => anyhow::bail!("Код входа истёк, начни вход заново."),
        "authorization_declined" => anyhow::bail!("Вход отклонён в браузере."),
        "bad_verification_code" => anyhow::bail!("Некорректный код устройства, начни вход заново."),
        _ => anyhow::bail!(
            "Microsoft отказал во входе: {} {}",
            err.error,
            truncate(&err.error_description, 200)
        ),
    }
}

/// Тихое обновление: меняем refresh_token на свежую пару токенов.
/// Именно это избавляет от браузера при каждом старте лаунчера.
pub async fn refresh_ms_tokens(refresh_token: &str) -> anyhow::Result<MsTokens> {
    let client_id = ms_client_id()?;
    let resp = net::client()
        .post(MS_TOKEN_URL)
        .form(&[
            ("client_id", client_id.as_str()),
            ("grant_type", "refresh_token"),
            ("refresh_token", refresh_token),
            ("scope", MS_SCOPE),
        ])
        .send()
        .await?;
    let token: MsTokenResponse = read_json(resp, "Microsoft refresh_token").await?;
    Ok(MsTokens {
        access_token: token.access_token,
        // Microsoft обычно выдаёт новый refresh_token; если нет — оставляем старый.
        refresh_token: token
            .refresh_token
            .or_else(|| Some(refresh_token.to_string())),
    })
}

#[derive(Serialize)]
struct XblAuthRequest<'a> {
    #[serde(rename = "Properties")]
    properties: XblProperties<'a>,
    #[serde(rename = "RelyingParty")]
    relying_party: &'a str,
    #[serde(rename = "TokenType")]
    token_type: &'a str,
}

#[derive(Serialize)]
struct XblProperties<'a> {
    #[serde(rename = "AuthMethod")]
    auth_method: &'a str,
    #[serde(rename = "SiteName")]
    site_name: &'a str,
    #[serde(rename = "RpsTicket")]
    rps_ticket: String,
}

#[derive(Deserialize)]
struct XblAuthResponse {
    #[serde(rename = "Token")]
    token: String,
    #[serde(rename = "DisplayClaims")]
    display_claims: DisplayClaims,
}

#[derive(Deserialize)]
struct DisplayClaims {
    xui: Vec<XuiEntry>,
}

#[derive(Deserialize)]
struct XuiEntry {
    uhs: String,
}

#[derive(Debug, Deserialize)]
pub struct ProfileSkin {
    #[serde(default)]
    pub state: String,
    #[serde(default)]
    pub url: String,
    #[serde(default)]
    pub variant: String,
}

#[derive(Debug, Deserialize)]
pub struct McProfile {
    pub id: String,
    pub name: String,
    #[serde(default)]
    pub skins: Vec<ProfileSkin>,
}

impl McProfile {
    /// Активный скин профиля — его и показываем в превью.
    pub fn active_skin(&self) -> Option<&ProfileSkin> {
        self.skins
            .iter()
            .find(|s| s.state.eq_ignore_ascii_case("ACTIVE"))
            .or_else(|| self.skins.first())
    }

    /// Нормализованный UUID с дефисами: Mojang отдаёт его без них, а игре
    /// и превью удобнее канонический вид.
    pub fn dashed_uuid(&self) -> String {
        if self.id.len() == 32 {
            if let Ok(parsed) = Uuid::parse_str(&self.id) {
                return parsed.to_string();
            }
        }
        self.id.clone()
    }
}

pub async fn fetch_profile(mc_access_token: &str) -> anyhow::Result<McProfile> {
    let resp = net::client()
        .get(MC_PROFILE_URL)
        .bearer_auth(mc_access_token)
        .send()
        .await?;
    if resp.status() == reqwest::StatusCode::NOT_FOUND {
        anyhow::bail!("На этом аккаунте Microsoft нет купленного Minecraft (профиль не найден).");
    }
    read_json(resp, "Minecraft profile").await
}

/// Шаги 3-5: MS access token -> XBL -> XSTS -> Minecraft -> профиль.
/// Возвращает уже готовую к сохранению запись аккаунта.
pub async fn account_from_ms_tokens(tokens: &MsTokens) -> anyhow::Result<StoredAccount> {
    let client = net::client();

    // --- Xbox Live
    let xbl_resp = client
        .post(XBL_AUTH_URL)
        .json(&XblAuthRequest {
            properties: XblProperties {
                auth_method: "RPS",
                site_name: "user.auth.xboxlive.com",
                rps_ticket: format!("d={}", tokens.access_token),
            },
            relying_party: "http://auth.xboxlive.com",
            token_type: "JWT",
        })
        .send()
        .await?;
    let xbl: XblAuthResponse = read_json(xbl_resp, "Xbox Live auth").await?;
    let user_hash = xbl
        .display_claims
        .xui
        .first()
        .map(|x| x.uhs.clone())
        .ok_or_else(|| anyhow::anyhow!("Xbox Live не вернул user hash"))?;

    // --- XSTS (самое частое место отказа, поэтому разбираем XErr)
    let xsts_resp = client
        .post(XSTS_AUTH_URL)
        .json(&serde_json::json!({
            "Properties": { "SandboxId": "RETAIL", "UserTokens": [xbl.token] },
            "RelyingParty": "rp://api.minecraftservices.com/",
            "TokenType": "JWT"
        }))
        .send()
        .await?;

    if xsts_resp.status() == reqwest::StatusCode::UNAUTHORIZED {
        let text = xsts_resp.text().await.unwrap_or_default();
        let xerr = serde_json::from_str::<serde_json::Value>(&text)
            .ok()
            .and_then(|v| v.get("XErr").and_then(|x| x.as_i64()));
        let msg = match xerr {
            Some(2148916233) => "К этому аккаунту Microsoft не привязан профиль Xbox Live. \
                                 Создай его на xbox.com и попробуй снова.",
            Some(2148916235) => "Xbox Live недоступен в регионе этого аккаунта.",
            Some(2148916236) | Some(2148916237) => {
                "Аккаунту нужна взрослая верификация (Южная Корея)."
            }
            Some(2148916238) => "Детский аккаунт: добавь его в семейную группу Microsoft.",
            _ => "XSTS отклонил авторизацию.",
        };
        anyhow::bail!("{msg}");
    }
    let xsts: XblAuthResponse = read_json(xsts_resp, "XSTS auth").await?;

    // --- Minecraft Services
    #[derive(Deserialize)]
    struct McLoginResponse {
        access_token: String,
        #[serde(default)]
        expires_in: Option<i64>,
    }
    let mc_resp = client
        .post(MC_LOGIN_URL)
        .json(&serde_json::json!({
            "identityToken": format!("XBL3.0 x={};{}", user_hash, xsts.token)
        }))
        .send()
        .await?;
    let mc_login: McLoginResponse = read_json(mc_resp, "Minecraft login").await?;

    let profile = fetch_profile(&mc_login.access_token).await?;
    let skin = profile.active_skin();

    Ok(StoredAccount {
        id: String::new(), // назначит AccountStore::upsert
        username: profile.name.clone(),
        uuid: profile.dashed_uuid(),
        kind: AccountKind::Microsoft,
        access_token: mc_login.access_token,
        refresh_token: tokens.refresh_token.clone(),
        // Токен Minecraft живёт ~24 часа; на это время браузер больше не нужен.
        expires_at: Some(now_unix() + mc_login.expires_in.unwrap_or(86_400)),
        skin_path: None,
        skin_url: skin.map(|s| s.url.clone()).filter(|u| !u.is_empty()),
        skin_slim: skin
            .map(|s| s.variant.eq_ignore_ascii_case("SLIM"))
            .unwrap_or(false),
        last_used_at: Some(now_unix()),
        invalid: false,
    })
}

/// Тихо обновляет официальный аккаунт по сохранённому refresh_token.
pub async fn silent_refresh(account: &StoredAccount) -> anyhow::Result<StoredAccount> {
    let refresh = account
        .refresh_token
        .as_deref()
        .ok_or_else(|| anyhow::anyhow!("нет refresh_token, нужен повторный вход"))?;
    let tokens = refresh_ms_tokens(refresh).await?;
    let mut refreshed = account_from_ms_tokens(&tokens).await?;
    refreshed.id = account.id.clone();
    // Локальные настройки скина переживают обновление токена.
    refreshed.skin_path = account.skin_path.clone();
    if refreshed.skin_url.is_none() {
        refreshed.skin_url = account.skin_url.clone();
    }
    refreshed.last_used_at = account.last_used_at;
    Ok(refreshed)
}

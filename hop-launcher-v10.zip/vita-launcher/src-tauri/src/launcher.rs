//! Сборка командной строки java и запуск игры.
//!
//! Что было починено на этом этапе:
//!  * classpath собирался из ВСЕХ библиотек без учёта rules и без учёта
//!    downloads.artifact.path — на любой версии с нативами путь получался
//!    неверным, и игра падала на старте;
//!  * jar-ы с нативами больше не попадают в classpath (старая схема
//!    classifiers), а нативы для 1.19+ наоборот остаются в classpath;
//!  * аргументы JVM из arguments.jvm теперь реально используются (там живут
//!    -XstartOnFirstThread для macOS, -Djava.library.path, -cp и module-path
//!    для 1.17+). Раньше они игнорировались целиком;
//!  * legacy-аргументы (minecraftArguments) больше не ломаются, если в пути
//!    к папке есть пробел: подстановка идёт по уже разбитым токенам, а не
//!    по строке целиком;
//!  * stdout/stderr игры перехватываются и уходят в UI событием game-log,
//!    плюс проверяется мгновенный вылет — раньше лаунчер писал "Запущено!"
//!    даже если java умирала через полсекунды;
//!  * проверяется мажорная версия java против javaVersion из манифеста
//!    (1.17+ требует 17, 1.20.5+ требует 21).

use std::io::{BufRead, BufReader};
use std::path::Path;
use std::process::{Command, Stdio};
use std::sync::{Arc, Mutex};

use serde_json::Value;

use crate::accounts::StoredAccount;
use crate::version_manager::{self as vm, Rule, VersionDetail};

/// Приёмник событий запуска (game-log/game-exit/install-progress), не привязанный
/// к Tauri: обычный запуск шлёт их в окно через AppHandle::emit, headless-запуск
/// ярлыка (`--launch-shortcut=...`, без UI вообще) — просто печатает их в stderr.
pub type Emitter = std::sync::Arc<dyn Fn(&str, Value) + Send + Sync>;

const LAUNCHER_NAME: &str = "VitaLauncher";
const LOG_TAIL_LINES: usize = 60;

/// Мажорная версия java по выводу `java -version`.
/// Формат: `openjdk version "17.0.8"` или `java version "1.8.0_381"`.
pub fn java_major_version(java_path: &str) -> Option<u32> {
    let output = Command::new(java_path).arg("-version").output().ok()?;
    let text = format!(
        "{}{}",
        String::from_utf8_lossy(&output.stderr),
        String::from_utf8_lossy(&output.stdout)
    );
    let quoted = text.split('"').nth(1)?;
    let mut parts = quoted.split(['.', '_', '-']);
    let first = parts.next()?;
    if first == "1" {
        parts.next()?.parse().ok()
    } else {
        first.parse().ok()
    }
}

/// Собирает команду и запускает игру. Возвращает PID процесса.
/// Ждёт несколько секунд и, если java уже умерла, отдаёт наверх хвост лога —
/// это ровно те ошибки, которые пользователь иначе никогда не увидит.
#[allow(clippy::too_many_arguments)]
pub async fn launch(
    emit: &Emitter,
    game_dir: &Path,
    // run_dir — рабочая папка профиля: именно здесь игра ищет mods/,
    // resourcepacks/, options.txt и saves/. Для сборок это versions/<id>/,
    // а не общий .minecraft, иначе моды одной сборки попадут во все остальные.
    run_dir: &Path,
    detail: &VersionDetail,
    account: &StoredAccount,
    java_path: &str,
    max_ram_mb: u32,
    extra_jvm_args: &[String],
) -> anyhow::Result<u32> {
    // --- Проверка java до запуска: понятная ошибка вместо загадочного краша.
    if let Some(req) = &detail.java_version {
        if req.major_version > 0 {
            match java_major_version(java_path) {
                Some(actual) if actual < req.major_version => {
                    anyhow::bail!(
                        "Версии {} нужна Java {} или новее, а найдена Java {}. \
                         Поставь подходящую JDK/JRE и укажи путь к ней в настройках.",
                        detail.id,
                        req.major_version,
                        actual
                    );
                }
                Some(_) => {}
                None => eprintln!("[vita] не удалось определить версию java по пути {java_path}"),
            }
        }
    }

    let version_dir = vm::version_dir(game_dir, &detail.id);
    // client.jar и natives живут у ванильной версии: у профиля Forge/Fabric
    // своего клиента нет, он наследует родительский.
    let client_jar = vm::client_jar_path(game_dir, detail.client_version_id());
    let natives_dir = vm::natives_dir(game_dir, detail.client_version_id());
    let libraries_dir = vm::libraries_dir(game_dir);
    let assets_dir = vm::assets_dir(game_dir);

    if !client_jar.exists() {
        anyhow::bail!(
            "не найден {} — установка версии не завершена",
            client_jar.display()
        );
    }
    std::fs::create_dir_all(game_dir)?;
    std::fs::create_dir_all(run_dir)?;
    std::fs::create_dir_all(&natives_dir)?;
    // Пустые mods/ и resourcepacks/ создаём заранее: и Forge, и Fabric ругаются
    // в лог, если папки нет, а пользователю проще закинуть файл руками.
    std::fs::create_dir_all(run_dir.join("mods"))?;
    std::fs::create_dir_all(run_dir.join("resourcepacks"))?;

    // --- Classpath: только разрешённые правилами библиотеки, без jar-ов,
    //     которые существуют исключительно ради распаковки нативов.
    let mut classpath: Vec<String> = Vec::new();
    for lib in vm::resolve_libraries(detail, &libraries_dir) {
        if lib.native_only {
            continue;
        }
        if !lib.path.exists() {
            eprintln!("[vita] библиотека отсутствует, пропускаю: {}", lib.path.display());
            continue;
        }
        classpath.push(lib.path.to_string_lossy().to_string());
    }
    classpath.push(client_jar.to_string_lossy().to_string());

    let separator = if cfg!(target_os = "windows") { ";" } else { ":" };
    let classpath_str = classpath.join(separator);

    let assets_index_name = detail
        .asset_index
        .as_ref()
        .map(|a| a.id.clone())
        .or_else(|| detail.assets.clone())
        .unwrap_or_else(|| "legacy".to_string());

    let virtual_assets = assets_dir
        .join("virtual")
        .join(crate::paths::safe_component(&assets_index_name));

    let uuid_plain = account.uuid.replace('-', "");
    let subs: Vec<(&str, String)> = vec![
        ("${auth_player_name}", account.username.clone()),
        ("${auth_uuid}", account.uuid.clone()),
        ("${auth_access_token}", account.access_token.clone()),
        (
            "${auth_session}",
            format!("token:{}:{}", account.access_token, uuid_plain),
        ),
        // Современный клиент ждёт msa; для офлайна значение всё равно не
        // проверяется, поэтому не выдумываем отдельный тип.
        ("${user_type}", "msa".to_string()),
        ("${user_properties}", "{}".to_string()),
        ("${clientid}", "-".to_string()),
        ("${auth_xuid}", "-".to_string()),
        ("${version_name}", detail.id.clone()),
        (
            "${version_type}",
            detail
                .version_type
                .clone()
                .unwrap_or_else(|| "release".to_string()),
        ),
        ("${profile_name}", LAUNCHER_NAME.to_string()),
        ("${game_directory}", run_dir.to_string_lossy().to_string()),
        ("${assets_root}", assets_dir.to_string_lossy().to_string()),
        ("${game_assets}", virtual_assets.to_string_lossy().to_string()),
        ("${assets_index_name}", assets_index_name.clone()),
        (
            "${natives_directory}",
            natives_dir.to_string_lossy().to_string(),
        ),
        (
            "${library_directory}",
            libraries_dir.to_string_lossy().to_string(),
        ),
        ("${classpath}", classpath_str.clone()),
        ("${classpath_separator}", separator.to_string()),
        ("${launcher_name}", LAUNCHER_NAME.to_string()),
        ("${launcher_version}", env!("CARGO_PKG_VERSION").to_string()),
        ("${resolution_width}", "854".to_string()),
        ("${resolution_height}", "480".to_string()),
    ];

    // --- Аргументы JVM
    let xmx = max_ram_mb.max(512);
    let xms = xmx.min(1024);
    let mut jvm_args: Vec<String> = vec![
        format!("-Xmx{xmx}M"),
        format!("-Xms{xms}M"),
        "-Dfile.encoding=UTF-8".to_string(),
        format!("-Dminecraft.launcher.brand={LAUNCHER_NAME}"),
        format!("-Dminecraft.launcher.version={}", env!("CARGO_PKG_VERSION")),
    ];
    jvm_args.extend(extra_jvm_args.iter().cloned());

    let manifest_jvm = match &detail.arguments {
        Some(args) => collect_args(&args.jvm, &subs),
        None => Vec::new(),
    };
    if manifest_jvm.is_empty() {
        // Старые версии (<1.13) не описывают аргументы JVM — собираем сами.
        jvm_args.push(format!(
            "-Djava.library.path={}",
            natives_dir.to_string_lossy()
        ));
        jvm_args.push("-cp".to_string());
        jvm_args.push(classpath_str.clone());
    } else {
        jvm_args.extend(manifest_jvm);
        if !jvm_args.iter().any(|a| a == "-cp" || a == "-classpath") {
            jvm_args.push("-cp".to_string());
            jvm_args.push(classpath_str.clone());
        }
        if !jvm_args
            .iter()
            .any(|a| a.starts_with("-Djava.library.path="))
        {
            jvm_args.push(format!(
                "-Djava.library.path={}",
                natives_dir.to_string_lossy()
            ));
        }
    }

    // --- Аргументы игры
    let mut game_args = build_game_args(detail, &subs);
    // Старые версии (и часть профилей Forge) не подставляют --gameDir из
    // шаблона. Без него игра уедет в общий .minecraft и не увидит моды сборки.
    if !game_args.iter().any(|a| a == "--gameDir") {
        game_args.push("--gameDir".to_string());
        game_args.push(run_dir.to_string_lossy().to_string());
    }

    let mut cmd = Command::new(java_path);
    cmd.args(&jvm_args)
        .arg(&detail.main_class)
        .args(&game_args)
        .current_dir(run_dir)
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());

    #[cfg(target_os = "windows")]
    {
        use std::os::windows::process::CommandExt;
        // Без этого рядом с игрой открывается пустое окно консоли.
        cmd.creation_flags(0x0800_0000); // CREATE_NO_WINDOW
    }

    eprintln!(
        "[vita] запуск {} из {} ({} библиотек в classpath, mainClass {}, рабочая папка {})",
        detail.id,
        version_dir.display(),
        classpath.len(),
        detail.main_class,
        run_dir.display()
    );

    let mut child = cmd
        .spawn()
        .map_err(|e| anyhow::anyhow!("не удалось запустить java ({java_path}): {e}"))?;
    let pid = child.id();

    // --- Перехват логов игры
    let tail: Arc<Mutex<Vec<String>>> = Arc::new(Mutex::new(Vec::new()));
    if let Some(stdout) = child.stdout.take() {
        spawn_log_pump(Arc::clone(emit), Arc::clone(&tail), stdout, "out");
    }
    if let Some(stderr) = child.stderr.take() {
        spawn_log_pump(Arc::clone(emit), Arc::clone(&tail), stderr, "err");
    }

    // Даём игре пару секунд: если java свалилась сразу, это почти всегда
    // ошибка конфигурации, и её надо показать, а не праздновать "Запущено!".
    tokio::time::sleep(std::time::Duration::from_millis(2500)).await;
    if let Ok(Some(status)) = child.try_wait() {
        if !status.success() {
            let log = tail
                .lock()
                .map(|lines| lines.join("\n"))
                .unwrap_or_default();
            anyhow::bail!(
                "Minecraft закрылся сразу после запуска (код {}).\n{}",
                status.code().unwrap_or(-1),
                crate::util::truncate(&log, 1500)
            );
        }
    }

    // Дальше игра живёт сама; ждём её в фоне, чтобы не оставлять зомби-процесс
    // и сообщить UI о закрытии.
    let emit_for_exit = Arc::clone(emit);
    std::thread::spawn(move || {
        let code = child.wait().ok().and_then(|s| s.code()).unwrap_or(-1);
        emit_for_exit("game-exit", serde_json::json!({ "code": code }));
    });

    Ok(pid)
}

fn spawn_log_pump<R>(emit: Emitter, tail: Arc<Mutex<Vec<String>>>, reader: R, stream: &'static str)
where
    R: std::io::Read + Send + 'static,
{
    std::thread::spawn(move || {
        let buffered = BufReader::new(reader);
        for line in buffered.lines() {
            let Ok(line) = line else { break };
            if let Ok(mut lines) = tail.lock() {
                lines.push(line.clone());
                if lines.len() > LOG_TAIL_LINES {
                    let overflow = lines.len() - LOG_TAIL_LINES;
                    lines.drain(0..overflow);
                }
            }
            emit(
                "game-log",
                serde_json::json!({ "stream": stream, "line": line }),
            );
        }
    });
}

fn substitute(raw: &str, subs: &[(&str, String)]) -> String {
    let mut out = raw.to_string();
    if !out.contains("${") {
        return out;
    }
    for (key, value) in subs {
        if out.contains(key) {
            out = out.replace(key, value);
        }
    }
    out
}

/// Аргументы в манифесте — это смесь простых строк и объектов с правилами.
/// Объекты с правилами по features (демо-режим, своё разрешение окна) мы
/// пропускаем: обычный запуск их не включает.
fn collect_args(values: &[Value], subs: &[(&str, String)]) -> Vec<String> {
    let mut out = Vec::new();
    for value in values {
        match value {
            Value::String(s) => out.push(substitute(s, subs)),
            Value::Object(obj) => {
                if let Some(rules) = obj.get("rules") {
                    if rules.to_string().contains("\"features\"") {
                        continue;
                    }
                    let parsed: Option<Vec<Rule>> = serde_json::from_value(rules.clone()).ok();
                    if !vm::rules_allow(&parsed) {
                        continue;
                    }
                }
                match obj.get("value") {
                    Some(Value::String(s)) => out.push(substitute(s, subs)),
                    Some(Value::Array(items)) => {
                        for item in items {
                            if let Some(s) = item.as_str() {
                                out.push(substitute(s, subs));
                            }
                        }
                    }
                    _ => {}
                }
            }
            _ => {}
        }
    }
    out
}

fn build_game_args(detail: &VersionDetail, subs: &[(&str, String)]) -> Vec<String> {
    if let Some(flat) = &detail.minecraft_arguments {
        // Сначала режем шаблон на токены, и только потом подставляем значения:
        // иначе путь с пробелом (C:\Users\Иван Петров\...) разъезжается на
        // два аргумента, и игра стартует не в той папке.
        return flat
            .split_whitespace()
            .map(|token| substitute(token, subs))
            .collect();
    }
    match &detail.arguments {
        Some(args) => collect_args(&args.game, subs),
        None => Vec::new(),
    }
}

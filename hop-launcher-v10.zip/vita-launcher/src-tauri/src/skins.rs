//! Скины.
//!
//! ОФИЦИАЛЬНЫЕ АККАУНТЫ
//! Загружаем png прямо в Minecraft Services:
//!   PUT https://api.minecraftservices.com/minecraft/profile/skins
//!   multipart: variant=classic|slim, file=<png>, Authorization: Bearer <token>
//! Ответ — обновлённый профиль, из него берём URL текстуры для превью.
//!
//! ОФЛАЙН-АККАУНТЫ — ВЫБРАН ВАРИАНТ B (локальный png + честное предупреждение)
//! Почему не вариант A (authlib-injector + локальный skin-сервер):
//!   1. Пришлось бы тащить в комплект сторонний authlib-injector.jar (GPLv3),
//!      следить за его версиями и совместимостью с каждой версией игры;
//!   2. Нужен полноценный yggdrasil-совместимый сервер: /authenticate,
//!      /refresh, /validate, /sessionserver/session/minecraft/hasJoined,
//!      профили с подписанными текстурами. Это отдельный подпроект, а не
//!      "кнопка выбрать файл", и любой промах в нём ломает сам запуск игры;
//!   3. Пользы почти нет: в одиночной офлайн-игре скин видит только сам
//!      игрок, а на серверах с online-mode=true офлайн-аккаунт всё равно не
//!      пустят. Ради превью в лаунчере поднимать HTTP-сервер и патчить JVM
//!      агентом — несоразмерный риск для этапа, цель которого "оно
//!      запускается".
//! Поэтому храним выбранный png в %APPDATA%/VitaLauncher/skins/<id>.png,
//! показываем его в лаунчере и прямо в UI пишем, что другим игрокам он не
//! виден. Когда (и если) понадобится вариант A, точка расширения очевидна:
//! добавить JVM-аргумент -javaagent в extra_jvm_args в launcher::launch.

use std::path::PathBuf;

use crate::accounts::{AccountKind, StoredAccount};
use crate::auth;
use crate::net;
use crate::paths;
use crate::util::{base64_encode, png_dimensions, truncate};

const SKIN_UPLOAD_URL: &str = "https://api.minecraftservices.com/minecraft/profile/skins";
const SKIN_RESET_URL: &str = "https://api.minecraftservices.com/minecraft/profile/skins/active";
const MAX_SKIN_BYTES: usize = 256 * 1024;

/// Проверяем png на месте, до сети: Mojang отвечает на кривой файл сухим 400,
/// а пользователю нужно понять, что именно не так.
pub fn validate_skin_png(data: &[u8]) -> anyhow::Result<(u32, u32)> {
    if data.is_empty() {
        anyhow::bail!("файл пустой");
    }
    if data.len() > MAX_SKIN_BYTES {
        anyhow::bail!("файл слишком большой ({} КБ), скин это маленький png", data.len() / 1024);
    }
    let Some((w, h)) = png_dimensions(data) else {
        anyhow::bail!("это не png-файл");
    };
    if !(w == 64 && (h == 64 || h == 32)) {
        anyhow::bail!("скин должен быть 64x64 (или старый формат 64x32), а тут {w}x{h}");
    }
    Ok((w, h))
}

/// Загружает скин официального аккаунта и возвращает URL новой текстуры.
pub async fn upload_official_skin(
    access_token: &str,
    png: Vec<u8>,
    slim: bool,
) -> anyhow::Result<Option<String>> {
    validate_skin_png(&png)?;

    let part = reqwest::multipart::Part::bytes(png)
        .file_name("skin.png")
        .mime_str("image/png")?;
    let form = reqwest::multipart::Form::new()
        .text("variant", if slim { "slim" } else { "classic" })
        .part("file", part);

    let resp = net::client()
        .put(SKIN_UPLOAD_URL)
        .bearer_auth(access_token)
        .multipart(form)
        .send()
        .await?;

    let status = resp.status();
    let text = resp.text().await.unwrap_or_default();
    if !status.is_success() {
        if status == reqwest::StatusCode::UNAUTHORIZED {
            anyhow::bail!("токен аккаунта истёк — переключись на аккаунт заново и повтори");
        }
        anyhow::bail!(
            "Mojang отклонил скин: HTTP {} — {}",
            status.as_u16(),
            truncate(&text, 300)
        );
    }

    // Ответ — свежий профиль с уже применённым скином.
    let profile: auth::McProfile = serde_json::from_str(&text)
        .map_err(|e| anyhow::anyhow!("не удалось прочитать ответ Mojang: {e}"))?;
    Ok(profile
        .active_skin()
        .map(|s| s.url.clone())
        .filter(|u| !u.is_empty()))
}

/// Сброс на стандартный скин Steve/Alex.
pub async fn reset_official_skin(access_token: &str) -> anyhow::Result<()> {
    let resp = net::client()
        .delete(SKIN_RESET_URL)
        .bearer_auth(access_token)
        .send()
        .await?;
    if !resp.status().is_success() {
        anyhow::bail!("не удалось сбросить скин: HTTP {}", resp.status().as_u16());
    }
    Ok(())
}

/// Кладёт png офлайн-аккаунта в папку лаунчера и возвращает путь.
pub fn save_local_skin(account_id: &str, png: &[u8]) -> anyhow::Result<PathBuf> {
    validate_skin_png(png)?;
    paths::ensure_dirs()?;
    let path = paths::skins_dir().join(format!("{}.png", paths::safe_component(account_id)));
    std::fs::write(&path, png)?;
    Ok(path)
}

pub fn remove_local_skin(account: &StoredAccount) {
    if let Some(path) = &account.skin_path {
        let _ = std::fs::remove_file(path);
    }
}

/// Что показать в превью: для официальных — URL Mojang, для офлайна —
/// data:-URL с локальным png (WebView не может читать файлы с диска напрямую).
pub fn skin_preview(account: &StoredAccount) -> Option<String> {
    if account.kind == AccountKind::Microsoft {
        if let Some(url) = &account.skin_url {
            if !url.is_empty() {
                return Some(url.clone());
            }
        }
    }
    let path = account.skin_path.as_ref()?;
    let bytes = std::fs::read(path).ok()?;
    Some(format!("data:image/png;base64,{}", base64_encode(&bytes)))
}

//! Поиск и скачивание модов/ресурс-паков из каталогов.
//!
//! Провайдеров два:
//!
//! * **Modrinth** (по умолчанию) — открытое API без ключей и лимитов на
//!   регистрацию. Работает сразу после сборки лаунчера.
//! * **CurseForge** — как в промте, но у их API есть деталь, которую промт
//!   пропускает: без заголовка `x-api-key` любой запрос отдаёт 403. Ключ
//!   выдаётся в консоли разработчика CurseForge и кладётся в
//!   `%APPDATA%/VitaLauncher/config.json` как `curseforge_api_key`
//!   (или в переменную окружения `VITA_CURSEFORGE_KEY`). Пока ключа нет,
//!   провайдер честно выключен в UI, а не падает с непонятным 403.
//!
//! Отдельно: CurseForge разрешает авторам мода запретить сторонние загрузки.
//! У таких файлов `downloadUrl` приходит пустым, и скачать их лаунчером
//! нельзя в принципе — показываем ссылку на страницу мода.

use serde::{Deserialize, Serialize};
use std::path::Path;

use crate::modloader::LoaderKind;
use crate::net;
use crate::paths;

const MODRINTH: &str = "https://api.modrinth.com/v2";
const CURSEFORGE: &str = "https://api.curseforge.com/v1";
const CF_GAME_MINECRAFT: u32 = 432;
const CF_CLASS_MODS: u32 = 6;
const CF_CLASS_RESOURCEPACKS: u32 = 12;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Provider {
    Modrinth,
    CurseForge,
}

impl Provider {
    pub fn parse(raw: &str) -> anyhow::Result<Self> {
        match raw.trim().to_ascii_lowercase().as_str() {
            "modrinth" | "" => Ok(Self::Modrinth),
            "curseforge" | "curse" => Ok(Self::CurseForge),
            other => anyhow::bail!("неизвестный каталог модов: {other}"),
        }
    }

    pub fn slug(&self) -> &'static str {
        match self {
            Self::Modrinth => "modrinth",
            Self::CurseForge => "curseforge",
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ContentKind {
    Mod,
    ResourcePack,
}

impl ContentKind {
    pub fn parse(raw: &str) -> Self {
        match raw.trim().to_ascii_lowercase().as_str() {
            "resourcepack" | "resource_pack" | "pack" => Self::ResourcePack,
            _ => Self::Mod,
        }
    }
}

#[derive(Debug, Clone, Serialize)]
pub struct ModInfo {
    /// id проекта в каталоге (строка у Modrinth, число у CurseForge).
    pub project_id: String,
    pub provider: String,
    pub slug: String,
    pub name: String,
    pub summary: String,
    pub author: String,
    pub downloads: u64,
    pub icon_url: String,
    pub page_url: String,
    pub categories: Vec<String>,
}

/// Deserialize тоже нужен: фронтенд возвращает выбранную версию обратно в
/// команду скачивания, чтобы не дёргать API второй раз.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModVersion {
    pub file_id: String,
    pub provider: String,
    pub display_name: String,
    pub filename: String,
    pub version: String,
    pub date: String,
    pub size: u64,
    pub sha1: String,
    pub download_url: String,
    pub game_versions: Vec<String>,
    pub loaders: Vec<String>,
    /// false у файлов, которым автор запретил сторонние загрузки.
    pub downloadable: bool,
}

/// Какие каталоги сейчас доступны (для UI).
#[derive(Debug, Clone, Serialize)]
pub struct ProviderStatus {
    pub provider: String,
    pub ready: bool,
    pub hint: Option<String>,
}

pub fn provider_status() -> Vec<ProviderStatus> {
    let cf_ready = paths::curseforge_key().is_some();
    vec![
        ProviderStatus {
            provider: "modrinth".to_string(),
            ready: true,
            hint: None,
        },
        ProviderStatus {
            provider: "curseforge".to_string(),
            ready: cf_ready,
            hint: if cf_ready {
                None
            } else {
                Some(
                    "Нужен ключ CurseForge API: добавь \"curseforge_api_key\" в config.json \
                     лаунчера. Modrinth работает без ключа."
                        .to_string(),
                )
            },
        },
    ]
}

// --- Поиск ------------------------------------------------------------

pub async fn search(
    provider: Provider,
    kind: ContentKind,
    query: &str,
    loader: LoaderKind,
    mc_version: &str,
    offset: u32,
) -> anyhow::Result<Vec<ModInfo>> {
    match provider {
        Provider::Modrinth => modrinth_search(kind, query, loader, mc_version, offset).await,
        Provider::CurseForge => curseforge_search(kind, query, loader, mc_version, offset).await,
    }
}

pub async fn versions(
    provider: Provider,
    project_id: &str,
    loader: LoaderKind,
    mc_version: &str,
    kind: ContentKind,
) -> anyhow::Result<Vec<ModVersion>> {
    match provider {
        Provider::Modrinth => modrinth_versions(project_id, loader, mc_version, kind).await,
        Provider::CurseForge => curseforge_versions(project_id, loader, mc_version).await,
    }
}

// --- Modrinth ---------------------------------------------------------

#[derive(Debug, Deserialize)]
struct MrSearch {
    #[serde(default)]
    hits: Vec<MrHit>,
}

#[derive(Debug, Deserialize)]
struct MrHit {
    project_id: String,
    #[serde(default)]
    slug: String,
    title: String,
    #[serde(default)]
    description: String,
    #[serde(default)]
    author: String,
    #[serde(default)]
    downloads: u64,
    #[serde(default)]
    icon_url: Option<String>,
    #[serde(default)]
    categories: Vec<String>,
}

#[derive(Debug, Deserialize)]
struct MrVersion {
    id: String,
    #[serde(default)]
    name: String,
    #[serde(default)]
    version_number: String,
    #[serde(default)]
    date_published: String,
    #[serde(default)]
    game_versions: Vec<String>,
    #[serde(default)]
    loaders: Vec<String>,
    #[serde(default)]
    files: Vec<MrFile>,
}

#[derive(Debug, Deserialize)]
struct MrFile {
    url: String,
    filename: String,
    #[serde(default)]
    size: u64,
    #[serde(default)]
    primary: bool,
    #[serde(default)]
    hashes: std::collections::HashMap<String, String>,
}

async fn modrinth_search(
    kind: ContentKind,
    query: &str,
    loader: LoaderKind,
    mc_version: &str,
    offset: u32,
) -> anyhow::Result<Vec<ModInfo>> {
    let project_type = match kind {
        ContentKind::Mod => "mod",
        ContentKind::ResourcePack => "resourcepack",
    };
    let mut facets: Vec<String> = vec![format!("[\"project_type:{project_type}\"]")];
    if !mc_version.is_empty() {
        facets.push(format!("[\"versions:{mc_version}\"]"));
    }
    // Для ресурс-паков фильтр по loader'у только сузит выдачу без пользы.
    if kind == ContentKind::Mod {
        if let Some(id) = loader.modrinth_id() {
            facets.push(format!("[\"categories:{id}\"]"));
        }
    }
    let url = format!(
        "{MODRINTH}/search?query={}&limit=20&offset={offset}&index=relevance&facets=[{}]",
        urlencode(query),
        facets.join(",")
    );

    let resp = net::client().get(url.as_str()).send().await?;
    let status = resp.status();
    let text = resp.text().await?;
    if !status.is_success() {
        anyhow::bail!(
            "Modrinth ответил HTTP {}: {}",
            status.as_u16(),
            crate::util::truncate(&text, 200)
        );
    }
    let parsed: MrSearch = serde_json::from_str(&text)?;
    Ok(parsed
        .hits
        .into_iter()
        .map(|hit| ModInfo {
            page_url: format!(
                "https://modrinth.com/{}/{}",
                if kind == ContentKind::Mod { "mod" } else { "resourcepack" },
                if hit.slug.is_empty() { hit.project_id.clone() } else { hit.slug.clone() }
            ),
            project_id: hit.project_id,
            provider: "modrinth".to_string(),
            slug: hit.slug,
            name: hit.title,
            summary: hit.description,
            author: hit.author,
            downloads: hit.downloads,
            icon_url: hit.icon_url.unwrap_or_default(),
            categories: hit.categories,
        })
        .collect())
}

async fn modrinth_versions(
    project_id: &str,
    loader: LoaderKind,
    mc_version: &str,
    kind: ContentKind,
) -> anyhow::Result<Vec<ModVersion>> {
    let mut url = format!("{MODRINTH}/project/{}/version", urlencode(project_id));
    let mut params: Vec<String> = Vec::new();
    if !mc_version.is_empty() {
        params.push(format!("game_versions=[\"{mc_version}\"]"));
    }
    if kind == ContentKind::Mod {
        if let Some(id) = loader.modrinth_id() {
            params.push(format!("loaders=[\"{id}\"]"));
        }
    }
    if !params.is_empty() {
        url.push('?');
        url.push_str(&params.join("&"));
    }

    let resp = net::client().get(url.as_str()).send().await?;
    let status = resp.status();
    let text = resp.text().await?;
    if !status.is_success() {
        anyhow::bail!("Modrinth ответил HTTP {}", status.as_u16());
    }
    let parsed: Vec<MrVersion> = serde_json::from_str(&text)?;

    Ok(parsed
        .into_iter()
        .filter_map(|v| {
            let file = v
                .files
                .iter()
                .find(|f| f.primary)
                .or_else(|| v.files.first())?
                .clone_shallow();
            Some(ModVersion {
                file_id: v.id,
                provider: "modrinth".to_string(),
                display_name: if v.name.is_empty() {
                    v.version_number.clone()
                } else {
                    v.name
                },
                filename: file.filename,
                version: v.version_number,
                date: v.date_published,
                size: file.size,
                sha1: file.sha1,
                download_url: file.url,
                game_versions: v.game_versions,
                loaders: v.loaders,
                downloadable: true,
            })
        })
        .collect())
}

/// Плоская копия файла Modrinth без лишних полей.
struct FlatFile {
    url: String,
    filename: String,
    size: u64,
    sha1: String,
}

impl MrFile {
    fn clone_shallow(&self) -> FlatFile {
        FlatFile {
            url: self.url.clone(),
            filename: self.filename.clone(),
            size: self.size,
            sha1: self.hashes.get("sha1").cloned().unwrap_or_default(),
        }
    }
}

// --- CurseForge -------------------------------------------------------

fn cf_request(url: &str) -> anyhow::Result<reqwest::RequestBuilder> {
    let key = paths::curseforge_key().ok_or_else(|| {
        anyhow::anyhow!(
            "CurseForge требует API-ключ. Добавь \"curseforge_api_key\" в config.json \
             лаунчера или используй Modrinth — он работает без ключа."
        )
    })?;
    Ok(net::client()
        .get(url)
        .header("x-api-key", key)
        .header("Accept", "application/json"))
}

#[derive(Debug, Deserialize)]
struct CfList<T> {
    #[serde(default)]
    data: Vec<T>,
}

#[derive(Debug, Deserialize)]
struct CfOne<T> {
    data: T,
}

#[derive(Debug, Deserialize, Default)]
struct CfMod {
    id: u32,
    name: String,
    #[serde(default)]
    slug: String,
    #[serde(default)]
    summary: String,
    #[serde(rename = "downloadCount", default)]
    download_count: f64,
    #[serde(default)]
    authors: Vec<CfAuthor>,
    #[serde(default)]
    logo: Option<CfLogo>,
    #[serde(default)]
    links: Option<CfLinks>,
}

#[derive(Debug, Deserialize)]
struct CfAuthor {
    #[serde(default)]
    name: String,
}

#[derive(Debug, Deserialize)]
struct CfLogo {
    #[serde(rename = "thumbnailUrl", default)]
    thumbnail_url: String,
}

#[derive(Debug, Deserialize)]
struct CfLinks {
    #[serde(rename = "websiteUrl", default)]
    website_url: Option<String>,
}

#[derive(Debug, Deserialize, Default)]
struct CfFile {
    id: u32,
    #[serde(rename = "displayName", default)]
    display_name: String,
    #[serde(rename = "fileName", default)]
    file_name: String,
    #[serde(rename = "fileDate", default)]
    file_date: String,
    #[serde(rename = "fileLength", default)]
    file_length: u64,
    #[serde(rename = "downloadUrl", default)]
    download_url: Option<String>,
    #[serde(rename = "gameVersions", default)]
    game_versions: Vec<String>,
    #[serde(default)]
    hashes: Vec<CfHash>,
}

#[derive(Debug, Deserialize)]
struct CfHash {
    value: String,
    /// 1 = sha1, 2 = md5
    algo: u32,
}

async fn curseforge_search(
    kind: ContentKind,
    query: &str,
    loader: LoaderKind,
    mc_version: &str,
    offset: u32,
) -> anyhow::Result<Vec<ModInfo>> {
    let class_id = match kind {
        ContentKind::Mod => CF_CLASS_MODS,
        ContentKind::ResourcePack => CF_CLASS_RESOURCEPACKS,
    };
    let mut url = format!(
        "{CURSEFORGE}/mods/search?gameId={CF_GAME_MINECRAFT}&classId={class_id}\
         &pageSize=20&index={offset}&sortField=2&sortOrder=desc&searchFilter={}",
        urlencode(query)
    );
    if !mc_version.is_empty() {
        url.push_str(&format!("&gameVersion={}", urlencode(mc_version)));
    }
    if kind == ContentKind::Mod {
        if let Some(id) = loader.curseforge_id() {
            url.push_str(&format!("&modLoaderType={id}"));
        }
    }

    let resp = cf_request(&url)?.send().await?;
    let status = resp.status();
    let text = resp.text().await?;
    if status.as_u16() == 403 {
        anyhow::bail!("CurseForge отклонил ключ API (403). Проверь curseforge_api_key.");
    }
    if !status.is_success() {
        anyhow::bail!(
            "CurseForge ответил HTTP {}: {}",
            status.as_u16(),
            crate::util::truncate(&text, 200)
        );
    }
    let parsed: CfList<CfMod> = serde_json::from_str(&text)?;
    Ok(parsed
        .data
        .into_iter()
        .map(|m| ModInfo {
            page_url: m
                .links
                .and_then(|l| l.website_url)
                .unwrap_or_else(|| format!("https://www.curseforge.com/minecraft/mc-mods/{}", m.slug)),
            project_id: m.id.to_string(),
            provider: "curseforge".to_string(),
            slug: m.slug,
            name: m.name,
            summary: m.summary,
            author: m
                .authors
                .into_iter()
                .map(|a| a.name)
                .collect::<Vec<_>>()
                .join(", "),
            downloads: m.download_count as u64,
            icon_url: m.logo.map(|l| l.thumbnail_url).unwrap_or_default(),
            categories: Vec::new(),
        })
        .collect())
}

async fn curseforge_versions(
    project_id: &str,
    loader: LoaderKind,
    mc_version: &str,
) -> anyhow::Result<Vec<ModVersion>> {
    let mut url = format!("{CURSEFORGE}/mods/{}/files?pageSize=30", urlencode(project_id));
    if !mc_version.is_empty() {
        url.push_str(&format!("&gameVersion={}", urlencode(mc_version)));
    }
    if let Some(id) = loader.curseforge_id() {
        url.push_str(&format!("&modLoaderType={id}"));
    }

    let resp = cf_request(&url)?.send().await?;
    let status = resp.status();
    let text = resp.text().await?;
    if !status.is_success() {
        anyhow::bail!("CurseForge ответил HTTP {}", status.as_u16());
    }
    let parsed: CfList<CfFile> = serde_json::from_str(&text)?;

    Ok(parsed
        .data
        .into_iter()
        .map(|f| {
            let loaders: Vec<String> = f
                .game_versions
                .iter()
                .filter(|v| {
                    let low = v.to_ascii_lowercase();
                    low == "forge" || low == "fabric" || low == "neoforge" || low == "quilt"
                })
                .map(|v| v.to_ascii_lowercase())
                .collect();
            let game_versions: Vec<String> = f
                .game_versions
                .iter()
                .filter(|v| v.chars().next().is_some_and(|c| c.is_ascii_digit()))
                .cloned()
                .collect();
            let url = f.download_url.unwrap_or_default();
            ModVersion {
                file_id: f.id.to_string(),
                provider: "curseforge".to_string(),
                display_name: f.display_name,
                filename: f.file_name,
                version: String::new(),
                date: f.file_date,
                size: f.file_length,
                sha1: f
                    .hashes
                    .into_iter()
                    .find(|h| h.algo == 1)
                    .map(|h| h.value)
                    .unwrap_or_default(),
                downloadable: !url.is_empty(),
                download_url: url,
                game_versions,
                loaders,
            }
        })
        .collect())
}

/// Ссылка на файл CurseForge, если в списке файлов её не отдали.
async fn curseforge_download_url(project_id: &str, file_id: &str) -> anyhow::Result<String> {
    let url = format!(
        "{CURSEFORGE}/mods/{}/files/{}/download-url",
        urlencode(project_id),
        urlencode(file_id)
    );
    let resp = cf_request(&url)?.send().await?;
    let status = resp.status();
    let text = resp.text().await?;
    if !status.is_success() {
        anyhow::bail!("CurseForge не отдал ссылку на файл (HTTP {})", status.as_u16());
    }
    let parsed: CfOne<Option<String>> = serde_json::from_str(&text)?;
    parsed.data.filter(|s| !s.is_empty()).ok_or_else(|| {
        anyhow::anyhow!(
            "автор мода запретил сторонние загрузки — скачай файл вручную \
             со страницы мода и добавь кнопкой «Из файла»"
        )
    })
}

// --- Скачивание -------------------------------------------------------

pub struct Downloaded {
    pub filename: String,
    pub sha1: String,
    pub size: u64,
    pub url: String,
}

/// Кладёт файл в указанную папку. Если файл уже там и sha1 совпал — не качаем
/// заново (ровно тот сценарий из промта «мод уже установлен»).
pub async fn download_file(
    provider: Provider,
    project_id: &str,
    version: &ModVersion,
    dir: &Path,
) -> anyhow::Result<Downloaded> {
    let filename = crate::mods::sanitize_filename(&version.filename)?;
    let dest = dir.join(&filename);
    tokio::fs::create_dir_all(dir).await?;

    let url = if version.download_url.is_empty() {
        match provider {
            Provider::CurseForge => curseforge_download_url(project_id, &version.file_id).await?,
            Provider::Modrinth => anyhow::bail!("Modrinth не отдал ссылку на файл"),
        }
    } else {
        version.download_url.clone()
    };
    net::ensure_download_url(&url)?;

    if dest.exists() && !version.sha1.is_empty() {
        if let Ok(actual) = crate::mods::sha1_file(&dest) {
            if actual.eq_ignore_ascii_case(&version.sha1) {
                return Ok(Downloaded {
                    filename,
                    sha1: actual,
                    size: version.size,
                    url,
                });
            }
        }
    }

    let sha1 = Some(version.sha1.as_str()).filter(|s| !s.is_empty());
    let size = Some(version.size).filter(|s| *s > 0);
    crate::version_manager::download_verified(&url, &dest, sha1, size).await?;

    let actual_sha1 = crate::mods::sha1_file(&dest).unwrap_or_default();
    let actual_size = tokio::fs::metadata(&dest).await.map(|m| m.len()).unwrap_or(0);
    Ok(Downloaded {
        filename,
        sha1: actual_sha1,
        size: actual_size,
        url,
    })
}

/// Fabric API — не библиотека загрузчика, а обычный мод (в промте он попал в
/// libraries/, где не заработает). Ставим его из Modrinth по slug.
pub async fn install_fabric_api(mc_version: &str, dir: &Path) -> anyhow::Result<String> {
    let versions =
        modrinth_versions("fabric-api", LoaderKind::Fabric, mc_version, ContentKind::Mod).await?;
    let latest = versions
        .into_iter()
        .next()
        .ok_or_else(|| anyhow::anyhow!("для {mc_version} нет сборки Fabric API"))?;
    let downloaded = download_file(Provider::Modrinth, "fabric-api", &latest, dir).await?;
    Ok(downloaded.filename)
}

fn urlencode(raw: &str) -> String {
    let mut out = String::with_capacity(raw.len());
    for byte in raw.as_bytes() {
        match byte {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => {
                out.push(*byte as char)
            }
            b' ' => out.push_str("%20"),
            other => out.push_str(&format!("%{other:02X}")),
        }
    }
    out
}

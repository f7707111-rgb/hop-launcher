//! Определение и установка модлоадеров (Forge, Fabric).
//!
//! Главное, что стоит понять про эту часть: **модлоадер — это отдельная версия**,
//! а не флаг у ванильной. И Forge installer, и Fabric meta отдают JSON-профиль с
//! `inheritsFrom`, своим `mainClass` и своим набором библиотек. Поэтому мы не
//! правим ванильный `versions/<id>.json` (иначе первая же проверка кэша или
//! перекачка версии затрёт правки, а ваниль перестанет запускаться), а создаём
//! рядом новый профиль:
//!
//! ```text
//! versions/1.20.1/1.20.1.json                              ← ваниль, не трогаем
//! versions/1.20.1-forge-47.3.12/1.20.1-forge-47.3.12.json   ← профиль Forge
//! versions/fabric-loader-0.16.9-1.20.1/...json              ← профиль Fabric
//! ```
//!
//! Склейку профиля с родителем делает `version_manager::resolve_detail`.
//!
//! Про `mainClass`: его НЕ надо угадывать. В промте были
//! `FMLServerTweaker` и `net.fabricmc.loader.launch.knot.KnotClient` — первый
//! серверный, второй из старой раскладки пакетов Fabric. Реальные значения
//! зависят от версии (`net.minecraft.launchwrapper.Launch` для Forge 1.12-,
//! `cpw.mods.bootstraplauncher.BootstrapLauncher` для 1.17+ и т.д.), и они уже
//! лежат в профиле, который отдаёт installer/meta. Берём оттуда.

use std::collections::HashMap;
use std::path::Path;
use std::process::Command;

use serde::{Deserialize, Serialize};

use crate::net;
use crate::version_manager as vm;

const FORGE_MAVEN: &str = "https://maven.minecraftforge.net/net/minecraftforge/forge";
const FORGE_METADATA: &str = "https://files.minecraftforge.net/net/minecraftforge/forge/maven-metadata.json";
const FORGE_PROMOS: &str = "https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json";
const FABRIC_META: &str = "https://meta.fabricmc.net/v2/versions";

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum LoaderKind {
    Vanilla,
    Forge,
    Fabric,
}

impl LoaderKind {
    pub fn parse(raw: &str) -> anyhow::Result<Self> {
        match raw.trim().to_ascii_lowercase().as_str() {
            "vanilla" | "" => Ok(Self::Vanilla),
            "forge" => Ok(Self::Forge),
            "fabric" => Ok(Self::Fabric),
            other => anyhow::bail!("неизвестный модлоадер: {other}"),
        }
    }

    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Vanilla => "Vanilla",
            Self::Forge => "Forge",
            Self::Fabric => "Fabric",
        }
    }

    /// Код загрузчика в API CurseForge (1 = Forge, 4 = Fabric).
    pub fn curseforge_id(&self) -> Option<u32> {
        match self {
            Self::Forge => Some(1),
            Self::Fabric => Some(4),
            Self::Vanilla => None,
        }
    }

    /// Идентификатор загрузчика в Modrinth.
    pub fn modrinth_id(&self) -> Option<&'static str> {
        match self {
            Self::Forge => Some("forge"),
            Self::Fabric => Some("fabric"),
            Self::Vanilla => None,
        }
    }
}

#[derive(Debug, Clone, Serialize)]
pub struct LoaderInfo {
    pub kind: LoaderKind,
    /// Версия самого загрузчика ("47.3.12", "0.16.9").
    pub version: String,
    /// id профиля в versions/ (== ванильный id для Vanilla).
    pub profile_id: String,
    /// Версия Minecraft, к которой профиль привязан.
    pub mc_version: String,
    pub installed: bool,
}

#[derive(Debug, Clone, Serialize)]
pub struct LoaderVersion {
    pub version: String,
    pub stable: bool,
    /// "recommended" / "latest" / "" — подсказка для UI.
    pub tag: String,
}

#[derive(Debug, Clone, Serialize)]
pub struct LoaderOptions {
    pub mc_version: String,
    pub forge: Vec<LoaderVersion>,
    pub fabric: Vec<LoaderVersion>,
    /// Уже установленные профили для этой версии MC.
    pub installed: Vec<LoaderInfo>,
    pub notes: Vec<String>,
}

// --- Определение установленного loader'а ------------------------------

/// Что за loader стоит в этом профиле. Смотрим на сам профиль, а не на
/// содержимое `mods/`: пустая папка модов у Forge-сборки — это нормально, а вот
/// профиль без библиотек Forge/Fabric модов точно не загрузит.
pub fn detect_loader(game_dir: &Path, version_id: &str) -> Option<LoaderInfo> {
    let detail = vm::read_local_detail(game_dir, version_id)?;
    let mc_version = detail
        .inherits_from
        .clone()
        .unwrap_or_else(|| detail.id.clone());
    let installed = vm::is_installed(game_dir, version_id);

    let lib_names: Vec<String> = detail
        .libraries
        .iter()
        .map(|l| l.name.to_ascii_lowercase())
        .collect();
    let main = detail.main_class.to_ascii_lowercase();
    let id_lower = detail.id.to_ascii_lowercase();

    let find_version = |needle: &str| -> Option<String> {
        lib_names
            .iter()
            .find(|n| n.contains(needle))
            .and_then(|n| n.split(':').nth(2).map(|s| s.to_string()))
    };

    if main.contains("fabric") || id_lower.contains("fabric") {
        let version = find_version("fabric-loader")
            .or_else(|| version_from_profile_id(&detail.id, "fabric-loader-"))
            .unwrap_or_default();
        return Some(LoaderInfo {
            kind: LoaderKind::Fabric,
            version,
            profile_id: detail.id,
            mc_version,
            installed,
        });
    }
    if main.contains("fml")
        || main.contains("bootstraplauncher")
        || main.contains("launchwrapper")
        || id_lower.contains("forge")
    {
        let version = find_version("net.minecraftforge:forge")
            .or_else(|| find_version("net.minecraftforge:fmlloader"))
            .map(|v| v.split('-').next_back().unwrap_or_default().to_string())
            .filter(|v| !v.is_empty())
            .or_else(|| forge_version_from_id(&detail.id))
            .unwrap_or_default();
        return Some(LoaderInfo {
            kind: LoaderKind::Forge,
            version,
            profile_id: detail.id,
            mc_version,
            installed,
        });
    }

    Some(LoaderInfo {
        kind: LoaderKind::Vanilla,
        version: String::new(),
        profile_id: detail.id,
        mc_version,
        installed,
    })
}

fn version_from_profile_id(id: &str, prefix: &str) -> Option<String> {
    // fabric-loader-0.16.9-1.20.1 → 0.16.9
    let rest = id.strip_prefix(prefix)?;
    let mut parts: Vec<&str> = rest.split('-').collect();
    if parts.len() > 1 {
        parts.pop();
    }
    Some(parts.join("-"))
}

fn forge_version_from_id(id: &str) -> Option<String> {
    // 1.20.1-forge-47.3.12 → 47.3.12 ; 1.12.2-forge1.12.2-14.23.5.2859 → 14.23.5.2859
    let idx = id.to_ascii_lowercase().find("forge")?;
    let tail = &id[idx + "forge".len()..];
    let tail = tail.trim_start_matches('-');
    let candidate = tail.split('-').next_back().unwrap_or(tail);
    if candidate.is_empty() {
        None
    } else {
        Some(candidate.to_string())
    }
}

/// Все профили в versions/: и ваниль, и сборки. Для выпадающего списка.
pub fn list_profiles(game_dir: &Path) -> Vec<LoaderInfo> {
    let mut out: Vec<LoaderInfo> = vm::local_version_ids(game_dir)
        .into_iter()
        .filter_map(|id| detect_loader(game_dir, &id))
        .collect();
    out.sort_by(|a, b| a.profile_id.cmp(&b.profile_id));
    out
}

// --- Какие loader'ы доступны для версии MC ----------------------------

#[derive(Debug, Deserialize)]
struct ForgePromos {
    #[serde(default)]
    promos: HashMap<String, String>,
}

#[derive(Debug, Deserialize)]
struct FabricLoaderEntry {
    loader: FabricLoaderMeta,
}

#[derive(Debug, Deserialize)]
struct FabricLoaderMeta {
    version: String,
    #[serde(default)]
    stable: bool,
}

pub async fn available_loaders(game_dir: &Path, mc_version: &str) -> LoaderOptions {
    let mut notes: Vec<String> = Vec::new();

    let forge = match forge_versions(mc_version).await {
        Ok(list) => list,
        Err(err) => {
            notes.push(format!("Список сборок Forge недоступен: {err}"));
            Vec::new()
        }
    };
    let fabric = match fabric_versions(mc_version).await {
        Ok(list) => list,
        Err(err) => {
            notes.push(format!("Список сборок Fabric недоступен: {err}"));
            Vec::new()
        }
    };
    if forge.is_empty() {
        notes.push(format!("Для {mc_version} нет сборок Forge."));
    }
    if fabric.is_empty() {
        notes.push(format!(
            "Fabric не поддерживает {mc_version} (он существует с 1.14)."
        ));
    }

    let installed: Vec<LoaderInfo> = list_profiles(game_dir)
        .into_iter()
        .filter(|p| p.mc_version == mc_version && p.kind != LoaderKind::Vanilla)
        .collect();

    LoaderOptions {
        mc_version: mc_version.to_string(),
        forge,
        fabric,
        installed,
        notes,
    }
}

/// Все сборки Forge под версию MC, свежие сверху, с пометками
/// recommended/latest из promotions_slim.
pub async fn forge_versions(mc_version: &str) -> anyhow::Result<Vec<LoaderVersion>> {
    let resp = net::client().get(FORGE_METADATA).send().await?;
    if !resp.status().is_success() {
        anyhow::bail!("HTTP {}", resp.status().as_u16());
    }
    let all: HashMap<String, Vec<String>> = resp.json().await?;
    let Some(builds) = all.get(mc_version) else {
        return Ok(Vec::new());
    };

    // promotions_slim: какая сборка recommended, а какая latest. Если файл
    // недоступен — не беда, просто не будет пометок.
    let empty = ForgePromos {
        promos: HashMap::new(),
    };
    let promos = match net::client().get(FORGE_PROMOS).send().await {
        Ok(resp) if resp.status().is_success() => resp.json::<ForgePromos>().await.unwrap_or(empty),
        _ => empty,
    };
    let recommended = promos.promos.get(&format!("{mc_version}-recommended")).cloned();
    let latest = promos.promos.get(&format!("{mc_version}-latest")).cloned();

    let mut out: Vec<LoaderVersion> = builds
        .iter()
        .rev()
        .map(|raw| {
            // В maven-metadata версии лежат как "1.20.1-47.3.12" или
            // "1.7.10-10.13.4.1614-1.7.10".
            let build = raw
                .strip_prefix(&format!("{mc_version}-"))
                .unwrap_or(raw)
                .to_string();
            let short = build
                .strip_suffix(&format!("-{mc_version}"))
                .unwrap_or(&build)
                .to_string();
            let tag = if recommended.as_deref() == Some(short.as_str()) {
                "recommended"
            } else if latest.as_deref() == Some(short.as_str()) {
                "latest"
            } else {
                ""
            };
            LoaderVersion {
                version: build,
                stable: tag == "recommended",
                tag: tag.to_string(),
            }
        })
        .collect();

    // recommended наверх — это то, что нужно 95% пользователей.
    out.sort_by_key(|v| match v.tag.as_str() {
        "recommended" => 0,
        "latest" => 1,
        _ => 2,
    });
    Ok(out)
}

pub async fn fabric_versions(mc_version: &str) -> anyhow::Result<Vec<LoaderVersion>> {
    let url = format!("{FABRIC_META}/loader/{mc_version}");
    let resp = net::client().get(url.as_str()).send().await?;
    if resp.status() == reqwest::StatusCode::BAD_REQUEST || resp.status().as_u16() == 404 {
        return Ok(Vec::new());
    }
    if !resp.status().is_success() {
        anyhow::bail!("HTTP {}", resp.status().as_u16());
    }
    let entries: Vec<FabricLoaderEntry> = resp.json().await.unwrap_or_default();
    Ok(entries
        .into_iter()
        .map(|e| LoaderVersion {
            stable: e.loader.stable,
            tag: if e.loader.stable { "stable" } else { "" }.to_string(),
            version: e.loader.version,
        })
        .collect())
}

// --- Установка --------------------------------------------------------

/// Ставит модлоадер и возвращает id созданного профиля.
///
/// Ванильная версия к этому моменту должна быть уже установлена: installer
/// Forge проверяет наличие client.jar и его хэш, а Fabric без ассетов родителя
/// всё равно не запустится.
pub async fn install_loader<F>(
    game_dir: &Path,
    kind: LoaderKind,
    mc_version: &str,
    loader_version: &str,
    java_path: &str,
    on_status: F,
) -> anyhow::Result<String>
where
    F: Fn(&str) + Send + Sync,
{
    match kind {
        LoaderKind::Vanilla => Ok(mc_version.to_string()),
        LoaderKind::Fabric => install_fabric(game_dir, mc_version, loader_version, &on_status).await,
        LoaderKind::Forge => {
            install_forge(game_dir, mc_version, loader_version, java_path, &on_status).await
        }
    }
}

/// Fabric ставится без installer-jar и без java: meta отдаёт готовый профиль.
async fn install_fabric<F>(
    game_dir: &Path,
    mc_version: &str,
    loader_version: &str,
    on_status: &F,
) -> anyhow::Result<String>
where
    F: Fn(&str) + Send + Sync,
{
    let loader_version = if loader_version.trim().is_empty() {
        fabric_versions(mc_version)
            .await?
            .into_iter()
            .find(|v| v.stable)
            .map(|v| v.version)
            .ok_or_else(|| anyhow::anyhow!("для {mc_version} нет стабильного Fabric Loader"))?
    } else {
        loader_version.trim().to_string()
    };

    on_status(&format!("Fabric {loader_version}: получаю профиль"));
    let url = format!("{FABRIC_META}/loader/{mc_version}/{loader_version}/profile/json");
    let resp = net::client().get(url.as_str()).send().await?;
    let status = resp.status();
    let text = resp.text().await?;
    if !status.is_success() {
        anyhow::bail!(
            "Fabric meta ответил HTTP {}: {}",
            status.as_u16(),
            crate::util::truncate(&text, 200)
        );
    }

    let parsed: serde_json::Value = serde_json::from_str(&text)?;
    let profile_id = parsed
        .get("id")
        .and_then(|v| v.as_str())
        .unwrap_or("")
        .to_string();
    if profile_id.is_empty() {
        anyhow::bail!("в профиле Fabric нет id");
    }

    vm::write_version_json(game_dir, &profile_id, &text).await?;
    on_status(&format!("Профиль {profile_id} создан"));
    Ok(profile_id)
}

/// Forge ставится своим installer-jar в headless-режиме.
///
/// Тонкости, на которых спотыкаются все:
///  * ключ `--installClient`, а не `--installServer` (серверная установка
///    поставит серверные библиотеки и mainClass, клиент с ними не поднимется);
///  * installer требует `launcher_profiles.json` в игровой папке, иначе падает
///    с "The Minecraft Launcher is not installed"; создаём заглушку;
///  * installer сам решает, как назвать профиль, и для старых версий имя не
///    равно `<mc>-forge-<build>`. Поэтому смотрим, какая папка появилась в
///    versions/ после запуска, а не угадываем.
async fn install_forge<F>(
    game_dir: &Path,
    mc_version: &str,
    loader_version: &str,
    java_path: &str,
    on_status: &F,
) -> anyhow::Result<String>
where
    F: Fn(&str) + Send + Sync,
{
    if java_path.trim().is_empty() {
        anyhow::bail!("installer Forge — это jar, без java его не запустить. Укажи путь к java.");
    }
    let build = if loader_version.trim().is_empty() {
        forge_versions(mc_version)
            .await?
            .into_iter()
            .next()
            .map(|v| v.version)
            .ok_or_else(|| anyhow::anyhow!("для {mc_version} нет сборок Forge"))?
    } else {
        loader_version.trim().to_string()
    };

    // Java 8 не осилит installer для 1.17+, а Java 21 — installer для 1.7.10.
    if let Some(major) = crate::launcher::java_major_version(java_path) {
        let needed = required_java_major(mc_version);
        if major < needed {
            anyhow::bail!(
                "installer Forge для {mc_version} требует Java {needed}+, а найдена Java {major}."
            );
        }
        if major >= 21 && is_ancient(mc_version) {
            anyhow::bail!(
                "installer Forge для {mc_version} не работает на Java {major}. \
                 Для версий 1.12 и старше нужна Java 8."
            );
        }
    }

    let installer = download_forge_installer(mc_version, &build, on_status).await?;

    // launcher_profiles.json — формальность, но без него installer не начнёт.
    let profiles = crate::paths::launcher_profiles_file();
    if !profiles.exists() {
        if let Some(parent) = profiles.parent() {
            tokio::fs::create_dir_all(parent).await?;
        }
        tokio::fs::write(
            &profiles,
            r#"{"profiles":{},"settings":{},"version":3}"#.as_bytes(),
        )
        .await?;
    }

    let before: std::collections::HashSet<String> =
        vm::local_version_ids(game_dir).into_iter().collect();

    on_status(&format!(
        "Forge {build}: запускаю installer (это самая долгая часть, до пары минут)"
    ));
    let java = java_path.to_string();
    let installer_path = installer.clone();
    let target = game_dir.to_path_buf();
    let output = tokio::task::spawn_blocking(move || {
        std::fs::create_dir_all(&target).ok();
        let mut cmd = Command::new(&java);
        cmd.arg("-jar")
            .arg(&installer_path)
            .arg("--installClient")
            .arg(&target)
            .current_dir(&target);
        #[cfg(target_os = "windows")]
        {
            use std::os::windows::process::CommandExt;
            cmd.creation_flags(0x0800_0000); // CREATE_NO_WINDOW
        }
        cmd.output()
    })
    .await??;

    let log = format!(
        "{}{}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    let after: Vec<String> = vm::local_version_ids(game_dir);
    let created: Option<String> = after
        .iter()
        .filter(|id| !before.contains(*id))
        .find(|id| id.to_ascii_lowercase().contains("forge"))
        .cloned()
        .or_else(|| {
            // Повторная установка того же Forge: папка уже была.
            after
                .iter()
                .find(|id| {
                    let low = id.to_ascii_lowercase();
                    low.contains("forge") && low.contains(&mc_version.to_ascii_lowercase())
                })
                .cloned()
        });

    match created {
        Some(id) if output.status.success() => {
            on_status(&format!("Профиль {id} создан"));
            Ok(id)
        }
        _ => {
            anyhow::bail!(
                "installer Forge завершился с кодом {} и профиль не появился.\n{}",
                output.status.code().unwrap_or(-1),
                crate::util::truncate(&log, 1200)
            )
        }
    }
}

async fn download_forge_installer<F>(
    mc_version: &str,
    build: &str,
    on_status: &F,
) -> anyhow::Result<std::path::PathBuf>
where
    F: Fn(&str) + Send + Sync,
{
    let cache = crate::paths::loader_cache_dir();
    tokio::fs::create_dir_all(&cache).await?;

    // Имя артефакта в maven: обычно <mc>-<build>, у старых версий с хвостом.
    let candidates = [
        format!("{mc_version}-{build}"),
        format!("{mc_version}-{build}-{mc_version}"),
    ];
    let mut last_err = None;
    for coord in candidates {
        let file = format!("forge-{coord}-installer.jar");
        let url = format!("{FORGE_MAVEN}/{coord}/{file}");
        net::ensure_download_url(&url)?;
        let dest = cache.join(&file);
        if dest.exists() {
            on_status("installer Forge уже в кэше");
            return Ok(dest);
        }
        on_status(&format!("Качаю {file}"));
        match vm::download_verified(&url, &dest, None, None).await {
            Ok(()) => return Ok(dest),
            Err(err) => last_err = Some(err),
        }
    }
    Err(last_err.unwrap_or_else(|| anyhow::anyhow!("не удалось скачать installer Forge")))
}

/// Минимальная мажорная версия java для installer'а под эту версию MC.
fn required_java_major(mc_version: &str) -> u32 {
    let (major, minor) = parse_mc_version(mc_version);
    if major == 1 && minor >= 20 {
        17
    } else if major == 1 && minor >= 17 {
        16
    } else {
        8
    }
}

fn is_ancient(mc_version: &str) -> bool {
    let (major, minor) = parse_mc_version(mc_version);
    major == 1 && minor <= 12
}

fn parse_mc_version(mc_version: &str) -> (u32, u32) {
    let mut parts = mc_version.split('.');
    let major = parts.next().and_then(|p| p.parse().ok()).unwrap_or(1);
    let minor = parts.next().and_then(|p| p.parse().ok()).unwrap_or(0);
    (major, minor)
}

/// Дополнительные JVM-аргументы, которые лаунчер добавляет сам.
/// Для Forge исторически нужен игнор невалидных сертификатов клиента.
pub fn extra_jvm_args(kind: LoaderKind) -> Vec<String> {
    match kind {
        LoaderKind::Forge => vec![
            "-Dfml.ignoreInvalidMinecraftCertificates=true".to_string(),
            "-Dfml.ignorePatchDiscrepancies=true".to_string(),
        ],
        _ => Vec::new(),
    }
}

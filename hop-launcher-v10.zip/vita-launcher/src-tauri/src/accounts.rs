//! Хранилище аккаунтов: %APPDATA%/VitaLauncher/accounts.json
//!
//! Держим сколько угодно аккаунтов обоих типов одновременно, помним последний
//! использованный и (для официальных) refresh_token, чтобы не гонять человека
//! в браузер на каждый запуск.
//!
//! ВНИМАНИЕ по безопасности: токены лежат в открытом JSON рядом с лаунчером —
//! ровно так же, как это делает большинство сторонних лаунчеров. Файл доступен
//! только текущему пользователю ОС. Если понадобится хранить их в системном
//! keychain — это отдельная задача (tauri-plugin-stronghold / keyring).

use serde::{Deserialize, Serialize};
use uuid::Uuid;

use crate::paths;
use crate::util::now_unix;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum AccountKind {
    Offline,
    Microsoft,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StoredAccount {
    /// Внутренний id записи в лаунчере (не путать с uuid игрока).
    pub id: String,
    pub username: String,
    /// UUID игрока: детерминированный для офлайна, реальный для официального.
    pub uuid: String,
    pub kind: AccountKind,
    /// Токен, который уходит игре в --accessToken.
    pub access_token: String,
    /// Только для официальных: MS refresh_token для тихого обновления.
    #[serde(default)]
    pub refresh_token: Option<String>,
    /// Unix-время, до которого валиден access_token Minecraft.
    #[serde(default)]
    pub expires_at: Option<i64>,
    /// Офлайн: путь к локальному png со скином.
    #[serde(default)]
    pub skin_path: Option<String>,
    /// Официальный: URL текстуры скина с серверов Mojang (для превью).
    #[serde(default)]
    pub skin_url: Option<String>,
    #[serde(default)]
    pub skin_slim: bool,
    #[serde(default)]
    pub last_used_at: Option<i64>,
    /// Тихое обновление не удалось — нужен повторный вход через браузер.
    #[serde(default)]
    pub invalid: bool,
}

impl StoredAccount {
    pub fn is_expired(&self) -> bool {
        match self.expires_at {
            // 5 минут запаса, чтобы токен не умер посреди запуска игры.
            Some(at) => now_unix() + 300 >= at,
            None => self.kind == AccountKind::Microsoft,
        }
    }
}

/// То, что уходит в UI. Токенов здесь намеренно нет.
#[derive(Debug, Clone, Serialize)]
pub struct AccountView {
    pub id: String,
    pub username: String,
    pub uuid: String,
    pub kind: AccountKind,
    pub skin_url: Option<String>,
    pub has_local_skin: bool,
    pub skin_slim: bool,
    pub selected: bool,
    pub needs_relogin: bool,
    pub last_used_at: Option<i64>,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct AccountStore {
    #[serde(default)]
    pub accounts: Vec<StoredAccount>,
    #[serde(default)]
    pub selected_id: Option<String>,
}

impl AccountStore {
    /// Битый или отсутствующий файл не должен ронять лаунчер — просто
    /// начинаем с пустого списка (битый файл при этом сохраняем как .bak).
    pub fn load() -> Self {
        let path = paths::accounts_file();
        let Ok(bytes) = std::fs::read(&path) else {
            return Self::default();
        };
        match serde_json::from_slice::<Self>(&bytes) {
            Ok(store) => store,
            Err(err) => {
                eprintln!("[vita] accounts.json повреждён ({err}), начинаю с пустого списка");
                let _ = std::fs::write(path.with_extension("json.bak"), &bytes);
                Self::default()
            }
        }
    }

    /// Пишем через временный файл + rename: если процесс упадёт в момент
    /// записи, accounts.json не превратится в обрезок.
    pub fn save(&self) -> anyhow::Result<()> {
        paths::ensure_dirs()?;
        let path = paths::accounts_file();
        let tmp = path.with_extension("json.tmp");
        std::fs::write(&tmp, serde_json::to_vec_pretty(self)?)?;
        std::fs::rename(&tmp, &path)?;
        Ok(())
    }

    pub fn get(&self, id: &str) -> Option<&StoredAccount> {
        self.accounts.iter().find(|a| a.id == id)
    }

    pub fn get_mut(&mut self, id: &str) -> Option<&mut StoredAccount> {
        self.accounts.iter_mut().find(|a| a.id == id)
    }

    pub fn selected(&self) -> Option<&StoredAccount> {
        self.selected_id.as_deref().and_then(|id| self.get(id))
    }

    /// Добавляет или обновляет аккаунт. Один и тот же игрок (тип + uuid) не
    /// должен появляться в списке дважды после повторного логина.
    pub fn upsert(&mut self, mut account: StoredAccount) -> String {
        let existing = self
            .accounts
            .iter()
            .position(|a| a.kind == account.kind && a.uuid.eq_ignore_ascii_case(&account.uuid));

        let id = match existing {
            Some(idx) => {
                let old = &self.accounts[idx];
                account.id = old.id.clone();
                // Локальный скин и данные превью логином не затираем.
                if account.skin_path.is_none() {
                    account.skin_path = old.skin_path.clone();
                }
                if account.skin_url.is_none() {
                    account.skin_url = old.skin_url.clone();
                }
                let id = account.id.clone();
                self.accounts[idx] = account;
                id
            }
            None => {
                if account.id.is_empty() {
                    account.id = Uuid::new_v4().to_string();
                }
                let id = account.id.clone();
                self.accounts.push(account);
                id
            }
        };
        self.selected_id = Some(id.clone());
        id
    }

    pub fn remove(&mut self, id: &str) -> Option<StoredAccount> {
        let idx = self.accounts.iter().position(|a| a.id == id)?;
        let removed = self.accounts.remove(idx);

        // Локальный скин удалённого аккаунта тоже подчищаем.
        if let Some(path) = &removed.skin_path {
            let _ = std::fs::remove_file(path);
        }
        if self.selected_id.as_deref() == Some(id) {
            // Переключаемся на самый недавно использованный из оставшихся.
            self.selected_id = self
                .accounts
                .iter()
                .max_by_key(|a| a.last_used_at.unwrap_or(0))
                .map(|a| a.id.clone());
        }
        Some(removed)
    }

    pub fn select(&mut self, id: &str) -> anyhow::Result<()> {
        if self.get(id).is_none() {
            anyhow::bail!("аккаунт не найден");
        }
        self.selected_id = Some(id.to_string());
        if let Some(acc) = self.get_mut(id) {
            acc.last_used_at = Some(now_unix());
        }
        Ok(())
    }

    pub fn views(&self) -> Vec<AccountView> {
        let mut list: Vec<AccountView> = self
            .accounts
            .iter()
            .map(|a| AccountView {
                id: a.id.clone(),
                username: a.username.clone(),
                uuid: a.uuid.clone(),
                kind: a.kind,
                skin_url: a.skin_url.clone(),
                has_local_skin: a
                    .skin_path
                    .as_ref()
                    .map(|p| std::path::Path::new(p).exists())
                    .unwrap_or(false),
                skin_slim: a.skin_slim,
                selected: self.selected_id.as_deref() == Some(a.id.as_str()),
                needs_relogin: a.kind == AccountKind::Microsoft
                    && (a.invalid || a.refresh_token.is_none()),
                last_used_at: a.last_used_at,
            })
            .collect();
        // Последний использованный — первым в списке.
        list.sort_by(|a, b| b.last_used_at.unwrap_or(0).cmp(&a.last_used_at.unwrap_or(0)));
        list
    }

    pub fn view_of(&self, id: &str) -> Option<AccountView> {
        self.views().into_iter().find(|v| v.id == id)
    }
}

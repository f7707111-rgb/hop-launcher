// Прячем консоль в release-сборке на Windows.
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod accounts;
mod auth;
mod backup;
mod launcher;
mod modloader;
mod mods;
mod mods_api;
mod net;
mod paths;
mod shortcuts;
mod skins;
mod util;
mod version_manager;

use serde::Serialize;
use tauri::Emitter;

use accounts::{AccountKind, AccountStore, AccountView, StoredAccount};
use modloader::{LoaderInfo, LoaderKind, LoaderOptions};
use mods_api::{ContentKind, ModInfo, ModVersion, Provider};
use version_manager::VersionManifest;

const DEFAULT_RAM_MB: u32 = 2048;

// --- Аккаунты ---------------------------------------------------------

#[derive(Serialize)]
struct StartupState {
    accounts: Vec<AccountView>,
    selected_id: Option<String>,
    java_path: Option<String>,
    java_major: Option<u32>,
    default_ram_mb: u32,
    launcher_dir: String,
    /// Задан ли client_id приложения Microsoft. Если нет — официальный вход
    /// невозможен, и лучше сказать об этом сразу, а не после клика.
    ms_ready: bool,
    ms_hint: Option<String>,
    installed_versions: Vec<String>,
    /// Все локальные профили: ваниль + сборки с Forge/Fabric.
    profiles: Vec<LoaderInfo>,
    /// Какие каталоги модов доступны (CurseForge — только с ключом API).
    mod_providers: Vec<mods_api::ProviderStatus>,
}

/// Всё, что нужно UI при старте: список аккаунтов, выбранный по умолчанию
/// (последний использованный), java, уже скачанные версии.
/// Здесь же тихо обновляем токен выбранного официального аккаунта.
#[tauri::command]
async fn startup_state() -> Result<StartupState, String> {
    let _ = paths::ensure_dirs();

    let mut store = AccountStore::load();

    // Если selected_id потерялся — берём последний использованный.
    if store.selected().is_none() {
        store.selected_id = store
            .accounts
            .iter()
            .max_by_key(|a| a.last_used_at.unwrap_or(0))
            .map(|a| a.id.clone());
    }

    // Тихое обновление access_token по refresh_token: браузер при старте
    // дёргать не нужно.
    if let Some(selected) = store.selected().cloned() {
        if selected.kind == AccountKind::Microsoft && selected.is_expired() {
            match auth::silent_refresh(&selected).await {
                Ok(refreshed) => {
                    store.upsert(refreshed);
                }
                Err(err) => {
                    eprintln!("[vita] тихое обновление не удалось: {err}");
                    if let Some(acc) = store.get_mut(&selected.id) {
                        acc.invalid = true;
                    }
                }
            }
        }
    }
    let _ = store.save();

    let java_path = which_java().or_else(|| {
        eprintln!("[vita] Java на машине не найдена, будет скачана при первом запуске игры");
        None
    });
    let java_major = java_path.as_deref().and_then(launcher::java_major_version);
    let (ms_ready, ms_hint) = match auth::ms_client_id() {
        Ok(_) => (true, None),
        Err(err) => (false, Some(err.to_string())),
    };

    Ok(StartupState {
        accounts: store.views(),
        selected_id: store.selected_id.clone(),
        java_path,
        java_major,
        default_ram_mb: DEFAULT_RAM_MB,
        launcher_dir: paths::launcher_dir().to_string_lossy().to_string(),
        ms_ready,
        ms_hint,
        installed_versions: version_manager::installed_versions(&paths::game_dir()),
        profiles: modloader::list_profiles(&paths::game_dir()),
        mod_providers: mods_api::provider_status(),
    })
}

#[tauri::command]
fn list_accounts() -> Vec<AccountView> {
    AccountStore::load().views()
}

#[tauri::command]
fn add_offline_account(username: String) -> Result<Vec<AccountView>, String> {
    let name = username.trim().to_string();
    if name.is_empty() || name.chars().count() > 16 {
        return Err("Ник должен быть от 1 до 16 символов".into());
    }
    if !name.chars().all(|c| c.is_ascii_alphanumeric() || c == '_') {
        return Err("В нике допустимы только латиница, цифры и подчёркивание".into());
    }

    let mut store = AccountStore::load();
    if store
        .accounts
        .iter()
        .any(|a| a.kind == AccountKind::Offline && a.username.eq_ignore_ascii_case(&name))
    {
        return Err(format!("Офлайн-аккаунт {name} уже есть в списке"));
    }

    store.upsert(auth::create_offline_account(&name));
    store.save().map_err(|e| e.to_string())?;
    Ok(store.views())
}

#[tauri::command]
async fn login_microsoft_start() -> Result<auth::DeviceCodeResponse, String> {
    auth::start_device_code_flow()
        .await
        .map_err(|e| e.to_string())
}

/// Ok(None) = пользователь ещё не подтвердил вход, опрашиваем дальше.
/// Err = реальная ошибка, опрос надо прекратить.
#[tauri::command]
async fn login_microsoft_poll(device_code: String) -> Result<Option<Vec<AccountView>>, String> {
    match auth::poll_device_code(&device_code)
        .await
        .map_err(|e| e.to_string())?
    {
        auth::PollOutcome::Pending => Ok(None),
        auth::PollOutcome::Ready(tokens) => {
            let account = auth::account_from_ms_tokens(&tokens)
                .await
                .map_err(|e| e.to_string())?;
            let mut store = AccountStore::load();
            store.upsert(account);
            store.save().map_err(|e| e.to_string())?;
            Ok(Some(store.views()))
        }
    }
}

#[tauri::command]
fn select_account(account_id: String) -> Result<Vec<AccountView>, String> {
    let mut store = AccountStore::load();
    store.select(&account_id).map_err(|e| e.to_string())?;
    store.save().map_err(|e| e.to_string())?;
    Ok(store.views())
}

#[tauri::command]
fn remove_account(account_id: String) -> Result<Vec<AccountView>, String> {
    let mut store = AccountStore::load();
    if store.remove(&account_id).is_none() {
        return Err("Аккаунт не найден".into());
    }
    store.save().map_err(|e| e.to_string())?;
    Ok(store.views())
}

/// Принудительное обновление токена (кнопка "обновить" у официального аккаунта).
#[tauri::command]
async fn refresh_account(account_id: String) -> Result<Vec<AccountView>, String> {
    let store = AccountStore::load();
    let account = store
        .get(&account_id)
        .cloned()
        .ok_or_else(|| "Аккаунт не найден".to_string())?;
    if account.kind != AccountKind::Microsoft {
        return Err("Офлайн-аккаунту обновление не нужно".into());
    }

    let refreshed = auth::silent_refresh(&account)
        .await
        .map_err(|e| e.to_string())?;
    let mut store = AccountStore::load();
    store.upsert(refreshed);
    store.save().map_err(|e| e.to_string())?;
    Ok(store.views())
}

/// Открывает ссылку во внешнем браузере (страница подтверждения входа).
#[tauri::command]
fn open_url(url: String) -> Result<(), String> {
    net::ensure_trusted_url(&url).map_err(|e| e.to_string())?;
    let result = if cfg!(target_os = "windows") {
        std::process::Command::new("cmd")
            .args(["/C", "start", "", url.as_str()])
            .spawn()
    } else if cfg!(target_os = "macos") {
        std::process::Command::new("open").arg(&url).spawn()
    } else {
        std::process::Command::new("xdg-open").arg(&url).spawn()
    };
    result.map(|_| ()).map_err(|e| e.to_string())
}

// --- Скины ------------------------------------------------------------

#[tauri::command]
async fn upload_skin(
    account_id: String,
    png: Vec<u8>,
    slim: bool,
) -> Result<Vec<AccountView>, String> {
    let store = AccountStore::load();
    let account = store
        .get(&account_id)
        .cloned()
        .ok_or_else(|| "Аккаунт не найден".to_string())?;

    match account.kind {
        AccountKind::Microsoft => {
            // Токен мог истечь, пока лаунчер был открыт — обновляем молча.
            let account = ensure_fresh(account).await?;
            let url = skins::upload_official_skin(&account.access_token, png, slim)
                .await
                .map_err(|e| e.to_string())?;

            let mut store = AccountStore::load();
            if let Some(acc) = store.get_mut(&account_id) {
                acc.access_token = account.access_token.clone();
                acc.refresh_token = account.refresh_token.clone();
                acc.expires_at = account.expires_at;
                acc.skin_url = url;
                acc.skin_slim = slim;
                acc.invalid = false;
            }
            store.save().map_err(|e| e.to_string())?;
            Ok(store.views())
        }
        AccountKind::Offline => {
            // Вариант B: png живёт локально, в UI честное предупреждение.
            let path = skins::save_local_skin(&account_id, &png).map_err(|e| e.to_string())?;
            let mut store = AccountStore::load();
            if let Some(acc) = store.get_mut(&account_id) {
                acc.skin_path = Some(path.to_string_lossy().to_string());
                acc.skin_slim = slim;
            }
            store.save().map_err(|e| e.to_string())?;
            Ok(store.views())
        }
    }
}

#[tauri::command]
async fn clear_skin(account_id: String) -> Result<Vec<AccountView>, String> {
    let store = AccountStore::load();
    let account = store
        .get(&account_id)
        .cloned()
        .ok_or_else(|| "Аккаунт не найден".to_string())?;

    if account.kind == AccountKind::Microsoft {
        let account = ensure_fresh(account).await?;
        skins::reset_official_skin(&account.access_token)
            .await
            .map_err(|e| e.to_string())?;
    } else {
        skins::remove_local_skin(&account);
    }

    let mut store = AccountStore::load();
    if let Some(acc) = store.get_mut(&account_id) {
        acc.skin_path = None;
        acc.skin_url = None;
    }
    store.save().map_err(|e| e.to_string())?;
    Ok(store.views())
}

#[tauri::command]
fn get_skin_preview(account_id: String) -> Option<String> {
    let store = AccountStore::load();
    store.get(&account_id).and_then(skins::skin_preview)
}

// --- Версии и запуск --------------------------------------------------

/// Полный список версий для выпадающего списка. Загружается один раз и
/// НИЧЕГО не скачивает кроме самого манифеста.
#[tauri::command]
async fn get_version_manifest() -> Result<VersionManifest, String> {
    version_manager::fetch_version_manifest()
        .await
        .map_err(|e| e.to_string())
}

#[tauri::command]
fn list_installed_versions() -> Vec<String> {
    version_manager::installed_versions(&paths::game_dir())
}

#[derive(Serialize)]
struct LaunchResult {
    version_id: String,
    /// true = всё уже было скачано, из сети не тянули ничего.
    cached: bool,
    pid: u32,
    /// Какой модлоадер реально запустился.
    loader: String,
    /// Сколько включённых модов ушло в игру.
    mods: usize,
    /// Файлы, которых не было на диске и которые докачали молча.
    restored: Vec<String>,
}

/// Ставит (если нужно) и запускает РОВНО ту версию, которую выбрали в списке.
#[tauri::command]
async fn install_and_launch(
    app: tauri::AppHandle,
    version_id: String,
    version_url: String,
    // profile_id — id профиля из versions/ (сборка с Forge/Fabric).
    // Пусто/None = запускаем ваниль.
    profile_id: Option<String>,
    account_id: String,
    java_path: String,
    max_ram_mb: u32,
) -> Result<LaunchResult, String> {
    let game_dir = paths::game_dir();

    // 1. Аккаунт (+ тихое обновление токена, если истёк)
    let store = AccountStore::load();
    let account = store
        .get(&account_id)
        .cloned()
        .ok_or_else(|| "Аккаунт не найден, выбери его в списке слева".to_string())?;
    let account = ensure_fresh(account).await?;

    {
        let mut store = AccountStore::load();
        store.upsert(account.clone());
        let _ = store.select(&account.id);
        let _ = store.save();
    }

    // 2. Что именно запускаем: ваниль или профиль модлоадера. У профиля JSON
    //    уже лежит на диске, ванильного родителя он подтянет сам.
    let launch_id = profile_id
        .map(|p| p.trim().to_string())
        .filter(|p| !p.is_empty())
        .unwrap_or_else(|| version_id.clone());
    let url_for_launch = if launch_id == version_id {
        version_url.clone()
    } else {
        String::new()
    };

    let detail = version_manager::resolve_detail(&game_dir, &launch_id, &url_for_launch)
        .await
        .map_err(|e| e.to_string())?;

    // 3. Установка с проверкой кэша
    let cached = ensure_installed(&app, &detail).await?;

    // 4. Моды: файл мог быть удалён мимо лаунчера — тихо возвращаем его.
    let restored = match mods::restore_missing(&launch_id).await {
        Ok(list) => list,
        Err(err) => {
            eprintln!("[vita] не удалось восстановить файлы модов: {err}");
            Vec::new()
        }
    };
    let loader = modloader::detect_loader(&game_dir, &launch_id)
        .map(|l| l.kind)
        .unwrap_or(LoaderKind::Vanilla);
    let mc_version = detail.client_version_id().to_string();
    let enabled_mods = mods::list_mods(&launch_id, &mc_version, loader)
        .into_iter()
        .filter(|m| m.enabled)
        .count();

    // 5. Запуск
    let java = if java_path.trim().is_empty() {
        return Err(
            "Java не найдена на машине.              
Поставь JDK 21 (для версий 1.20.5+) или JDK 17 отсюда:              
https://adoptium.net/temurin/releases/              
              
Выбери Windows Installer, установи, перезапусти лаунчер.".to_string()
        );
    } else {
        java_path
    };

    let run_dir = paths::run_dir(&launch_id);

    // Автобэкап мира перед запуском: бы��тро, в фоновом потоке, никогда не
    // блокирует старт игры и никогда её не ломает, даже если зип не соберётся.
    {
        let backup_run_dir = run_dir.clone();
        let backup_version_id = launch_id.clone();
        std::thread::spawn(move || match backup::backup_world(&backup_run_dir, &backup_version_id) {
            Ok(Some(path)) => eprintln!("[vita] автобэкап мира сохранён: {path}"),
            Ok(None) => {}
            Err(err) => eprintln!("[vita] автобэкап мира не удался: {err}"),
        });
    }

    let emit = make_emitter(Some(app.clone()));
    let pid = launcher::launch(
        &emit,
        &game_dir,
        &run_dir,
        &detail,
        &account,
        &java,
        max_ram_mb,
        &modloader::extra_jvm_args(loader),
    )
    .await
    .map_err(|e| e.to_string())?;

    Ok(LaunchResult {
        version_id: detail.id,
        cached,
        pid,
        loader: loader.as_str().to_string(),
        mods: enabled_mods,
        restored,
    })
}

/// Собирает приёмник событий: с окном — шлём в него, без окна (headless-запуск
/// ярлыка) — печатаем в stderr, чтобы хоть в консоли было видно, что происходит.
fn make_emitter(app: Option<tauri::AppHandle>) -> launcher::Emitter {
    match app {
        Some(app) => std::sync::Arc::new(move |event: &str, payload: serde_json::Value| {
            let _ = app.emit(event, payload);
        }),
        None => std::sync::Arc::new(|event: &str, payload: serde_json::Value| {
            eprintln!("[vita] {event}: {payload}");
        }),
    }
}

// --- Ярлыки быстрого запуска ------------------------------------------
//
// Ярлык — это сохранённая связка аккаунт+версия(+сборка), по которой можно
// стартовать игру в один клик с рабочего стола/меню, минуя обычное окно
// лаунчера. Общая логика запуска (обновить токен, разрешить версию,
// доустановить, запустить java) шарится между обычной командой
// `launch_from_shortcut` (из открытого лаунчера) и headless-путём, который
// main() выбирает по аргументу `--launch-shortcut=<name>` ещё до создания
// окна Tauri.
async fn run_shortcut(
    app: Option<tauri::AppHandle>,
    shortcut: shortcuts::ShortcutFile,
) -> Result<LaunchResult, String> {
    let game_dir = paths::game_dir();

    let store = AccountStore::load();
    let account = store.get(&shortcut.account_id).cloned().ok_or_else(|| {
        format!(
            "Аккаунт ярлыка «{}» не найден — пересоздай ярлык",
            shortcut.name
        )
    })?;
    let account = ensure_fresh(account).await?;
    {
        let mut store = AccountStore::load();
        store.upsert(account.clone());
        let _ = store.select(&account.id);
        let _ = store.save();
    }

    let launch_id = shortcut
        .profile_id
        .clone()
        .filter(|p| !p.trim().is_empty())
        .unwrap_or_else(|| shortcut.version_id.clone());

    let mut url_for_launch = if launch_id == shortcut.version_id {
        shortcut.version_url.clone()
    } else {
        String::new()
    };
    if url_for_launch.trim().is_empty() && !version_manager::local_detail_exists(&game_dir, &launch_id) {
        url_for_launch = version_manager::version_url_for(&launch_id)
            .await
            .map_err(|e| e.to_string())?
            .ok_or_else(|| format!("версия {launch_id} не найдена ни на диске, ни в манифесте Mojang"))?;
    }

    let detail = version_manager::resolve_detail(&game_dir, &launch_id, &url_for_launch)
        .await
        .map_err(|e| e.to_string())?;

    let emit = make_emitter(app);

    let cached = version_manager::ensure_installed(&game_dir, &detail, {
        let emit = emit.clone();
        move |phase: &str, done: usize, total: usize, label: &str| {
            emit(
                "install-progress",
                serde_json::json!({ "phase": phase, "done": done, "total": total, "label": label }),
            );
        }
    })
    .await
    .map_err(|e| e.to_string())?;

    let restored = match mods::restore_missing(&launch_id).await {
        Ok(list) => list,
        Err(err) => {
            eprintln!("[vita] не удалось восстановить файлы модов: {err}");
            Vec::new()
        }
    };
    let loader = modloader::detect_loader(&game_dir, &launch_id)
        .map(|l| l.kind)
        .unwrap_or(LoaderKind::Vanilla);
    let mc_version = detail.client_version_id().to_string();
    let enabled_mods = mods::list_mods(&launch_id, &mc_version, loader)
        .into_iter()
        .filter(|m| m.enabled)
        .count();

    let java = which_java().ok_or_else(|| "Java не найдена на машине.".to_string())?;
    let run_dir = paths::run_dir(&launch_id);

    let pid = launcher::launch(
        &emit,
        &game_dir,
        &run_dir,
        &detail,
        &account,
        &java,
        DEFAULT_RAM_MB,
        &modloader::extra_jvm_args(loader),
    )
    .await
    .map_err(|e| e.to_string())?;

    Ok(LaunchResult {
        version_id: detail.id,
        cached,
        pid,
        loader: loader.as_str().to_string(),
        mods: enabled_mods,
        restored,
    })
}

/// Кнопка «☆ Создать ярлык» рядом с «Играть»: сохраняет JSON в shortcuts/,
/// тянет иконку (голову скина текущего аккаунта) и создаёт настоящий
/// платформенный ярлык (рабочий стол Windows/.desktop на Linux/.command на
/// macOS), который запускает лаунчер с `--launch-shortcut=<name>`.
#[tauri::command]
async fn create_desktop_shortcut(
    name: String,
    account_id: String,
    version_id: String,
    version_url: Option<String>,
    profile_id: Option<String>,
    loader: Option<String>,
) -> Result<shortcuts::ShortcutInfo, String> {
    let trimmed = name.trim().to_string();
    if trimmed.is_empty() {
        return Err("Введи название ярлыка".into());
    }
    if shortcuts::exists(&trimmed) {
        return Err(format!("Ярлык «{trimmed}» уже существует"));
    }

    let store = AccountStore::load();
    let account = store
        .get(&account_id)
        .cloned()
        .ok_or_else(|| "Аккаунт не найден".to_string())?;

    let icon_path = shortcuts::save_icon_for(&trimmed, &account).await;

    let file = shortcuts::ShortcutFile {
        name: trimmed.clone(),
        account_id: account_id.clone(),
        version_id,
        profile_id: profile_id.filter(|p| !p.trim().is_empty()),
        loader: loader.unwrap_or_else(|| "Vanilla".to_string()),
        version_url: version_url.unwrap_or_default(),
        created_at: util::now_unix(),
    };
    shortcuts::save(&file).map_err(|e| e.to_string())?;
    shortcuts::create_platform_shortcut(&trimmed, icon_path.as_deref()).map_err(|e| e.to_string())?;

    Ok(shortcuts::info(&file, Some(account.username)))
}

/// Список всех ярлыков для панели в сайдбаре.
#[tauri::command]
fn list_shortcuts() -> Vec<shortcuts::ShortcutInfo> {
    let store = AccountStore::load();
    shortcuts::list()
        .into_iter()
        .map(|s| {
            let account_name = store.get(&s.account_id).map(|a| a.username.clone());
            shortcuts::info(&s, account_name)
        })
        .collect()
}

/// Удаляет JSON и платформенный ярлык (рабочий стол / меню приложений).
#[tauri::command]
fn delete_shortcut(name: String) -> Result<(), String> {
    shortcuts::delete(&name).map_err(|e| e.to_string())
}

/// Ручной запуск ярлыка из самого лаунчера (например, чтобы проверить его,
/// не выходя на рабочий стол). Настоящий сценарий «в один клик с рабочего
/// стола» идёт через headless-путь в main().
#[tauri::command]
async fn launch_from_shortcut(
    app: tauri::AppHandle,
    shortcut_name: String,
) -> Result<LaunchResult, String> {
    let shortcut = shortcuts::load(&shortcut_name).map_err(|e| e.to_string())?;
    run_shortcut(Some(app), shortcut).await
}

/// Headless-запуск: main() зовёт это до создания окна Tauri, поэтому тут нет
/// AppHandle — события уходят в stderr через make_emitter(None).
async fn launch_shortcut_headless(shortcut_name: &str) -> anyhow::Result<()> {
    let shortcut = shortcuts::load(shortcut_name)?;
    run_shortcut(None, shortcut).await.map_err(|e| anyhow::anyhow!(e))?;
    Ok(())
}

/// Установка версии/профиля с прогрессом в UI. Вынесена отдельно, потому что
/// нужна и перед запуском, и перед установкой модлоадера.
async fn ensure_installed(
    app: &tauri::AppHandle,
    detail: &version_manager::VersionDetail,
) -> Result<bool, String> {
    let app_for_progress = app.clone();
    version_manager::ensure_installed(
        &paths::game_dir(),
        detail,
        move |phase: &str, done: usize, total: usize, label: &str| {
            let _ = app_for_progress.emit(
                "install-progress",
                serde_json::json!({
                    "phase": phase,
                    "done": done,
                    "total": total,
                    "label": label
                }),
            );
        },
    )
    .await
    .map_err(|e| e.to_string())
}

/// Обновляет токен официального аккаунта, если он истёк.
async fn ensure_fresh(account: StoredAccount) -> Result<StoredAccount, String> {
    if account.kind != AccountKind::Microsoft || !account.is_expired() {
        return Ok(account);
    }
    match auth::silent_refresh(&account).await {
        Ok(refreshed) => {
            let mut store = AccountStore::load();
            store.upsert(refreshed.clone());
            let _ = store.save();
            Ok(refreshed)
        }
        Err(err) => {
            let mut store = AccountStore::load();
            if let Some(acc) = store.get_mut(&account.id) {
                acc.invalid = true;
            }
            let _ = store.save();
            Err(format!(
                "Не удалось обновить вход для {}: {err}. Войди через Microsoft заново.",
                account.username
            ))
        }
    }
}


// --- Модлоадеры -------------------------------------------------------

/// Что доступно для этой версии MC: сборки Forge, сборки Fabric и уже
/// установленные профили.
#[tauri::command]
async fn get_loaders(mc_version: String) -> Result<LoaderOptions, String> {
    Ok(modloader::available_loaders(&paths::game_dir(), &mc_version).await)
}

/// Все локальные профили (ваниль + сборки) для выпадающего списка.
#[tauri::command]
fn list_profiles() -> Vec<LoaderInfo> {
    modloader::list_profiles(&paths::game_dir())
}

/// Какой loader стоит в конкретном профиле.
#[tauri::command]
fn detect_current_loader(profile_id: String) -> Option<LoaderInfo> {
    modloader::detect_loader(&paths::game_dir(), &profile_id)
}

#[derive(Serialize)]
struct InstallLoaderResult {
    profile_id: String,
    loader: String,
    loader_version: String,
    /// Что доставили попутно (например, Fabric API).
    extras: Vec<String>,
}

/// Ставит Forge/Fabric и создаёт отдельный профиль в versions/.
/// Ванильная версия при необходимости скачивается первой: installer Forge
/// проверяет client.jar, а Fabric без ассетов родителя не запустится.
#[tauri::command]
async fn install_loader(
    app: tauri::AppHandle,
    mc_version: String,
    version_url: String,
    loader_kind: String,
    loader_version: String,
    with_fabric_api: bool,
    java_path: String,
) -> Result<InstallLoaderResult, String> {
    let game_dir = paths::game_dir();
    let kind = LoaderKind::parse(&loader_kind).map_err(|e| e.to_string())?;

    // 1. Ваниль
    let vanilla = version_manager::resolve_detail(&game_dir, &mc_version, &version_url)
        .await
        .map_err(|e| e.to_string())?;
    ensure_installed(&app, &vanilla).await?;

    // 2. Сам модлоадер
    let app_for_status = app.clone();
    let profile_id = modloader::install_loader(
        &game_dir,
        kind,
        &mc_version,
        &loader_version,
        &java_path,
        move |line: &str| {
            let _ = app_for_status.emit(
                "install-progress",
                serde_json::json!({ "phase": "loader", "done": 0, "total": 1, "label": line }),
            );
        },
    )
    .await
    .map_err(|e| e.to_string())?;

    // 3. Библиотеки профиля (у Fabric их качаем мы, у Forge доложил installer)
    let profile = version_manager::resolve_detail(&game_dir, &profile_id, "")
        .await
        .map_err(|e| e.to_string())?;
    ensure_installed(&app, &profile).await?;

    let detected = modloader::detect_loader(&game_dir, &profile_id);
    let resolved_version = detected
        .as_ref()
        .map(|d| d.version.clone())
        .unwrap_or_else(|| loader_version.clone());
    mods::remember_loader(&profile_id, kind, &resolved_version, &mc_version)
        .map_err(|e| e.to_string())?;

    // 4. Fabric API — обычный мод, а не библиотека загрузчика.
    let mut extras = Vec::new();
    if with_fabric_api && kind == LoaderKind::Fabric {
        let dir = paths::mods_dir(&profile_id);
        match mods_api::install_fabric_api(&mc_version, &dir).await {
            Ok(filename) => {
                let mut config = mods::load_config(&profile_id);
                config.mods.retain(|m| m.filename != filename);
                config.mods.push(mods::ModRecord {
                    id: "fabric-api".to_string(),
                    filename: filename.clone(),
                    enabled: true,
                    source: "modrinth:fabric-api".to_string(),
                    name: "Fabric API".to_string(),
                    ..Default::default()
                });
                let _ = mods::save_config(&profile_id, &config);
                extras.push(filename);
            }
            Err(err) => eprintln!("[vita] Fabric API не поставился: {err}"),
        }
    }

    Ok(InstallLoaderResult {
        profile_id,
        loader: kind.as_str().to_string(),
        loader_version: resolved_version,
        extras,
    })
}

// --- Моды профиля -----------------------------------------------------

#[derive(Serialize)]
struct ModsView {
    profile_id: String,
    loader: String,
    loader_version: String,
    mc_version: String,
    mods_dir: String,
    mods: Vec<mods::ModEntry>,
}

#[tauri::command]
fn list_installed_mods(profile_id: String) -> Result<ModsView, String> {
    let game_dir = paths::game_dir();
    let info = modloader::detect_loader(&game_dir, &profile_id);
    let config = mods::load_config(&profile_id);
    let loader = info
        .as_ref()
        .map(|i| i.kind)
        .unwrap_or(LoaderKind::Vanilla);
    let mc_version = info
        .as_ref()
        .map(|i| i.mc_version.clone())
        .filter(|v| !v.is_empty())
        .unwrap_or(config.mc_version);

    Ok(ModsView {
        mods: mods::list_mods(&profile_id, &mc_version, loader),
        mods_dir: paths::mods_dir(&profile_id).to_string_lossy().to_string(),
        loader: loader.as_str().to_string(),
        loader_version: info.map(|i| i.version).unwrap_or_default(),
        mc_version,
        profile_id,
    })
}

#[tauri::command]
fn toggle_mod(profile_id: String, filename: String, enabled: bool) -> Result<(), String> {
    mods::toggle_mod(&profile_id, &filename, enabled).map_err(|e| e.to_string())
}

#[tauri::command]
fn remove_mod(profile_id: String, filename: String) -> Result<(), String> {
    mods::remove_mod(&profile_id, &filename).map_err(|e| e.to_string())
}

/// Мод из локального файла (кнопка «Из файла» в диалоге добавления).
#[tauri::command]
fn add_local_mod(profile_id: String, path: String) -> Result<String, String> {
    mods::add_local_mod(&profile_id, std::path::Path::new(&path)).map_err(|e| e.to_string())
}

// --- Каталоги модов ---------------------------------------------------

#[tauri::command]
fn mod_providers() -> Vec<mods_api::ProviderStatus> {
    mods_api::provider_status()
}

#[tauri::command]
async fn search_mods(
    provider: String,
    kind: String,
    query: String,
    loader: String,
    mc_version: String,
    offset: u32,
) -> Result<Vec<ModInfo>, String> {
    let provider = Provider::parse(&provider).map_err(|e| e.to_string())?;
    let loader = LoaderKind::parse(&loader).map_err(|e| e.to_string())?;
    mods_api::search(
        provider,
        ContentKind::parse(&kind),
        &query,
        loader,
        &mc_version,
        offset,
    )
    .await
    .map_err(|e| e.to_string())
}

#[tauri::command]
async fn get_mod_versions(
    provider: String,
    project_id: String,
    kind: String,
    loader: String,
    mc_version: String,
) -> Result<Vec<ModVersion>, String> {
    let provider = Provider::parse(&provider).map_err(|e| e.to_string())?;
    let loader = LoaderKind::parse(&loader).map_err(|e| e.to_string())?;
    mods_api::versions(
        provider,
        &project_id,
        loader,
        &mc_version,
        ContentKind::parse(&kind),
    )
    .await
    .map_err(|e| e.to_string())
}

/// Скачивает выбранный файл в mods/ или resourcepacks/ профиля и записывает
/// его в mods.json. Уже лежащий файл с тем же sha1 не перекачивается.
#[tauri::command]
async fn download_and_install_mod(
    app: tauri::AppHandle,
    provider: String,
    project_id: String,
    kind: String,
    profile_id: String,
    version: ModVersion,
    project_name: String,
) -> Result<String, String> {
    let provider_kind = Provider::parse(&provider).map_err(|e| e.to_string())?;
    let content = ContentKind::parse(&kind);
    let dir = match content {
        ContentKind::Mod => paths::mods_dir(&profile_id),
        ContentKind::ResourcePack => paths::resourcepacks_dir(&profile_id),
    };

    let _ = app.emit(
        "install-progress",
        serde_json::json!({
            "phase": "mod",
            "done": 0,
            "total": 1,
            "label": version.filename.clone()
        }),
    );

    let downloaded = mods_api::download_file(provider_kind, &project_id, &version, &dir)
        .await
        .map_err(|e| e.to_string())?;

    let record = mods::ModRecord {
        id: project_id.clone(),
        filename: downloaded.filename.clone(),
        enabled: true,
        version: version.version.clone(),
        source: format!("{}:{}", provider_kind.slug(), project_id),
        sha1: downloaded.sha1,
        name: project_name,
        url: downloaded.url,
        size: downloaded.size,
    };

    let mut config = mods::load_config(&profile_id);
    let list = match content {
        ContentKind::Mod => &mut config.mods,
        ContentKind::ResourcePack => &mut config.resourcepacks,
    };
    list.retain(|m| m.filename != record.filename);
    list.push(record.clone());
    mods::save_config(&profile_id, &config).map_err(|e| e.to_string())?;

    let _ = app.emit(
        "install-progress",
        serde_json::json!({ "phase": "done", "done": 1, "total": 1, "label": record.filename }),
    );
    Ok(record.filename)
}

// --- Ресурс-паки ------------------------------------------------------

#[derive(Serialize)]
struct ResourcePacksView {
    profile_id: String,
    dir: String,
    packs: Vec<mods::ResourcePackEntry>,
}

#[tauri::command]
fn list_resourcepacks(profile_id: String) -> Result<ResourcePacksView, String> {
    Ok(ResourcePacksView {
        packs: mods::list_resourcepacks(&profile_id),
        dir: paths::resourcepacks_dir(&profile_id)
            .to_string_lossy()
            .to_string(),
        profile_id,
    })
}

#[tauri::command]
fn toggle_resourcepack(profile_id: String, filename: String, enabled: bool) -> Result<(), String> {
    mods::toggle_resourcepack(&profile_id, &filename, enabled).map_err(|e| e.to_string())
}

#[tauri::command]
fn remove_resourcepack(profile_id: String, filename: String) -> Result<(), String> {
    mods::remove_resourcepack(&profile_id, &filename).map_err(|e| e.to_string())
}

#[tauri::command]
fn add_local_resourcepack(profile_id: String, path: String) -> Result<String, String> {
    mods::add_local_resourcepack(&profile_id, std::path::Path::new(&path))
        .map_err(|e| e.to_string())
}

/// Открывает папку профиля в проводнике — быстрее, чем объяснять путь словами.
// --- Друзья: экспорт/импорт модпака ------------------------------------

/// Отдаёт список модов текущего профиля в виде, который можно переслать
/// другу через сервер друзей (JSON), чтобы он мог поставить точно то же.
#[tauri::command]
fn export_modpack(profile_id: String) -> Result<Vec<mods::ModRecord>, String> {
    let config = mods::load_config(&profile_id);
    Ok(config.mods)
}

/// Ставит список модов (полученный от друга) в указанный профиль.
/// Каждая запись уже содержит прямую ссылку на файл и sha1, поэтому
/// скачивание идёт напрямую, без повторного поиска в каталоге.
#[tauri::command]
async fn import_modpack(
    app: tauri::AppHandle,
    profile_id: String,
    records: Vec<mods::ModRecord>,
) -> Result<usize, String> {
    let dir = paths::mods_dir(&profile_id);
    let mut config = mods::load_config(&profile_id);
    let total = records.len();
    let mut done = 0usize;

    for record in records {
        let _ = app.emit(
            "install-progress",
            serde_json::json!({
                "phase": "mod",
                "done": done,
                "total": total,
                "label": record.name.clone()
            }),
        );

        let mut parts = record.source.splitn(2, ':');
        let provider_slug = parts.next().unwrap_or("modrinth");
        let project_id = parts.next().unwrap_or(&record.id).to_string();
        let provider_kind = match mods_api::Provider::parse(provider_slug) {
            Ok(p) => p,
            Err(_) => mods_api::Provider::Modrinth,
        };

        let version = mods_api::ModVersion {
            file_id: project_id.clone(),
            provider: provider_slug.to_string(),
            display_name: record.name.clone(),
            filename: record.filename.clone(),
            version: record.version.clone(),
            date: String::new(),
            size: record.size,
            sha1: record.sha1.clone(),
            download_url: record.url.clone(),
            game_versions: Vec::new(),
            loaders: Vec::new(),
            downloadable: true,
        };

        match mods_api::download_file(provider_kind, &project_id, &version, &dir).await {
            Ok(downloaded) => {
                config.mods.retain(|m| m.filename != downloaded.filename);
                config.mods.push(mods::ModRecord {
                    id: project_id,
                    filename: downloaded.filename,
                    enabled: true,
                    version: record.version,
                    source: record.source,
                    sha1: downloaded.sha1,
                    name: record.name,
                    url: downloaded.url,
                    size: downloaded.size,
                });
                done += 1;
            }
            Err(err) => eprintln!("[vita] не удалось поставить мод друга {}: {err}", record.filename),
        }
    }

    mods::save_config(&profile_id, &config).map_err(|e| e.to_string())?;
    Ok(done)
}

#[tauri::command]
fn open_profile_folder(profile_id: String, kind: String) -> Result<(), String> {
    let path = match kind.as_str() {
        "mods" => paths::mods_dir(&profile_id),
        "resourcepacks" => paths::resourcepacks_dir(&profile_id),
        _ => paths::instance_dir(&profile_id),
    };
    std::fs::create_dir_all(&path).map_err(|e| e.to_string())?;
    let result = if cfg!(target_os = "windows") {
        std::process::Command::new("explorer").arg(&path).spawn()
    } else if cfg!(target_os = "macos") {
        std::process::Command::new("open").arg(&path).spawn()
    } else {
        std::process::Command::new("xdg-open").arg(&path).spawn()
    };
    result.map(|_| ()).map_err(|e| e.to_string())
}

#[tauri::command]
fn detect_java() -> Option<String> {
    which_java()
}

fn which_java() -> Option<String> {
    // Сначала настройка/переменная окружения, потом PATH, потом типовые пути.
    if let Ok(path) = std::env::var("VITA_JAVA_PATH") {
        if !path.trim().is_empty() {
            return Some(path);
        }
    }
    if let Ok(bytes) = std::fs::read(paths::config_file()) {
        if let Ok(cfg) = serde_json::from_slice::<serde_json::Value>(&bytes) {
            if let Some(path) = cfg.get("java_path").and_then(|v| v.as_str()) {
                if !path.trim().is_empty() {
                    return Some(path.to_string());
                }
            }
        }
    }

    let cmd = if cfg!(target_os = "windows") { "where" } else { "which" };
    if let Ok(output) = std::process::Command::new(cmd).arg("java").output() {
        if output.status.success() {
            if let Some(first) = String::from_utf8_lossy(&output.stdout).lines().next() {
                let trimmed = first.trim();
                if !trimmed.is_empty() {
                    return Some(trimmed.to_string());
                }
            }
        }
    }

    if let Ok(java_home) = std::env::var("JAVA_HOME") {
        let exe = if cfg!(target_os = "windows") { "java.exe" } else { "java" };
        let candidate = std::path::Path::new(&java_home).join("bin").join(exe);
        if candidate.exists() {
            return Some(candidate.to_string_lossy().to_string());
        }
    }
    None
}

/// Ярлык может стартовать лаунчер с `--launch-shortcut=<name>` (создаётся
/// кнопкой «☆ Создать ярлык», см. shortcuts.rs). В этом случае UI вообще не
/// нужен: разбираем аргумент до создания окна Tauri, доустанавливаем и
/// запускаем игру headless-путём и завершаем процесс лаунчера, оставляя
/// Minecraft жить самостоятельно — ровно то самое «окно Minecraft вместо
/// окна лаунчера».
fn main() {
    let args: Vec<String> = std::env::args().collect();
    if let Some(pos) = args.iter().position(|a| a.starts_with("--launch-shortcut=")) {
        let shortcut_name = args[pos]
            .split_once('=')
            .map(|(_, v)| v.to_string())
            .unwrap_or_default();
        let rt = tokio::runtime::Runtime::new().expect("не удалось создать async runtime");
        let code = rt.block_on(async {
            match launch_shortcut_headless(&shortcut_name).await {
                Ok(()) => 0,
                Err(err) => {
                    eprintln!("[vita] ошибка запуска ярлыка «{shortcut_name}»: {err}");
                    1
                }
            }
        });
        std::process::exit(code);
    }

    tauri::Builder::default()
        .plugin(tauri_plugin_shell::init())
        .plugin(tauri_plugin_dialog::init())
        .setup(|app| {
            // Иконка в трее — тот же лого HOP, что и в окне/билде. Клик по иконке
            // восстанавливает/фокусит окно лаунчера.
            use tauri::tray::TrayIconBuilder;
            use tauri::Manager;
            if let Some(icon) = app.default_window_icon().cloned() {
                let app_handle = app.handle().clone();
                TrayIconBuilder::new()
                    .icon(icon)
                    .tooltip("HOP")
                    .on_tray_icon_event(move |_tray, event| {
                        if let tauri::tray::TrayIconEvent::Click { .. } = event {
                            if let Some(win) = app_handle.get_webview_window("main") {
                                let _ = win.show();
                                let _ = win.set_focus();
                            }
                        }
                    })
                    .build(app)?;
            }
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            startup_state,
            list_accounts,
            add_offline_account,
            login_microsoft_start,
            login_microsoft_poll,
            select_account,
            remove_account,
            refresh_account,
            open_url,
            upload_skin,
            clear_skin,
            get_skin_preview,
            get_version_manifest,
            list_installed_versions,
            install_and_launch,
            create_desktop_shortcut,
            list_shortcuts,
            delete_shortcut,
            launch_from_shortcut,
            detect_java,
            get_loaders,
            list_profiles,
            detect_current_loader,
            install_loader,
            list_installed_mods,
            toggle_mod,
            remove_mod,
            add_local_mod,
            mod_providers,
            search_mods,
            get_mod_versions,
            download_and_install_mod,
            list_resourcepacks,
            toggle_resourcepack,
            remove_resourcepack,
            add_local_resourcepack,
            open_profile_folder,
            export_modpack,
            import_modpack,
        ])
        .run(tauri::generate_context!())
        .expect("error while running HOP");
}

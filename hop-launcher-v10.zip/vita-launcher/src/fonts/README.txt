Monocraft font (pixel Minecraft-style font) is NOT bundled here because this
sandbox has no internet access to download it.

To get the real look:
1. Download Monocraft.ttf from https://github.com/IdreesInc/Monocraft/releases
2. Put the file here as: src/fonts/Monocraft.ttf
3. Restart the app (npm run tauri dev / rebuild).

Until then, the launcher automatically falls back to a monospace font
(Segoe UI / system default), so nothing breaks — it just won't look pixelated.
